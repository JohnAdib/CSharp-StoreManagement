﻿namespace StoreManagement.Forms
{
    partial class FrmHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmHome));
            this.jsPanelMenuHome = new JSRequirement.Controls.JSPanel();
            this.jsMenuStripStoreManagement1 = new StoreManagement.Requirement.JSMenuStripStoreManagement();
            this.jS7Btn2 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn4 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn5 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn1 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn3 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn6 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn7 = new JSRequirement.Controls.JS7Btn();
            this.jsPanelMenuHome.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsPanelMenuHome
            // 
            this.jsPanelMenuHome.BackColor = System.Drawing.Color.Transparent;
            this.jsPanelMenuHome.Controls.Add(this.jsMenuStripStoreManagement1);
            this.jsPanelMenuHome.Dock = System.Windows.Forms.DockStyle.Right;
            this.jsPanelMenuHome.Location = new System.Drawing.Point(509, 0);
            this.jsPanelMenuHome.Name = "jsPanelMenuHome";
            this.jsPanelMenuHome.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanelMenuHome.Size = new System.Drawing.Size(75, 332);
            this.jsPanelMenuHome.TabIndex = 1001;
            // 
            // jsMenuStripStoreManagement1
            // 
            this.jsMenuStripStoreManagement1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.jsMenuStripStoreManagement1.BackColor = System.Drawing.Color.Transparent;
            this.jsMenuStripStoreManagement1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsMenuStripStoreManagement1.Location = new System.Drawing.Point(0, 0);
            this.jsMenuStripStoreManagement1.MaximumSize = new System.Drawing.Size(80, 0);
            this.jsMenuStripStoreManagement1.MinimumSize = new System.Drawing.Size(75, 250);
            this.jsMenuStripStoreManagement1.Name = "jsMenuStripStoreManagement1";
            this.jsMenuStripStoreManagement1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsMenuStripStoreManagement1.Size = new System.Drawing.Size(75, 332);
            this.jsMenuStripStoreManagement1.TabIndex = 0;
            // 
            // jS7Btn2
            // 
            this.jS7Btn2.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Add;
            this.jS7Btn2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn2.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn2.ButtonText = "اضافه کردن";
            this.jS7Btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn2.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn2.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn2.Image")));
            this.jS7Btn2.Location = new System.Drawing.Point(16, 16);
            this.jS7Btn2.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn2.MinimumSize = new System.Drawing.Size(70, 30);
            this.jS7Btn2.Name = "jS7Btn2";
            this.jS7Btn2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn2.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn2.TabIndex = 1002;
            this.jS7Btn2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn2.UseVisualStyleBackColor = false;
            this.jS7Btn2.Click += new System.EventHandler(this.JS7Btn2Click);
            // 
            // jS7Btn4
            // 
            this.jS7Btn4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn4.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn4.ButtonText = "تنظیمات";
            this.jS7Btn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn4.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn4.Location = new System.Drawing.Point(379, 16);
            this.jS7Btn4.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn4.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn4.Name = "jS7Btn4";
            this.jS7Btn4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn4.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn4.TabIndex = 1004;
            this.jS7Btn4.Text = "jS7Btn4";
            this.jS7Btn4.UseVisualStyleBackColor = false;
            this.jS7Btn4.Click += new System.EventHandler(this.JS7Btn4Click);
            // 
            // jS7Btn5
            // 
            this.jS7Btn5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn5.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn5.ButtonText = "دسته ها";
            this.jS7Btn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn5.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn5.Location = new System.Drawing.Point(379, 70);
            this.jS7Btn5.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn5.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn5.Name = "jS7Btn5";
            this.jS7Btn5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn5.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn5.TabIndex = 1005;
            this.jS7Btn5.UseVisualStyleBackColor = false;
            this.jS7Btn5.Click += new System.EventHandler(this.JS7Btn5Click);
            // 
            // jS7Btn1
            // 
            this.jS7Btn1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn1.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn1.ButtonText = "مشتریان";
            this.jS7Btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn1.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn1.Location = new System.Drawing.Point(379, 121);
            this.jS7Btn1.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn1.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn1.Name = "jS7Btn1";
            this.jS7Btn1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn1.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn1.TabIndex = 1006;
            this.jS7Btn1.UseVisualStyleBackColor = false;
            this.jS7Btn1.Click += new System.EventHandler(this.JS7Btn1Click);
            // 
            // jS7Btn3
            // 
            this.jS7Btn3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn3.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn3.ButtonText = "واحد شمارش کالا";
            this.jS7Btn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn3.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn3.Location = new System.Drawing.Point(379, 172);
            this.jS7Btn3.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn3.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn3.Name = "jS7Btn3";
            this.jS7Btn3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn3.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn3.TabIndex = 1007;
            this.jS7Btn3.Text = "jS7Btn3";
            this.jS7Btn3.UseVisualStyleBackColor = false;
            this.jS7Btn3.Click += new System.EventHandler(this.JS7Btn3Click);
            // 
            // jS7Btn6
            // 
            this.jS7Btn6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn6.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn6.ButtonText = "توزیع کنندگان";
            this.jS7Btn6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn6.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn6.Location = new System.Drawing.Point(379, 223);
            this.jS7Btn6.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn6.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn6.Name = "jS7Btn6";
            this.jS7Btn6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn6.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn6.TabIndex = 1008;
            this.jS7Btn6.Text = "jS7Btn6";
            this.jS7Btn6.UseVisualStyleBackColor = false;
            this.jS7Btn6.Click += new System.EventHandler(this.JS7Btn6Click);
            // 
            // jS7Btn7
            // 
            this.jS7Btn7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn7.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn7.ButtonText = "کالاها";
            this.jS7Btn7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn7.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn7.Location = new System.Drawing.Point(245, 70);
            this.jS7Btn7.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn7.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn7.Name = "jS7Btn7";
            this.jS7Btn7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn7.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn7.TabIndex = 1009;
            this.jS7Btn7.Text = "jS7Btn7";
            this.jS7Btn7.UseVisualStyleBackColor = false;
            this.jS7Btn7.Click += new System.EventHandler(this.JS7Btn7Click);
            // 
            // FrmHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(584, 332);
            this.Controls.Add(this.jS7Btn7);
            this.Controls.Add(this.jS7Btn6);
            this.Controls.Add(this.jS7Btn3);
            this.Controls.Add(this.jS7Btn1);
            this.Controls.Add(this.jS7Btn5);
            this.Controls.Add(this.jS7Btn4);
            this.Controls.Add(this.jS7Btn2);
            this.Controls.Add(this.jsPanelMenuHome);
            this.Name = "FrmHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "سامانه مدیریت فروشگاه | صفحه اصلی";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmHomeFormClosing);
            this.jsPanelMenuHome.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSPanel jsPanelMenuHome;
        private Requirement.JSMenuStripStoreManagement jsMenuStripStoreManagement1;
        private JSRequirement.Controls.JS7Btn jS7Btn2;
        private JSRequirement.Controls.JS7Btn jS7Btn4;
        private JSRequirement.Controls.JS7Btn jS7Btn5;
        private JSRequirement.Controls.JS7Btn jS7Btn1;
        private JSRequirement.Controls.JS7Btn jS7Btn3;
        private JSRequirement.Controls.JS7Btn jS7Btn6;
        private JSRequirement.Controls.JS7Btn jS7Btn7;
    }
}
