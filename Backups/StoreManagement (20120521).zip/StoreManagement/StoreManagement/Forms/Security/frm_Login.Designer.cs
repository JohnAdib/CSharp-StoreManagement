﻿namespace StoreManagement.Forms.Security
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmLogin));
            this.btnSubmit = new JSRequirement.Controls.JS7Btn();
            this.txtPassCode = new JSRequirement.Controls.JSTextBox();
            this.cmbUserCode = new JSRequirement.Controls.JSComboBox();
            this.jscMessage = new JSRequirement.Controls.JSLabel();
            this.jsPictureBox1 = new JSRequirement.Controls.JSPictureBox();
            this.btnQuit = new JSRequirement.Controls.JS7Btn();
            this.jsTimer1 = new JSRequirement.Controls.JSTimer();
            this.jslblAppLoginTryCount = new JSRequirement.Controls.JSLabel();
            this.jslblToday = new JSRequirement.Controls.JSLabel();
            ((System.ComponentModel.ISupportInitialize)(this.jsPictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSubmit
            // 
            this.btnSubmit.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Submit;
            this.btnSubmit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSubmit.BackColor = System.Drawing.Color.Transparent;
            this.btnSubmit.ButtonText = "تایید";
            this.btnSubmit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSubmit.Font = new System.Drawing.Font("B Mitra", 18F);
            this.btnSubmit.Image = ((System.Drawing.Image)(resources.GetObject("btnSubmit.Image")));
            this.btnSubmit.Location = new System.Drawing.Point(202, 369);
            this.btnSubmit.Margin = new System.Windows.Forms.Padding(7);
            this.btnSubmit.MinimumSize = new System.Drawing.Size(120, 40);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnSubmit.Size = new System.Drawing.Size(130, 40);
            this.btnSubmit.TabIndex = 2;
            this.btnSubmit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.BtnSubmitClick);
            // 
            // txtPassCode
            // 
            this.txtPassCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPassCode.BackColor = System.Drawing.Color.GhostWhite;

            this.txtPassCode.Location = new System.Drawing.Point(76, 266);
            this.txtPassCode.MaxLength = 200;
            this.txtPassCode.Name = "txtPassCode";
            this.txtPassCode.PasswordChar = '*';
            this.txtPassCode.PersianText = false;
            this.txtPassCode.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtPassCode.Size = new System.Drawing.Size(242, 33);
            this.txtPassCode.TabIndex = 1;
            this.txtPassCode.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtPassCode.UseSystemPasswordChar = true;
            this.txtPassCode.TextChanged += new System.EventHandler(this.TxtPassCodeTextChanged);
            // 
            // cmbUserCode
            // 
            this.cmbUserCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbUserCode.BackColor = System.Drawing.SystemColors.Window;
            this.cmbUserCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbUserCode.FormattingEnabled = true;
            this.cmbUserCode.Location = new System.Drawing.Point(75, 180);
            this.cmbUserCode.Name = "cmbUserCode";
            this.cmbUserCode.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cmbUserCode.Size = new System.Drawing.Size(243, 33);
            this.cmbUserCode.TabIndex = 0;
            this.cmbUserCode.SelectionChangeCommitted += new System.EventHandler(this.CmbUserCodeSelectionChangeCommitted);
            this.cmbUserCode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.CmbUserCodeKeyDown);
            // 
            // jscMessage
            // 
            this.jscMessage.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscMessage.BackColor = System.Drawing.Color.Transparent;
            this.jscMessage.ForeColor = System.Drawing.Color.Black;
            this.jscMessage.Location = new System.Drawing.Point(24, 321);
            this.jscMessage.Name = "jscMessage";
            this.jscMessage.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscMessage.Size = new System.Drawing.Size(347, 26);
            this.jscMessage.TabIndex = 7;
            this.jscMessage.Text = "طراحی، برنامه نویسی و توسعه توسط جواد عوض زاده";
            this.jscMessage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsPictureBox1
            // 
            this.jsPictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsPictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.jsPictureBox1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("jsPictureBox1.ErrorImage")));
            this.jsPictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("jsPictureBox1.Image")));
            this.jsPictureBox1.InitialImage = ((System.Drawing.Image)(resources.GetObject("jsPictureBox1.InitialImage")));
            this.jsPictureBox1.Location = new System.Drawing.Point(349, 4);
            this.jsPictureBox1.Name = "jsPictureBox1";
            this.jsPictureBox1.Size = new System.Drawing.Size(45, 49);
            this.jsPictureBox1.TabIndex = 8;
            this.jsPictureBox1.TabStop = false;
            this.jsPictureBox1.Click += new System.EventHandler(this.BtnQuitClick);
            // 
            // btnQuit
            // 
            this.btnQuit.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Exit;
            this.btnQuit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnQuit.BackColor = System.Drawing.Color.Transparent;
            this.btnQuit.ButtonText = "خروج";
            this.btnQuit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnQuit.Font = new System.Drawing.Font("B Mitra", 18F);
            this.btnQuit.Image = ((System.Drawing.Image)(resources.GetObject("btnQuit.Image")));
            this.btnQuit.Location = new System.Drawing.Point(58, 369);
            this.btnQuit.Margin = new System.Windows.Forms.Padding(7);
            this.btnQuit.MinimumSize = new System.Drawing.Size(120, 40);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnQuit.Size = new System.Drawing.Size(130, 40);
            this.btnQuit.TabIndex = 10;
            this.btnQuit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnQuit.UseVisualStyleBackColor = false;
            this.btnQuit.Click += new System.EventHandler(this.BtnQuitClick);
            // 
            // jsTimer1
            // 
            this.jsTimer1.Enabled = true;
            this.jsTimer1.MaxTickTimes = 100;
            this.jsTimer1.TickTimes = 0;
            this.jsTimer1.Tick += new System.EventHandler(this.JSTimer1Tick);
            // 
            // jslblAppLoginTryCount
            // 
            this.jslblAppLoginTryCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jslblAppLoginTryCount.BackColor = System.Drawing.Color.Transparent;
            this.jslblAppLoginTryCount.Font = new System.Drawing.Font("B Mitra", 10F);
            this.jslblAppLoginTryCount.Location = new System.Drawing.Point(78, 237);
            this.jslblAppLoginTryCount.Name = "jslblAppLoginTryCount";
            this.jslblAppLoginTryCount.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jslblAppLoginTryCount.Size = new System.Drawing.Size(194, 27);
            this.jslblAppLoginTryCount.TabIndex = 11;
            this.jslblAppLoginTryCount.Text = "(تعداد تلاش های ممکن برای ورود)";
            this.jslblAppLoginTryCount.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // jslblToday
            // 
            this.jslblToday.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jslblToday.BackColor = System.Drawing.Color.Transparent;
            this.jslblToday.Font = new System.Drawing.Font("B Mitra", 11F);
            this.jslblToday.Location = new System.Drawing.Point(23, 23);
            this.jslblToday.Name = "jslblToday";
            this.jslblToday.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jslblToday.Size = new System.Drawing.Size(78, 21);
            this.jslblToday.TabIndex = 12;
            this.jslblToday.Text = "امروز";
            this.jslblToday.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(400, 450);
            this.ControlBox = false;
            this.Controls.Add(this.jslblAppLoginTryCount);
            this.Controls.Add(this.jsPictureBox1);
            this.Controls.Add(this.cmbUserCode);
            this.Controls.Add(this.txtPassCode);
            this.Controls.Add(this.jscMessage);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.jslblToday);
            this.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmLogin";
            this.Opacity = 0.99D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ورود به سامانه";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.FrmLoginMouseDown);
            ((System.ComponentModel.ISupportInitialize)(this.jsPictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private JSRequirement.Controls.JS7Btn btnSubmit;
        private JSRequirement.Controls.JSTextBox txtPassCode;
        private JSRequirement.Controls.JSComboBox cmbUserCode;
        private JSRequirement.Controls.JSLabel jscMessage;
        private JSRequirement.Controls.JSPictureBox jsPictureBox1;
        private JSRequirement.Controls.JS7Btn btnQuit;
        private JSRequirement.Controls.JSTimer jsTimer1;
        private JSRequirement.Controls.JSLabel jslblAppLoginTryCount;
        private JSRequirement.Controls.JSLabel jslblToday;
    }
}