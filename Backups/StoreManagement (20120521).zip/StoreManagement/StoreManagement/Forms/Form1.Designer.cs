﻿namespace StoreManagement.Forms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.jsDataGrid1 = new JSRequirement.Controls.JSDataGrid();
            this.jS7Btn1 = new JSRequirement.Controls.JS7Btn();
            this.jsLabel1 = new JSRequirement.Controls.JSLabel();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // jsDataGrid1
            // 
            this.jsDataGrid1.AllowUserToAddRows = false;
            this.jsDataGrid1.AllowUserToOrderColumns = true;
            this.jsDataGrid1.AllowUserToResizeColumns = false;
            this.jsDataGrid1.AllowUserToResizeRows = false;
            this.jsDataGrid1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsDataGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.jsDataGrid1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.jsDataGrid1.BackgroundColor = System.Drawing.Color.White;
            this.jsDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Mj_Sazeh Light", 12F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.jsDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.jsDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.jsDataGrid1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.jsDataGrid1.GridColor = System.Drawing.SystemColors.Menu;
            this.jsDataGrid1.JSCustomSetting = true;
            this.jsDataGrid1.Location = new System.Drawing.Point(13, 48);
            this.jsDataGrid1.MultiSelect = false;
            this.jsDataGrid1.Name = "jsDataGrid1";
            this.jsDataGrid1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsDataGrid1.RowHeadersVisible = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleRight;
            this.jsDataGrid1.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.jsDataGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.jsDataGrid1.Size = new System.Drawing.Size(490, 104);
            this.jsDataGrid1.TabIndex = 2;
            // 
            // jS7Btn1
            // 
            this.jS7Btn1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn1.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn1.ButtonText = null;
            this.jS7Btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn1.Font = new System.Drawing.Font("Far.Dast Nevis", 15F);
            this.jS7Btn1.Location = new System.Drawing.Point(13, 159);
            this.jS7Btn1.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn1.MinimumSize = new System.Drawing.Size(70, 30);
            this.jS7Btn1.Name = "jS7Btn1";
            this.jS7Btn1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn1.Size = new System.Drawing.Size(70, 30);
            this.jS7Btn1.TabIndex = 3;
            this.jS7Btn1.Text = "jS7Btn1";
            this.jS7Btn1.UseVisualStyleBackColor = false;
            this.jS7Btn1.Click += new System.EventHandler(this.JS7Btn1Click);
            // 
            // jsLabel1
            // 
            this.jsLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel1.AutoSize = true;
            this.jsLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel1.Location = new System.Drawing.Point(217, 175);
            this.jsLabel1.Name = "jsLabel1";
            this.jsLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel1.Size = new System.Drawing.Size(79, 26);
            this.jsLabel1.TabIndex = 4;
            this.jsLabel1.Text = "jsLabel1";
            this.jsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(293, 159);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(210, 161);
            this.richTextBox1.TabIndex = 5;
            this.richTextBox1.Text = "";
            this.richTextBox1.TextChanged += new System.EventHandler(this.richTextBox1_TextChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(584, 332);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.jsLabel1);
            this.Controls.Add(this.jS7Btn1);
            this.Controls.Add(this.jsDataGrid1);
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1Load);
            this.Controls.SetChildIndex(this.jsDataGrid1, 0);
            this.Controls.SetChildIndex(this.jS7Btn1, 0);
            this.Controls.SetChildIndex(this.jsLabel1, 0);
            this.Controls.SetChildIndex(this.richTextBox1, 0);
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private JSRequirement.Controls.JSDataGrid jsDataGrid1;
        private JSRequirement.Controls.JS7Btn jS7Btn1;
        private JSRequirement.Controls.JSLabel jsLabel1;
        private System.Windows.Forms.RichTextBox richTextBox1;

    }
}
