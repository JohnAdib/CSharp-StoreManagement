﻿using System;


namespace StoreManagement.Forms
{
    public partial class Form1 : Requirement.JSfrmBase
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1Load(object sender, EventArgs e)
        {
            jsDataGrid1.AutoGenerateColumns = true;
            jsDataGrid1.DataSource = new Requirement.SMLinqDataContext().tbl_SM_ProductsCategories;

            {
                
            }
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {
            richTextBox1.Text= JSRequirement.Codes.ToWords.ToString(200)
                + Environment.NewLine + JSRequirement.Codes.ToWords.ToString(2000)
                + Environment.NewLine + JSRequirement.Codes.ToWords.ToString(30000)
                + Environment.NewLine + JSRequirement.Codes.ToWords.ToString(400000)
                + Environment.NewLine + JSRequirement.Codes.ToWords.ToString(5000000)
                + Environment.NewLine + JSRequirement.Codes.ToWords.ToString(60000000)
                + Environment.NewLine + JSRequirement.Codes.ToWords.ToString(700000000)
                + Environment.NewLine + JSRequirement.Codes.ToWords.ToString(1386)
                ;
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
