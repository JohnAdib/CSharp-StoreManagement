﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace StoreManagement.Forms.frm_Customer
{
    public partial class FrmCustomer : Requirement.JSfrmBase
    {
        public FrmCustomer()
        {
            InitializeComponent();
            UpdateDateGrid();
        }
        public void UpdateDateGrid()
        {
            jsDataGrid1.DataSource = new Requirement.SMLinqDataContext().tbl_SM_Customers;
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {
            new FrmCustomerAdd().ShowDialog();
            UpdateDateGrid();
        }

        private void JS7Btn2Click(object sender, EventArgs e)
        {
            try
            {

                if (jsDataGrid1.CurrentRow == null)
                    return;
                new FrmCustomerEdit(
                    Convert.ToInt16(jsDataGrid1.CurrentRow.Cells["CustomerID"].Value),
                    jsDataGrid1.CurrentRow.Cells["CName"].Value.ToString(),
                    jsDataGrid1.CurrentRow.Cells["Address"].Value.ToString(),
                    jsDataGrid1.CurrentRow.Cells["Tel"].Value.ToString(),
                    jsDataGrid1.CurrentRow.Cells["Mobile"].Value.ToString(),
                    Convert.ToBoolean(jsDataGrid1.CurrentRow.Cells["CreditSaleAccess"].Value.ToString())
                    ).ShowDialog();
                UpdateDateGrid();
            }
            catch
            {
                MessageBox.Show(@"خطایی در ویرایش رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void JS7Btn3Click(object sender, EventArgs e)
        {
            try
            {
                if (jsDataGrid1.CurrentRow == null)
                    return;

                var cid = Convert.ToInt16(jsDataGrid1.CurrentRow.Cells["CustomerID"].Value);
                if (new Requirement.SMLinqDataContext().tbl_SM_Sales.Where(c => c.CustomerID == cid).Count() > 0)
                {
                    MessageBox.Show(@"این مشتری از ما خرید داشته است" + Environment.NewLine
                                    + @"برای حذف واحد ابتدا فروش های مربوط به این مشتری را پاک نمایید",
                                    @"توجه"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }

                if (
                    MessageBox.Show(Properties.Settings.Default.AppMsgDelete, @"حذف", MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Question) == DialogResult.No)
                    return;

                new Requirement.SMLinqDataContext().JSP_SM_Customers_Delete(cid);
                UpdateDateGrid();
            }
            catch
            {
                MessageBox.Show(@"خطایی در حذف رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void JS7Btn4Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
