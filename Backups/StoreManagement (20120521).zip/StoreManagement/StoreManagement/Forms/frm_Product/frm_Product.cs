﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace StoreManagement.Forms.frm_Product
{
    public partial class FrmProduct : Requirement.JSfrmBase
    {
        public FrmProduct()
        {
            InitializeComponent();
            UpdateDateGrid();
        }

        public void UpdateDateGrid()
        {
            jsDataGrid1.DataSource = new Requirement.SMLinqDataContext().tbl_SM_Products;
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {
            new FrmProductAdd().ShowDialog();
            UpdateDateGrid();
        }

        private void JS7Btn2Click(object sender, EventArgs e)
        {
            UpdateDateGrid();
        }

        private void JS7Btn3Click(object sender, EventArgs e)
        {
            try
            {
                if (jsDataGrid1.CurrentRow == null)
                    return;

                var pid = Convert.ToInt16(jsDataGrid1.CurrentRow.Cells["ProductID"].Value);
                if (new Requirement.SMLinqDataContext().tbl_SM_SalesDetails.Where(c => c.ProductID == pid).Count() > 0)
                {
                    MessageBox.Show(@"از این کالا فروخته ایم!" + Environment.NewLine
                                    + @"برای حذف واحد ابتدا فروش های مربوط به این کالا را پاک نمایید",
                                    @"توجه"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }

                if (
                    MessageBox.Show(Properties.Settings.Default.AppMsgDelete, @"حذف", MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Question) ==DialogResult.No)
                    return;

                new Requirement.SMLinqDataContext().JSP_SM_Products_Delete(pid);
                UpdateDateGrid();
            }
            catch
            {
                MessageBox.Show(@"خطایی در حذف رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void JS7Btn4Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
