﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace StoreManagement.Forms.frm_Product
{
    public partial class FrmProductAdd : Requirement.FrmPopup
    {
        public FrmProductAdd()
        {
            InitializeComponent();

            jsCmbCategory.DataSource = new Requirement.SMLinqDataContext().tbl_SM_ProductsCategories;
            jsCmbCategory.DisplayMember = "ProductCategory";
            jsCmbCategory.ValueMember = "ProductCategoryID";

            jsCmbUnit.DataSource = new Requirement.SMLinqDataContext().tbl_SM_ProductsUnits;
            jsCmbUnit.DisplayMember = "ProductsUnit";
            jsCmbUnit.ValueMember = "ProductsUnitID";
        }

        private void JS7Btn2Click(object sender, EventArgs e)
        {
            Close();
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {

            if (jstxtName.Text == "" || jstxtBuyPrice.Text == "" || jstxtPrice.Text == "") 
            {
                jstxtName.BackColor = Color.Red;
                jstxtBuyPrice.BackColor = Color.Red;
                jstxtPrice.BackColor = Color.Red;
                return;
            }

            new Requirement.SMLinqDataContext().JSP_SM_Products_Add(jstxtName.Text,
                                                                    jsCmbCategory.SValue,
                                                                    jsCmbUnit.SValueByte, jstxtsize.Num32,
                                                                    jsBarCodeBox1.Text, jsBarCodeBox1.Text,
                                                                    jstxtStock.NumDouble, 0, jstxtMinInventory.NumDouble,
                                                                    jstxtBuyPrice.Num32,
                                                                    jstxtPrice.Num32, jstxtDiscount.Num32, DateTime.Now);
            
            Close();
        }

        private void JSBarCodeBox1Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {

        }

        private void JSCmbBarcodeTypeValueMemberChanged(object sender, EventArgs e)
        {
        }

        private void JSCmbBarcodeTypeSelectedIndexChanged(object sender, EventArgs e)
        {
            MessageBox.Show(jsCmbBarcodeType.SValue.ToString() + Environment.NewLine
                + jsCmbBarcodeType.SelectedItem + Environment.NewLine
                + jsCmbBarcodeType.SelectedText + Environment.NewLine
                + jsCmbBarcodeType.SelectedValue);
            
        }

        private bool _isBarCode;
        private string _barcode = "";
        private void FrmProductAddKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '$')
            {
                try
                {
                    var elanguage = new System.Globalization.CultureInfo("en-us");
                    InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(elanguage);
                }
                catch (Exception) { return; }

                _isBarCode = !_isBarCode;
                e.Handled = true;
                if (!_isBarCode)
                {
                    if (_barcode.Length > 7)
                    {
                        if (jsCmbBarcodeType.SValue == 1)
                            jsBarCodeBox1.Text = _barcode;
                        else
                            jsBarCodeBox2.Text = _barcode;
                    }
                    _barcode = string.Empty;
                    try
                    {
                        var flanguage = new System.Globalization.CultureInfo("fa-ir");
                        InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(flanguage);
                    }
                    catch (Exception) { return; }
                }
            }
            else if (_isBarCode)
            {

                _barcode += e.KeyChar;
                e.Handled = true;
            }

        }

        private void JSLabel7Click(object sender, EventArgs e)
        {
            jsBarCodeBox1.Text = string.Empty;

        }

        private void JslblBarcodeClick(object sender, EventArgs e)
        {
            jsBarCodeBox2.Text = string.Empty;
        }

        private void JSBarCodeBox1TextChanged(object sender, EventArgs e)
        {

        }

        private void JSBarCodeBox2TextChanged(object sender, EventArgs e)
        {

        }
    }
}
