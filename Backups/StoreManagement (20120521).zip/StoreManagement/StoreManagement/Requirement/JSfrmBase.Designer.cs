﻿namespace StoreManagement.Requirement
{
    partial class JSfrmBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jsPanelMenu = new JSRequirement.Controls.JSPanel();
            this.jsMenuStripStoreManagement1 = new StoreManagement.Requirement.JSMenuStripStoreManagement();
            this.jsPanelMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsPanelMenu
            // 
            this.jsPanelMenu.BackColor = System.Drawing.Color.Transparent;
            this.jsPanelMenu.Controls.Add(this.jsMenuStripStoreManagement1);
            this.jsPanelMenu.Dock = System.Windows.Forms.DockStyle.Right;
            this.jsPanelMenu.Location = new System.Drawing.Point(509, 0);
            this.jsPanelMenu.Name = "jsPanelMenu";
            this.jsPanelMenu.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanelMenu.Size = new System.Drawing.Size(75, 332);
            this.jsPanelMenu.TabIndex = 1;
            // 
            // jsMenuStripStoreManagement1
            // 
            this.jsMenuStripStoreManagement1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.jsMenuStripStoreManagement1.BackColor = System.Drawing.Color.Transparent;
            this.jsMenuStripStoreManagement1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsMenuStripStoreManagement1.Location = new System.Drawing.Point(0, 0);
            this.jsMenuStripStoreManagement1.MaximumSize = new System.Drawing.Size(80, 0);
            this.jsMenuStripStoreManagement1.MinimumSize = new System.Drawing.Size(75, 250);
            this.jsMenuStripStoreManagement1.Name = "jsMenuStripStoreManagement1";
            this.jsMenuStripStoreManagement1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsMenuStripStoreManagement1.Size = new System.Drawing.Size(75, 332);
            this.jsMenuStripStoreManagement1.TabIndex = 0;
            // 
            // JSfrmBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(584, 332);
            this.Controls.Add(this.jsPanelMenu);
            this.Name = "JSfrmBase";
            this.jsPanelMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSPanel jsPanelMenu;
        private JSMenuStripStoreManagement jsMenuStripStoreManagement1;

    }
}
