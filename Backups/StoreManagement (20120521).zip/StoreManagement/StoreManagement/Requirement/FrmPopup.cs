﻿namespace StoreManagement.Requirement
{
    public partial class FrmPopup : JSRequirement.Forms.JSBaseForm
    {
        public FrmPopup()
        {
            InitializeComponent();
        }
    }
}
