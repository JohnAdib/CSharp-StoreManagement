﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace StoreManagement.Requirement
{
    public partial class JSfrmBase : JSRequirement.Forms.JSBaseForm
    {
        public JSfrmBase()
        {
            InitializeComponent();
            jsMenuStripStoreManagement1.ParentForm = this;
            BringToFront();
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            try
            {
                if (Owner != null) Owner.Hide();
                if (!DesignMode) CenterForm();

                Activate();
                BringToFront();
                Focus();
            }
            catch{return;}
        }
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            try
            {
                if (Forms.FrmHome.Instance != null && !Forms.FrmHome.Instance.Visible)
                {
                    Forms.FrmHome.Instance.Visible = false;
                    Forms.FrmHome.Instance.Show();
                }
            }
            catch{return;}
        }
        private void CenterForm()
        {
            var center = new Point
            {
                X = (Screen.PrimaryScreen.WorkingArea.Width - Width) / 2,
                Y = (Screen.PrimaryScreen.WorkingArea.Height - Height) / 2
            };

            Location = center;
        }

        private string _frmTitle;
        /// <summary>
        /// current form title for showing on title bar.
        /// </summary>
        [Category("JSCustomizer"),
         Description("The text that is displayed on form title bar.")]
        public string FormTitle
        {
            get { return _frmTitle; }
            set
            {
                try
                {
                    _frmTitle = value;
                    Invalidate();
                    var appPreName = Properties.Settings.Default.AppNamePre + @" " + Properties.Settings.Default.AppName;
                    
                    if(_frmTitle.Length < 3)
                    {
                        base.Text = appPreName;
                    }
                    else
                    {
                        base.Text = appPreName + @" | " + _frmTitle;
                    }
                }
                catch
                {
                    return;
                }
            }
        }
    }
}