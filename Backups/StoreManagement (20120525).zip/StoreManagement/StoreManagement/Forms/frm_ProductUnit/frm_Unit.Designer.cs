﻿namespace StoreManagement.Forms.frm_ProductUnit
{
    partial class FrmUnit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmUnit));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.jsPanel1 = new JSRequirement.Controls.JSPanel();
            this.jS7Btn4 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn3 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn2 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn1 = new JSRequirement.Controls.JS7Btn();
            this.jsPanel2 = new JSRequirement.Controls.JSPanel();
            this.jsDataGrid1 = new JSRequirement.Controls.JSDataGrid();
            this.ProductsUnitID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductsUnit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jsPanel1.SuspendLayout();
            this.jsPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // jsPanel1
            // 
            this.jsPanel1.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel1.Controls.Add(this.jS7Btn4);
            this.jsPanel1.Controls.Add(this.jS7Btn3);
            this.jsPanel1.Controls.Add(this.jS7Btn2);
            this.jsPanel1.Controls.Add(this.jS7Btn1);
            this.jsPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.jsPanel1.Location = new System.Drawing.Point(0, 0);
            this.jsPanel1.Name = "jsPanel1";
            this.jsPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel1.Size = new System.Drawing.Size(142, 262);
            this.jsPanel1.TabIndex = 2;
            // 
            // jS7Btn4
            // 
            this.jS7Btn4.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Home;
            this.jS7Btn4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn4.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn4.ButtonText = "بازگشت";
            this.jS7Btn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn4.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn4.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn4.Image")));
            this.jS7Btn4.Location = new System.Drawing.Point(12, 206);
            this.jS7Btn4.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn4.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn4.Name = "jS7Btn4";
            this.jS7Btn4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn4.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn4.TabIndex = 3;
            this.jS7Btn4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn4.UseVisualStyleBackColor = false;
            this.jS7Btn4.Click += new System.EventHandler(this.JS7Btn4Click);
            // 
            // jS7Btn3
            // 
            this.jS7Btn3.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Delete;
            this.jS7Btn3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn3.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn3.ButtonText = "حذف";
            this.jS7Btn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn3.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn3.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn3.Image")));
            this.jS7Btn3.Location = new System.Drawing.Point(12, 152);
            this.jS7Btn3.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn3.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn3.Name = "jS7Btn3";
            this.jS7Btn3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn3.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn3.TabIndex = 2;
            this.jS7Btn3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn3.UseVisualStyleBackColor = false;
            this.jS7Btn3.Click += new System.EventHandler(this.JS7Btn3Click);
            // 
            // jS7Btn2
            // 
            this.jS7Btn2.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Update;
            this.jS7Btn2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn2.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn2.ButtonText = "به روز رسانی";
            this.jS7Btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn2.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn2.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn2.Image")));
            this.jS7Btn2.Location = new System.Drawing.Point(12, 98);
            this.jS7Btn2.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn2.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn2.Name = "jS7Btn2";
            this.jS7Btn2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn2.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn2.TabIndex = 1;
            this.jS7Btn2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn2.UseVisualStyleBackColor = false;
            this.jS7Btn2.Click += new System.EventHandler(this.JS7Btn2Click);
            // 
            // jS7Btn1
            // 
            this.jS7Btn1.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Add;
            this.jS7Btn1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn1.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn1.ButtonText = "اضافه کردن";
            this.jS7Btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn1.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn1.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn1.Image")));
            this.jS7Btn1.Location = new System.Drawing.Point(12, 44);
            this.jS7Btn1.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn1.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn1.Name = "jS7Btn1";
            this.jS7Btn1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn1.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn1.TabIndex = 0;
            this.jS7Btn1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn1.UseVisualStyleBackColor = false;
            this.jS7Btn1.Click += new System.EventHandler(this.JS7Btn1Click);
            // 
            // jsPanel2
            // 
            this.jsPanel2.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel2.Controls.Add(this.jsDataGrid1);
            this.jsPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsPanel2.Location = new System.Drawing.Point(142, 0);
            this.jsPanel2.Name = "jsPanel2";
            this.jsPanel2.Padding = new System.Windows.Forms.Padding(3);
            this.jsPanel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel2.Size = new System.Drawing.Size(329, 262);
            this.jsPanel2.TabIndex = 3;
            // 
            // jsDataGrid1
            // 
            this.jsDataGrid1.AllowUserToAddRows = false;
            this.jsDataGrid1.AllowUserToDeleteRows = false;
            this.jsDataGrid1.AllowUserToOrderColumns = true;
            this.jsDataGrid1.AllowUserToResizeColumns = false;
            this.jsDataGrid1.AllowUserToResizeRows = false;
            this.jsDataGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.jsDataGrid1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.jsDataGrid1.BackgroundColor = System.Drawing.Color.White;
            this.jsDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("B Mitra", 12F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.jsDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.jsDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.jsDataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductsUnitID,
            this.ProductsUnit});
            this.jsDataGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsDataGrid1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.jsDataGrid1.GridColor = System.Drawing.SystemColors.Menu;
            this.jsDataGrid1.JSCustomSetting = true;
            this.jsDataGrid1.Location = new System.Drawing.Point(3, 3);
            this.jsDataGrid1.MultiSelect = false;
            this.jsDataGrid1.Name = "jsDataGrid1";
            this.jsDataGrid1.ReadOnly = true;
            this.jsDataGrid1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsDataGrid1.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.jsDataGrid1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.jsDataGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.jsDataGrid1.Size = new System.Drawing.Size(323, 256);
            this.jsDataGrid1.TabIndex = 0;
            // 
            // ProductsUnitID
            // 
            this.ProductsUnitID.DataPropertyName = "ProductsUnitID";
            this.ProductsUnitID.HeaderText = "کد واحد شمارش";
            this.ProductsUnitID.Name = "ProductsUnitID";
            this.ProductsUnitID.ReadOnly = true;
            this.ProductsUnitID.Visible = false;
            // 
            // ProductsUnit
            // 
            this.ProductsUnit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProductsUnit.DataPropertyName = "ProductsUnit";
            this.ProductsUnit.HeaderText = "واحد شمارش کالا";
            this.ProductsUnit.Name = "ProductsUnit";
            this.ProductsUnit.ReadOnly = true;
            // 
            // FrmUnit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(546, 262);
            this.Controls.Add(this.jsPanel2);
            this.Controls.Add(this.jsPanel1);
            this.FormTitle = "واحد شمارش کالا";
            this.Name = "FrmUnit";
            this.Text = "سامانه مدیریت فروشگاه | واحد شمارش کالا";
            this.Controls.SetChildIndex(this.jsPanel1, 0);
            this.Controls.SetChildIndex(this.jsPanel2, 0);
            this.jsPanel1.ResumeLayout(false);
            this.jsPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSPanel jsPanel1;
        private JSRequirement.Controls.JSPanel jsPanel2;
        private JSRequirement.Controls.JSDataGrid jsDataGrid1;
        private JSRequirement.Controls.JS7Btn jS7Btn4;
        private JSRequirement.Controls.JS7Btn jS7Btn3;
        private JSRequirement.Controls.JS7Btn jS7Btn2;
        private JSRequirement.Controls.JS7Btn jS7Btn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductsUnitID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductsUnit;
    }
}
