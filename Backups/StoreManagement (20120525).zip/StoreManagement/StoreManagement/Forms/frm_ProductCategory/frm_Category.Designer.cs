﻿namespace StoreManagement.Forms.frm_ProductCategory
{
    partial class FrmCategory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCategory));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.jsPanel1 = new JSRequirement.Controls.JSPanel();
            this.jS7BtnHome = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnDel = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnUpdate = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnAdd = new JSRequirement.Controls.JS7Btn();
            this.jsPanel2 = new JSRequirement.Controls.JSPanel();
            this.jsPanel4 = new JSRequirement.Controls.JSPanel();
            this.jsDataGrid1 = new JSRequirement.Controls.JSDataGrid();
            this.ProductCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCategoryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jsPanel1.SuspendLayout();
            this.jsPanel2.SuspendLayout();
            this.jsPanel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // jsPanel1
            // 
            this.jsPanel1.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel1.Controls.Add(this.jS7BtnHome);
            this.jsPanel1.Controls.Add(this.jS7BtnDel);
            this.jsPanel1.Controls.Add(this.jS7BtnUpdate);
            this.jsPanel1.Controls.Add(this.jS7BtnAdd);
            this.jsPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.jsPanel1.Location = new System.Drawing.Point(0, 0);
            this.jsPanel1.Name = "jsPanel1";
            this.jsPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel1.Size = new System.Drawing.Size(141, 262);
            this.jsPanel1.TabIndex = 2;
            // 
            // jS7BtnHome
            // 
            this.jS7BtnHome.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Home;
            this.jS7BtnHome.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnHome.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnHome.ButtonText = "بازگشت";
            this.jS7BtnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnHome.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnHome.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnHome.Image")));
            this.jS7BtnHome.Location = new System.Drawing.Point(11, 206);
            this.jS7BtnHome.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnHome.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnHome.Name = "jS7BtnHome";
            this.jS7BtnHome.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnHome.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnHome.TabIndex = 8;
            this.jS7BtnHome.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnHome.UseVisualStyleBackColor = false;
            this.jS7BtnHome.Click += new System.EventHandler(this.JS7BtnHomeClick);
            // 
            // jS7BtnDel
            // 
            this.jS7BtnDel.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Delete;
            this.jS7BtnDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnDel.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnDel.ButtonText = "حذف";
            this.jS7BtnDel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnDel.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnDel.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnDel.Image")));
            this.jS7BtnDel.Location = new System.Drawing.Point(11, 152);
            this.jS7BtnDel.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnDel.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnDel.Name = "jS7BtnDel";
            this.jS7BtnDel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnDel.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnDel.TabIndex = 7;
            this.jS7BtnDel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnDel.UseVisualStyleBackColor = false;
            this.jS7BtnDel.Click += new System.EventHandler(this.JS7BtnDelClick);
            // 
            // jS7BtnUpdate
            // 
            this.jS7BtnUpdate.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Update;
            this.jS7BtnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnUpdate.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnUpdate.ButtonText = "به روز رسانی";
            this.jS7BtnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnUpdate.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnUpdate.Image")));
            this.jS7BtnUpdate.Location = new System.Drawing.Point(11, 98);
            this.jS7BtnUpdate.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnUpdate.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnUpdate.Name = "jS7BtnUpdate";
            this.jS7BtnUpdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnUpdate.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnUpdate.TabIndex = 6;
            this.jS7BtnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnUpdate.UseVisualStyleBackColor = false;
            this.jS7BtnUpdate.Click += new System.EventHandler(this.JS7BtnUpdateClick);
            // 
            // jS7BtnAdd
            // 
            this.jS7BtnAdd.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Add;
            this.jS7BtnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnAdd.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnAdd.ButtonText = "اضافه کردن";
            this.jS7BtnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnAdd.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnAdd.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnAdd.Image")));
            this.jS7BtnAdd.Location = new System.Drawing.Point(11, 44);
            this.jS7BtnAdd.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnAdd.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnAdd.Name = "jS7BtnAdd";
            this.jS7BtnAdd.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnAdd.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnAdd.TabIndex = 5;
            this.jS7BtnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnAdd.UseVisualStyleBackColor = false;
            this.jS7BtnAdd.Click += new System.EventHandler(this.JS7BtnAddClick);
            // 
            // jsPanel2
            // 
            this.jsPanel2.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel2.Controls.Add(this.jsPanel4);
            this.jsPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsPanel2.Location = new System.Drawing.Point(141, 0);
            this.jsPanel2.Name = "jsPanel2";
            this.jsPanel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel2.Size = new System.Drawing.Size(326, 262);
            this.jsPanel2.TabIndex = 3;
            // 
            // jsPanel4
            // 
            this.jsPanel4.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel4.Controls.Add(this.jsDataGrid1);
            this.jsPanel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsPanel4.Location = new System.Drawing.Point(0, 0);
            this.jsPanel4.Name = "jsPanel4";
            this.jsPanel4.Padding = new System.Windows.Forms.Padding(3);
            this.jsPanel4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel4.Size = new System.Drawing.Size(326, 262);
            this.jsPanel4.TabIndex = 2;
            // 
            // jsDataGrid1
            // 
            this.jsDataGrid1.AllowUserToAddRows = false;
            this.jsDataGrid1.AllowUserToDeleteRows = false;
            this.jsDataGrid1.AllowUserToOrderColumns = true;
            this.jsDataGrid1.AllowUserToResizeColumns = false;
            this.jsDataGrid1.AllowUserToResizeRows = false;
            this.jsDataGrid1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.jsDataGrid1.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.jsDataGrid1.BackgroundColor = System.Drawing.Color.White;
            this.jsDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("B Mitra", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.jsDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.jsDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.jsDataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductCategory,
            this.ProductCategoryID});
            this.jsDataGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsDataGrid1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.jsDataGrid1.GridColor = System.Drawing.SystemColors.Menu;
            this.jsDataGrid1.JSCustomSetting = true;
            this.jsDataGrid1.Location = new System.Drawing.Point(3, 3);
            this.jsDataGrid1.MultiSelect = false;
            this.jsDataGrid1.Name = "jsDataGrid1";
            this.jsDataGrid1.ReadOnly = true;
            this.jsDataGrid1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsDataGrid1.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.BottomLeft;
            this.jsDataGrid1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.jsDataGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.jsDataGrid1.Size = new System.Drawing.Size(320, 256);
            this.jsDataGrid1.TabIndex = 0;
            // 
            // ProductCategory
            // 
            this.ProductCategory.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ProductCategory.DataPropertyName = "ProductCategory";
            this.ProductCategory.HeaderText = "دسته بندی";
            this.ProductCategory.Name = "ProductCategory";
            this.ProductCategory.ReadOnly = true;
            // 
            // ProductCategoryID
            // 
            this.ProductCategoryID.DataPropertyName = "ProductCategoryID";
            this.ProductCategoryID.HeaderText = "کد دسته بندی";
            this.ProductCategoryID.Name = "ProductCategoryID";
            this.ProductCategoryID.ReadOnly = true;
            this.ProductCategoryID.Visible = false;
            // 
            // FrmCategory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(542, 262);
            this.Controls.Add(this.jsPanel2);
            this.Controls.Add(this.jsPanel1);
            this.Font = new System.Drawing.Font("B Mitra", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.FormTitle = "دسته بندی محصولات";
            this.Name = "FrmCategory";
            this.Text = "سامانه مدیریت فروشگاه | دسته بندی محصولات";
            this.Controls.SetChildIndex(this.jsPanel1, 0);
            this.Controls.SetChildIndex(this.jsPanel2, 0);
            this.jsPanel1.ResumeLayout(false);
            this.jsPanel2.ResumeLayout(false);
            this.jsPanel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSPanel jsPanel1;
        private JSRequirement.Controls.JSPanel jsPanel2;
        private JSRequirement.Controls.JSDataGrid jsDataGrid1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCategoryID;
        private JSRequirement.Controls.JSPanel jsPanel4;
        private JSRequirement.Controls.JS7Btn jS7BtnHome;
        private JSRequirement.Controls.JS7Btn jS7BtnDel;
        private JSRequirement.Controls.JS7Btn jS7BtnUpdate;
        private JSRequirement.Controls.JS7Btn jS7BtnAdd;
    }
}
