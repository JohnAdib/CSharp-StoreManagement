﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace StoreManagement.Forms.frm_Sale
{
    public partial class frm_Sale_Add : StoreManagement.Requirement.JSfrmBase
    {
        public frm_Sale_Add()
        {
            InitializeComponent();
        }
    }
}
