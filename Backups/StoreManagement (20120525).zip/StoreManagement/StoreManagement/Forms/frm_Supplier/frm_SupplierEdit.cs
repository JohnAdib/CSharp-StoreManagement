﻿using System;

namespace StoreManagement.Forms.frm_Supplier
{
    public partial class FrmSupplierEdit : Requirement.FrmPopup
    {
        private readonly Int16 _sid;

        public FrmSupplierEdit(Int16 sid, string sName, string sAddress, string sTel, string sDesc, string sVisitor,
                               string sVMobile)
        {
            InitializeComponent();
            _sid = sid;
            jsTxtName.Text = sName;
            jstxtAddress.Text = sAddress;
            jstxtTel.Text = sTel;
            jstxtDesc.Text = sDesc;
            jstxtVisitor.Text = sVisitor;
            jsTxtMobile.Text = sVMobile;
        }

        private void JS7BtnCloseClick(object sender, EventArgs e)
        {
            Close();
        }

        private void JS7BtnAddClick(object sender, EventArgs e)
        {
            new Requirement.SMLinqDataContext()
                .JSP_SM_Suppliers_Edit(_sid, jsTxtName.Text, jstxtAddress.Text, jstxtTel.Text,
                                       jstxtDesc.Text, jstxtVisitor.Text, jsTxtMobile.Text, DateTime.Now);
            Close();
        }

        private void JSTxtNameTextChanged(object sender, EventArgs e)
        {
            jS7BtnAdd.Enabled = !string.IsNullOrWhiteSpace(jsTxtName.Text);
        }
    }
}
