﻿using System;

namespace StoreManagement.Forms.Settings
{
    public partial class FrmAppSettings : Requirement.JSfrmBase
    {
        public FrmAppSettings()
        {
            InitializeComponent();
            try
            {
                jsTxtAppname.Text = Properties.Settings.Default.AppName;
                jsTxtAppLoginTryCount.Text = Properties.Settings.Default.AppLoginTryCount.ToString();
                cmbDefaultUserCode.DataSource = new Requirement.SMLinqDataContext().tbl_DB_Users;
                cmbDefaultUserCode.DisplayMember = "NikName";
                cmbDefaultUserCode.ValueMember = "UserCode";
                cmbDefaultUserCode.SelectedValue = Properties.Settings.Default.AppLoginDefaultUser;

            }
            catch (Exception)
            {
                return;
            }
        }

        private void JS7BtnUpdateClick(object sender, EventArgs e)
        {
            try
            {
                Properties.Settings.Default.AppName = jsTxtAppname.Text;
                Properties.Settings.Default.AppLoginTryCount = jsTxtAppLoginTryCount.NumByte;
                Properties.Settings.Default.AppLoginDefaultUser = cmbDefaultUserCode.SelectedValue.ToString();
                Properties.Settings.Default.Save();
                Close();

            }
            catch (Exception)
            {
                return;
            }
        }

        private void JS7BtnCloseClick(object sender, EventArgs e)
        {
            Close();
        }

    }
}
