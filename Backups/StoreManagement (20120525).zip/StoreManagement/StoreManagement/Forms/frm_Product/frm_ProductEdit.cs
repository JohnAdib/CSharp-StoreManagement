﻿using System;
using System.Windows.Forms;

namespace StoreManagement.Forms.frm_Product
{
    public partial class FrmProductEdit : Requirement.FrmPopup
    {
        private readonly short _pid;
        public FrmProductEdit(DataGridViewRow dataRow)
        {
            InitializeComponent();

            jsCmbCategory.DataSource = new Requirement.SMLinqDataContext().tbl_SM_ProductsCategories;
            jsCmbCategory.DisplayMember = "ProductCategory";
            jsCmbCategory.ValueMember = "ProductCategoryID";

            jsCmbUnit.DataSource = new Requirement.SMLinqDataContext().tbl_SM_ProductsUnits;
            jsCmbUnit.DisplayMember = "ProductsUnit";
            jsCmbUnit.ValueMember = "ProductsUnitID";
            jstxtPrice.Focus();
            try
            {

                for (int i = 0; i < dataRow.Cells.Count; i++)
                {
                    if (dataRow.Cells[i].Value == null)
                        dataRow.Cells[i].Value = string.Empty;
                }


                _pid = Convert.ToInt16(dataRow.Cells["ProductID"].Value);
                jstxtName.Text = dataRow.Cells["PName"].Value.ToString();
                jsCmbCategory.SelectedValue = Convert.ToInt16(dataRow.Cells["ProductCategoryID"].Value);
                jsCmbUnit.SelectedValue = Convert.ToByte(dataRow.Cells["ProductsUnitID"].Value);
                jsBarCodeBox1.Text = dataRow.Cells["PBarCode"].Value.ToString();

                //if (dataRow.Cells["PBarCode2"].Value != DBNull.Value)
                jsBarCodeBox2.Text = dataRow.Cells["PBarCode2"].Value.ToString();

                jstxtsize.NumFloat = Convert.ToSingle(dataRow.Cells["PSize"].Value);
                jstxtStock.NumFloat = Convert.ToSingle(dataRow.Cells["PStock"].Value);
                jstxtMinInventory.NumFloat = Convert.ToSingle(dataRow.Cells["PMinInventory"].Value);
                jstxtBuyPrice.Num32 = Convert.ToInt32(dataRow.Cells["PBuyPrice"].Value);
                jstxtPrice.Num32 = Convert.ToInt32(dataRow.Cells["PPrice"].Value);
                jstxtDiscount.Num32 = Convert.ToInt32(dataRow.Cells["PDiscount"].Value);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,@"خطا در شروع ویرایش");
                return;
            }
        }

        private void JSCmbBarcodeTypeSelectedIndexChanged(object sender, EventArgs e)
        {
            if (jsCmbBarcodeType.SelectedIndex == 1)
                if (string.IsNullOrWhiteSpace(jsBarCodeBox1.Text))
                {
                    if (MessageBox.Show(@"بارکد اصلی وارد نشده، آیا از ورود ایران بارکد اطمینان دارید؟",
                                    @"عدم رعایت ترتیب در ورود بارکد",
                                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    {
                        jsCmbBarcodeType.SelectedIndex = 0;
                    }

                }
        }

        private void JslblBarcodeClick(object sender, EventArgs e)
        {
            jsBarCodeBox1.Text = string.Empty;
        }

        private void JslblBarcode2Click(object sender, EventArgs e)
        {
            jsBarCodeBox2.Text = string.Empty;
        }

        private void FrmProductEditBarcodeTaken(object sender, EventArgs e)
        {
            if (jsCmbBarcodeType.SelectedIndex == 0)
                jsBarCodeBox1.Text = JSBarcode;
            else
                jsBarCodeBox2.Text = JSBarcode;
        }

        private void JS7Btn2Click(object sender, EventArgs e)
        {
            Close();
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {

            new Requirement.SMLinqDataContext().JSP_SM_Products_Edit(_pid, jstxtName.Text
                                                                     , jsCmbCategory.SValue, jsCmbUnit.SValueByte,
                                                                     jsBarCodeBox1.Text, jsBarCodeBox2.Text,
                                                                     jstxtsize.NumDouble, jstxtStock.NumDouble,
                                                                     jstxtMinInventory.NumDouble, jstxtBuyPrice.Num32,
                                                                     jstxtPrice.Num32, jstxtDiscount.Num32, DateTime.Now);


        }
    }
}
