﻿namespace StoreManagement.Forms.frm_Product
{
    partial class FrmProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmProduct));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            this.jsPanel1 = new JSRequirement.Controls.JSPanel();
            this.jS7Btn4 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn3 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn2 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn1 = new JSRequirement.Controls.JS7Btn();
            this.jsPanel2 = new JSRequirement.Controls.JSPanel();
            this.jsDataGrid2 = new JSRequirement.Controls.JSDataGrid();
            this.jsDataGrid1 = new JSRequirement.Controls.JSDataGrid();
            this.ProductID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCategoryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductsUnit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductsUnitID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PBuyPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PStock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PMinInventory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PSold = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PBarCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jsPanel1.SuspendLayout();
            this.jsPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // jsPanel1
            // 
            this.jsPanel1.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel1.Controls.Add(this.jS7Btn4);
            this.jsPanel1.Controls.Add(this.jS7Btn3);
            this.jsPanel1.Controls.Add(this.jS7Btn2);
            this.jsPanel1.Controls.Add(this.jS7Btn1);
            this.jsPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.jsPanel1.Location = new System.Drawing.Point(0, 0);
            this.jsPanel1.Name = "jsPanel1";
            this.jsPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel1.Size = new System.Drawing.Size(140, 332);
            this.jsPanel1.TabIndex = 2;
            // 
            // jS7Btn4
            // 
            this.jS7Btn4.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Home;
            this.jS7Btn4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn4.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn4.ButtonText = "بازگشت";
            this.jS7Btn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn4.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn4.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn4.Image")));
            this.jS7Btn4.Location = new System.Drawing.Point(10, 276);
            this.jS7Btn4.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn4.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn4.Name = "jS7Btn4";
            this.jS7Btn4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn4.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn4.TabIndex = 3;
            this.jS7Btn4.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn4.UseVisualStyleBackColor = false;
            this.jS7Btn4.Click += new System.EventHandler(this.JS7Btn4Click);
            // 
            // jS7Btn3
            // 
            this.jS7Btn3.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Delete;
            this.jS7Btn3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn3.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn3.ButtonText = "حذف";
            this.jS7Btn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn3.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn3.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn3.Image")));
            this.jS7Btn3.Location = new System.Drawing.Point(10, 222);
            this.jS7Btn3.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn3.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn3.Name = "jS7Btn3";
            this.jS7Btn3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn3.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn3.TabIndex = 2;
            this.jS7Btn3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn3.UseVisualStyleBackColor = false;
            this.jS7Btn3.Click += new System.EventHandler(this.JS7Btn3Click);
            // 
            // jS7Btn2
            // 
            this.jS7Btn2.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Update;
            this.jS7Btn2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn2.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn2.ButtonText = "به روز رسانی";
            this.jS7Btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn2.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn2.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn2.Image")));
            this.jS7Btn2.Location = new System.Drawing.Point(10, 168);
            this.jS7Btn2.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn2.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn2.Name = "jS7Btn2";
            this.jS7Btn2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn2.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn2.TabIndex = 1;
            this.jS7Btn2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn2.UseVisualStyleBackColor = false;
            this.jS7Btn2.Click += new System.EventHandler(this.JS7Btn2Click);
            // 
            // jS7Btn1
            // 
            this.jS7Btn1.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Add;
            this.jS7Btn1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn1.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn1.ButtonText = "اضافه کردن";
            this.jS7Btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn1.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn1.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn1.Image")));
            this.jS7Btn1.Location = new System.Drawing.Point(10, 114);
            this.jS7Btn1.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn1.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn1.Name = "jS7Btn1";
            this.jS7Btn1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn1.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn1.TabIndex = 0;
            this.jS7Btn1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn1.UseVisualStyleBackColor = false;
            this.jS7Btn1.Click += new System.EventHandler(this.JS7Btn1Click);
            // 
            // jsPanel2
            // 
            this.jsPanel2.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel2.Controls.Add(this.jsDataGrid2);
            this.jsPanel2.Controls.Add(this.jsDataGrid1);
            this.jsPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsPanel2.Location = new System.Drawing.Point(140, 0);
            this.jsPanel2.Name = "jsPanel2";
            this.jsPanel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel2.Size = new System.Drawing.Size(746, 332);
            this.jsPanel2.TabIndex = 3;
            // 
            // jsDataGrid2
            // 
            this.jsDataGrid2.AllowUserToAddRows = false;
            this.jsDataGrid2.AllowUserToDeleteRows = false;
            this.jsDataGrid2.AllowUserToOrderColumns = true;
            this.jsDataGrid2.AllowUserToResizeRows = false;
            this.jsDataGrid2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsDataGrid2.BackgroundColor = System.Drawing.Color.White;
            this.jsDataGrid2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("B Mitra", 12F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.jsDataGrid2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.jsDataGrid2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.jsDataGrid2.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.jsDataGrid2.GridColor = System.Drawing.Color.LightGray;
            this.jsDataGrid2.JSCustomSetting = true;
            this.jsDataGrid2.Location = new System.Drawing.Point(118, 81);
            this.jsDataGrid2.MultiSelect = false;
            this.jsDataGrid2.Name = "jsDataGrid2";
            this.jsDataGrid2.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.jsDataGrid2.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.jsDataGrid2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.jsDataGrid2.Size = new System.Drawing.Size(240, 150);
            this.jsDataGrid2.TabIndex = 1;
            // 
            // jsDataGrid1
            // 
            this.jsDataGrid1.AllowUserToAddRows = false;
            this.jsDataGrid1.AllowUserToDeleteRows = false;
            this.jsDataGrid1.AllowUserToOrderColumns = true;
            this.jsDataGrid1.AllowUserToResizeRows = false;
            this.jsDataGrid1.BackgroundColor = System.Drawing.Color.White;
            this.jsDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("B Mitra", 12F);
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.jsDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.jsDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.jsDataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductID,
            this.PName,
            this.ProductCategory,
            this.ProductCategoryID,
            this.ProductsUnit,
            this.ProductsUnitID,
            this.PSize,
            this.PBuyPrice,
            this.PPrice,
            this.PDiscount,
            this.PStock,
            this.PMinInventory,
            this.PSold,
            this.PBarCode});
            this.jsDataGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsDataGrid1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.jsDataGrid1.GridColor = System.Drawing.Color.LightGray;
            this.jsDataGrid1.JSCustomSetting = false;
            this.jsDataGrid1.Location = new System.Drawing.Point(0, 0);
            this.jsDataGrid1.MultiSelect = false;
            this.jsDataGrid1.Name = "jsDataGrid1";
            this.jsDataGrid1.RowHeadersVisible = false;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.jsDataGrid1.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.jsDataGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.jsDataGrid1.Size = new System.Drawing.Size(746, 332);
            this.jsDataGrid1.TabIndex = 0;
            // 
            // ProductID
            // 
            this.ProductID.DataPropertyName = "ProductID";
            this.ProductID.HeaderText = "کد کالا";
            this.ProductID.Name = "ProductID";
            this.ProductID.Visible = false;
            this.ProductID.Width = 5;
            // 
            // PName
            // 
            this.PName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PName.DataPropertyName = "PName";
            this.PName.HeaderText = "نام";
            this.PName.MinimumWidth = 80;
            this.PName.Name = "PName";
            // 
            // ProductCategory
            // 
            this.ProductCategory.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.ProductCategory.DataPropertyName = "ProductCategory";
            this.ProductCategory.HeaderText = "دسته بندی";
            this.ProductCategory.Name = "ProductCategory";
            this.ProductCategory.Width = 65;
            // 
            // ProductCategoryID
            // 
            this.ProductCategoryID.DataPropertyName = "ProductCategoryID";
            this.ProductCategoryID.HeaderText = "ProductCategoryID";
            this.ProductCategoryID.Name = "ProductCategoryID";
            this.ProductCategoryID.Visible = false;
            // 
            // ProductsUnit
            // 
            this.ProductsUnit.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.ProductsUnit.DataPropertyName = "ProductsUnit";
            this.ProductsUnit.HeaderText = "واحد شمارش";
            this.ProductsUnit.Name = "ProductsUnit";
            this.ProductsUnit.Width = 73;
            // 
            // ProductsUnitID
            // 
            this.ProductsUnitID.DataPropertyName = "ProductsUnitID";
            this.ProductsUnitID.HeaderText = "ProductsUnitID";
            this.ProductsUnitID.Name = "ProductsUnitID";
            this.ProductsUnitID.Visible = false;
            // 
            // PSize
            // 
            this.PSize.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.PSize.DataPropertyName = "PSize";
            this.PSize.HeaderText = "تعداد در کارتن";
            this.PSize.Name = "PSize";
            this.PSize.Width = 79;
            // 
            // PBuyPrice
            // 
            this.PBuyPrice.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.PBuyPrice.DataPropertyName = "PBuyPrice";
            this.PBuyPrice.HeaderText = "قیمت خرید";
            this.PBuyPrice.Name = "PBuyPrice";
            this.PBuyPrice.Width = 66;
            // 
            // PPrice
            // 
            this.PPrice.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.PPrice.DataPropertyName = "PPrice";
            this.PPrice.HeaderText = "قیمت فروش";
            this.PPrice.Name = "PPrice";
            this.PPrice.Width = 72;
            // 
            // PDiscount
            // 
            this.PDiscount.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.PDiscount.DataPropertyName = "PDiscount";
            this.PDiscount.HeaderText = "تخفیف";
            this.PDiscount.Name = "PDiscount";
            this.PDiscount.Width = 47;
            // 
            // PStock
            // 
            this.PStock.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.PStock.DataPropertyName = "PStock";
            this.PStock.HeaderText = "موجودی";
            this.PStock.Name = "PStock";
            this.PStock.Width = 53;
            // 
            // PMinInventory
            // 
            this.PMinInventory.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCellsExceptHeader;
            this.PMinInventory.DataPropertyName = "PMinInventory";
            this.PMinInventory.HeaderText = "حداقل موجودی لازم";
            this.PMinInventory.Name = "PMinInventory";
            this.PMinInventory.Visible = false;
            this.PMinInventory.Width = 5;
            // 
            // PSold
            // 
            this.PSold.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.PSold.DataPropertyName = "PSold";
            this.PSold.HeaderText = "فروخته شده";
            this.PSold.Name = "PSold";
            this.PSold.Visible = false;
            this.PSold.Width = 88;
            // 
            // PBarCode
            // 
            this.PBarCode.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.PBarCode.DataPropertyName = "PBarCode";
            this.PBarCode.HeaderText = "بارکد";
            this.PBarCode.Name = "PBarCode";
            this.PBarCode.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.PBarCode.Visible = false;
            this.PBarCode.Width = 57;
            // 
            // FrmProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(961, 332);
            this.Controls.Add(this.jsPanel2);
            this.Controls.Add(this.jsPanel1);
            this.FormTitle = "کالاها";
            this.Name = "FrmProduct";
            this.Text = "سامانه مدیریت فروشگاه | کالاها";
            this.Controls.SetChildIndex(this.jsPanel1, 0);
            this.Controls.SetChildIndex(this.jsPanel2, 0);
            this.jsPanel1.ResumeLayout(false);
            this.jsPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSPanel jsPanel1;
        private JSRequirement.Controls.JSPanel jsPanel2;
        private JSRequirement.Controls.JSDataGrid jsDataGrid1;
        private JSRequirement.Controls.JS7Btn jS7Btn4;
        private JSRequirement.Controls.JS7Btn jS7Btn3;
        private JSRequirement.Controls.JS7Btn jS7Btn2;
        private JSRequirement.Controls.JS7Btn jS7Btn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCategoryID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductsUnit;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductsUnitID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn PBuyPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn PPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn PDiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn PStock;
        private System.Windows.Forms.DataGridViewTextBoxColumn PMinInventory;
        private System.Windows.Forms.DataGridViewTextBoxColumn PSold;
        private System.Windows.Forms.DataGridViewTextBoxColumn PBarCode;
        private JSRequirement.Controls.JSDataGrid jsDataGrid2;
    }
}
