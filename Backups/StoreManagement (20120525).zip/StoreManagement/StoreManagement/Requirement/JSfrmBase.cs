﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace StoreManagement.Requirement
{
    public partial class JSfrmBase : JSRequirement.Forms.JSBaseForm
    {
        public JSfrmBase()
        {
            InitializeComponent();
            jsMenuStripStoreManagement1.ParentForm = this;
            BringToFront();
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            try
            {
                if (Owner != null) Owner.Hide();
                if (!DesignMode) CenterForm();

                Activate();
                BringToFront();
                Focus();
            }
            catch{return;}
        }
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            try
            {
                if (Forms.FrmHome.Instance != null && !Forms.FrmHome.Instance.Visible)
                {
                    Forms.FrmHome.Instance.Visible = false;
                    Forms.FrmHome.Instance.Show();
                }
            }
            catch{return;}
        }
        private void CenterForm()
        {
            var center = new Point
            {
                X = (Screen.PrimaryScreen.WorkingArea.Width - Width) / 2,
                Y = (Screen.PrimaryScreen.WorkingArea.Height - Height) / 2
            };

            Location = center;
        }

        private string _frmTitle;
        /// <summary>
        /// current form title for showing on title bar.
        /// </summary>
        [Category("JSCustomizer"),
         Description("The text that is displayed on form title bar.")]
        public string FormTitle
        {
            get { return _frmTitle; }
            set
            {
                try
                {
                    _frmTitle = value;
                    Invalidate();
                    var appPreName = Properties.Settings.Default.AppNamePre + @" " + Properties.Settings.Default.AppName;
                    
                    if(_frmTitle.Length < 3)
                    {
                        base.Text = appPreName;
                    }
                    else
                    {
                        base.Text = appPreName + @" | " + _frmTitle;
                    }
                }
                catch
                {
                    return;
                }
            }
        }


        [Category("JSCustomizer"), Description("Raise Event when user input barcode.")]
        public event EventHandler BarcodeTaken;
        protected virtual void OnBarcodeTaken(EventArgs e)
        {
            if (BarcodeTaken != null)
                BarcodeTaken(this, e);
        }

        /// <summary>
        /// Give barcode from user and save it.
        /// </summary>
        [Category("JSCustomizer"), Description("Give barcode from user and save it.")]
        public string JSBarcode { get; private set; }

        private bool _isBarCode;
        private string _barcode = string.Empty;

        private void JSfrmBaseKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '$')
            {
                try
                {
                    InputLanguage.CurrentInputLanguage =
                        InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-us"));
                }
                catch { return; }

                _isBarCode = !_isBarCode;
                e.Handled = true;                           // dont show any char to user
                if (_isBarCode) return;                     // if start reading barcode, don't continue

                if (_barcode.Length > 3)                    // if barcode len > 3
                {
                    JSBarcode = _barcode;
                    BarcodeTaken(this, e);
                    _barcode = string.Empty;
                }
            }
            else if (_isBarCode)
            {
                _barcode += e.KeyChar;                      // give barcode char by char
                e.Handled = true;                           // dont show any char to user
            }
        }
    }
}