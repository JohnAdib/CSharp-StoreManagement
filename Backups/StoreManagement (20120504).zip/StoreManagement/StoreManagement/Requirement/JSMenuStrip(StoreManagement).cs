﻿using System.Windows.Forms;

namespace StoreManagement.Requirement
{
    public partial class JSMenuStripStoreManagement : UserControl
    {
        public JSMenuStripStoreManagement()
        {
            InitializeComponent();
        }

        private void ExitToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            if (ParentForm != null) ParentForm.Close();
        }

        private void CalculatorToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            System.Diagnostics.Process.Start("calc.exe");
        }

        private void AboutusToolStripMenuItemClick(object sender, System.EventArgs e)
        {
            new JSAboutBox().ShowDialog();
        }
    }
}
