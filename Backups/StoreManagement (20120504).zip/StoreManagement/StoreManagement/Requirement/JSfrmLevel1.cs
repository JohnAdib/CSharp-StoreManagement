﻿namespace StoreManagement.Requirement
{
    public partial class JSfrmLevel1 : JSRequirement.Forms.JSBaseForm
    {
        public JSfrmLevel1()
        {
            InitializeComponent();
        }

        private void JSfrmLevel1Load(object sender, System.EventArgs e)
        {
            Text = Properties.Settings.Default.AppNamePre + @" " + Properties.Settings.Default.AppName;
        }
    }
}
