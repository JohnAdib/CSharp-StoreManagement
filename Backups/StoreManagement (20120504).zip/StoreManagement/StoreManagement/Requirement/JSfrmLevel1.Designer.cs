﻿namespace StoreManagement.Requirement
{
    partial class JSfrmLevel1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jsMenuStripStoreManagement1 = new StoreManagement.Requirement.JSMenuStripStoreManagement();
            this.jsMenuPanel = new JSRequirement.Controls.JSPanel();
            this.jsMenuPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsMenuStripStoreManagement1
            // 
            this.jsMenuStripStoreManagement1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.jsMenuStripStoreManagement1.BackColor = System.Drawing.Color.Transparent;
            this.jsMenuStripStoreManagement1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsMenuStripStoreManagement1.Location = new System.Drawing.Point(0, 0);
            this.jsMenuStripStoreManagement1.MaximumSize = new System.Drawing.Size(80, 0);
            this.jsMenuStripStoreManagement1.MinimumSize = new System.Drawing.Size(80, 250);
            this.jsMenuStripStoreManagement1.Name = "jsMenuStripStoreManagement1";
            this.jsMenuStripStoreManagement1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsMenuStripStoreManagement1.Size = new System.Drawing.Size(80, 332);
            this.jsMenuStripStoreManagement1.TabIndex = 0;
            // 
            // jsMenuPanel
            // 
            this.jsMenuPanel.BackColor = System.Drawing.Color.Transparent;
            this.jsMenuPanel.Controls.Add(this.jsMenuStripStoreManagement1);
            this.jsMenuPanel.Dock = System.Windows.Forms.DockStyle.Right;
            this.jsMenuPanel.Location = new System.Drawing.Point(504, 0);
            this.jsMenuPanel.Name = "jsMenuPanel";
            this.jsMenuPanel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsMenuPanel.Size = new System.Drawing.Size(80, 332);
            this.jsMenuPanel.TabIndex = 1;
            // 
            // JSfrmLevel1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(584, 332);
            this.Controls.Add(this.jsMenuPanel);
            this.Name = "JSfrmLevel1";
            this.ShowInTaskbar = false;
            this.Text = "فرم سطح 1";
            this.Load += new System.EventHandler(this.JSfrmLevel1Load);
            this.jsMenuPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private JSMenuStripStoreManagement jsMenuStripStoreManagement1;
        private JSRequirement.Controls.JSPanel jsMenuPanel;






    }
}
