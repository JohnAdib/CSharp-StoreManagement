﻿namespace StoreManagement.Requirement
{
    partial class JSMenuStripStoreManagement
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.JSMenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.formsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فرم1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فرم2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فرم3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.فرمتستToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.JSMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // JSMenuStrip
            // 
            this.JSMenuStrip.BackgroundImage = global::StoreManagement.Properties.Resources.LightBackgroundTile;
            this.JSMenuStrip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.JSMenuStrip.Font = new System.Drawing.Font("Far.Dast Nevis", 14F);
            this.JSMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolStripMenuItem3,
            this.formsToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.JSMenuStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.JSMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.JSMenuStrip.Margin = new System.Windows.Forms.Padding(3);
            this.JSMenuStrip.Name = "JSMenuStrip";
            this.JSMenuStrip.Padding = new System.Windows.Forms.Padding(3);
            this.JSMenuStrip.Size = new System.Drawing.Size(80, 270);
            this.JSMenuStrip.TabIndex = 0;
            this.JSMenuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4);
            this.fileToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.fileToolStripMenuItem.RightToLeftAutoMirrorImage = true;
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(63, 44);
            this.fileToolStripMenuItem.Text = "فایل";
            this.fileToolStripMenuItem.ToolTipText = "از طریق این گزینه ها بین قسمت های مختلف برنامه جابجا شوید";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(121, 36);
            this.exitToolStripMenuItem.Text = "خروج";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItemClick);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Padding = new System.Windows.Forms.Padding(4);
            this.toolStripMenuItem3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.toolStripMenuItem3.Size = new System.Drawing.Size(63, 44);
            this.toolStripMenuItem3.Text = "ویرایش";
            this.toolStripMenuItem3.ToolTipText = "از طریق این گزینه ها بین قسمت های مختلف برنامه جابجا شوید";
            // 
            // formsToolStripMenuItem
            // 
            this.formsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.فرم1ToolStripMenuItem,
            this.فرم2ToolStripMenuItem,
            this.فرم3ToolStripMenuItem,
            this.فرمتستToolStripMenuItem});
            this.formsToolStripMenuItem.Name = "formsToolStripMenuItem";
            this.formsToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4);
            this.formsToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.formsToolStripMenuItem.Size = new System.Drawing.Size(63, 44);
            this.formsToolStripMenuItem.Text = "فرم ها";
            this.formsToolStripMenuItem.ToolTipText = "از طریق این گزینه ها بین قسمت های مختلف برنامه جابجا شوید";
            // 
            // فرم1ToolStripMenuItem
            // 
            this.فرم1ToolStripMenuItem.Name = "فرم1ToolStripMenuItem";
            this.فرم1ToolStripMenuItem.Size = new System.Drawing.Size(153, 36);
            this.فرم1ToolStripMenuItem.Text = "فرم 1";
            // 
            // فرم2ToolStripMenuItem
            // 
            this.فرم2ToolStripMenuItem.Name = "فرم2ToolStripMenuItem";
            this.فرم2ToolStripMenuItem.Size = new System.Drawing.Size(153, 36);
            this.فرم2ToolStripMenuItem.Text = "فرم2";
            // 
            // فرم3ToolStripMenuItem
            // 
            this.فرم3ToolStripMenuItem.Name = "فرم3ToolStripMenuItem";
            this.فرم3ToolStripMenuItem.Size = new System.Drawing.Size(153, 36);
            this.فرم3ToolStripMenuItem.Text = "فرم3";
            // 
            // فرمتستToolStripMenuItem
            // 
            this.فرمتستToolStripMenuItem.Name = "فرمتستToolStripMenuItem";
            this.فرمتستToolStripMenuItem.Size = new System.Drawing.Size(153, 36);
            this.فرمتستToolStripMenuItem.Text = "فرم تست";
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.calculatorToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4);
            this.toolsToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(63, 44);
            this.toolsToolStripMenuItem.Text = "امکانات";
            this.toolsToolStripMenuItem.ToolTipText = "از طریق این گزینه ها بین قسمت های مختلف برنامه جابجا شوید";
            // 
            // calculatorToolStripMenuItem
            // 
            this.calculatorToolStripMenuItem.Name = "calculatorToolStripMenuItem";
            this.calculatorToolStripMenuItem.Size = new System.Drawing.Size(182, 36);
            this.calculatorToolStripMenuItem.Text = "ماشین حساب";
            this.calculatorToolStripMenuItem.Click += new System.EventHandler(this.CalculatorToolStripMenuItemClick);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutusToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4);
            this.aboutToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(63, 44);
            this.aboutToolStripMenuItem.Text = "درباره";
            this.aboutToolStripMenuItem.ToolTipText = "از طریق این گزینه ها بین قسمت های مختلف برنامه جابجا شوید";
            // 
            // aboutusToolStripMenuItem
            // 
            this.aboutusToolStripMenuItem.Name = "aboutusToolStripMenuItem";
            this.aboutusToolStripMenuItem.Size = new System.Drawing.Size(140, 36);
            this.aboutusToolStripMenuItem.Text = "درباره ما";
            this.aboutusToolStripMenuItem.Click += new System.EventHandler(this.AboutusToolStripMenuItemClick);
            // 
            // JSMenuStripStoreManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.JSMenuStrip);
            this.MaximumSize = new System.Drawing.Size(80, 0);
            this.MinimumSize = new System.Drawing.Size(80, 250);
            this.Name = "JSMenuStripStoreManagement";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Size = new System.Drawing.Size(80, 270);
            this.JSMenuStrip.ResumeLayout(false);
            this.JSMenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutusToolStripMenuItem;
        protected System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        protected System.Windows.Forms.ToolStripMenuItem formsToolStripMenuItem;
        protected System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        protected System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        protected System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem فرم1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فرم2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فرم3ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem فرمتستToolStripMenuItem;
        private System.Windows.Forms.MenuStrip JSMenuStrip;
    }
}
