﻿namespace StoreManagement.Forms.SecurityQuestions
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.jS7Btn1 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn2 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn3 = new JSRequirement.Controls.JS7Btn();
            this.SuspendLayout();
            // 
            // jS7Btn1
            // 
            this.jS7Btn1.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Add;
            this.jS7Btn1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn1.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn1.ButtonText = "اضافه کردن";
            this.jS7Btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn1.Font = new System.Drawing.Font("Far.Dast Nevis", 15F);
            this.jS7Btn1.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn1.Image")));
            this.jS7Btn1.ImageSize = new System.Drawing.Size(32, 32);
            this.jS7Btn1.Location = new System.Drawing.Point(16, 16);
            this.jS7Btn1.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn1.MinimumSize = new System.Drawing.Size(150, 50);
            this.jS7Btn1.Name = "jS7Btn1";
            this.jS7Btn1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn1.Size = new System.Drawing.Size(150, 50);
            this.jS7Btn1.TabIndex = 1;
            this.jS7Btn1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // jS7Btn2
            // 
            this.jS7Btn2.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Update;
            this.jS7Btn2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn2.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn2.ButtonText = "به روز رسانی";
            this.jS7Btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn2.Font = new System.Drawing.Font("Far.Dast Nevis", 15F);
            this.jS7Btn2.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn2.Image")));
            this.jS7Btn2.ImageSize = new System.Drawing.Size(32, 32);
            this.jS7Btn2.Location = new System.Drawing.Point(16, 77);
            this.jS7Btn2.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn2.MinimumSize = new System.Drawing.Size(150, 50);
            this.jS7Btn2.Name = "jS7Btn2";
            this.jS7Btn2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn2.Size = new System.Drawing.Size(150, 50);
            this.jS7Btn2.TabIndex = 2;
            this.jS7Btn2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // jS7Btn3
            // 
            this.jS7Btn3.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Delete;
            this.jS7Btn3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn3.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn3.ButtonText = "حذف";
            this.jS7Btn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn3.Font = new System.Drawing.Font("Far.Dast Nevis", 15F);
            this.jS7Btn3.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn3.Image")));
            this.jS7Btn3.ImageSize = new System.Drawing.Size(32, 32);
            this.jS7Btn3.Location = new System.Drawing.Point(16, 138);
            this.jS7Btn3.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn3.MinimumSize = new System.Drawing.Size(150, 50);
            this.jS7Btn3.Name = "jS7Btn3";
            this.jS7Btn3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn3.Size = new System.Drawing.Size(150, 50);
            this.jS7Btn3.TabIndex = 3;
            this.jS7Btn3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(712, 426);
            this.Controls.Add(this.jS7Btn1);
            this.Controls.Add(this.jS7Btn3);
            this.Controls.Add(this.jS7Btn2);
            this.Name = "Form1";
            this.Controls.SetChildIndex(this.jS7Btn2, 0);
            this.Controls.SetChildIndex(this.jS7Btn3, 0);
            this.Controls.SetChildIndex(this.jS7Btn1, 0);
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JS7Btn jS7Btn1;
        private JSRequirement.Controls.JS7Btn jS7Btn2;
        private JSRequirement.Controls.JS7Btn jS7Btn3;


    }
}
