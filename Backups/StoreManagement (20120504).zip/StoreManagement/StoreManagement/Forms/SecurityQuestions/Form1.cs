﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace StoreManagement.Forms.SecurityQuestions
{
    public partial class Form1 : StoreManagement.Requirement.JSfrmLevel1
    {
        public Form1()
        {
            InitializeComponent();
        }
    }
}
