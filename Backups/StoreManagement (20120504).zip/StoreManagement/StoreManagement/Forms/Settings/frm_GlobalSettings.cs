﻿using System;

namespace StoreManagement.Forms.Settings
{
    public partial class FrmGlobalSettings : Requirement.JSfrmLevel1
    {
        public FrmGlobalSettings()
        {
            InitializeComponent();
            try
            {
                jscTxtAppname.Text = Properties.Settings.Default.AppName;
            }
            catch (Exception)
            {
                return;
            }
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {
            try
            {
                Properties.Settings.Default.AppName = jscTxtAppname.Text;
                Properties.Settings.Default.Save();
                Close();
            }
            catch (Exception)
            {
                return;
            }
        }

        private void JS7Btn2Click(object sender, EventArgs e)
        {
            Close();
        }

        private void FrmGlobalSettingsLoad(object sender, EventArgs e)
        {

        }
    }
}
