﻿namespace StoreManagement.Forms.Settings
{
    partial class FrmGlobalSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmGlobalSettings));
            this.jsPanel1 = new JSRequirement.Controls.JSPanel();
            this.jS7Btn2 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn1 = new JSRequirement.Controls.JS7Btn();
            this.jsPanel2 = new JSRequirement.Controls.JSPanel();
            this.jsGroupBox1 = new JSRequirement.Controls.JSGroupBox();
            this.jscTxtAppname = new JSRequirement.Controls.JSTextBox();
            this.jsLabel1 = new JSRequirement.Controls.JSLabel();
            this.jsPanel1.SuspendLayout();
            this.jsPanel2.SuspendLayout();
            this.jsGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsPanel1
            // 
            this.jsPanel1.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel1.Controls.Add(this.jS7Btn2);
            this.jsPanel1.Controls.Add(this.jS7Btn1);
            this.jsPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.jsPanel1.Location = new System.Drawing.Point(0, 0);
            this.jsPanel1.Name = "jsPanel1";
            this.jsPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel1.Size = new System.Drawing.Size(165, 262);
            this.jsPanel1.TabIndex = 1;
            // 
            // jS7Btn2
            // 
            this.jS7Btn2.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Close;
            this.jS7Btn2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn2.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn2.ButtonText = "بستن";
            this.jS7Btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn2.Font = new System.Drawing.Font("Far.Dast Nevis", 15F);
            this.jS7Btn2.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn2.Image")));
            this.jS7Btn2.ImageSize = new System.Drawing.Size(32, 32);
            this.jS7Btn2.Location = new System.Drawing.Point(8, 120);
            this.jS7Btn2.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn2.MinimumSize = new System.Drawing.Size(150, 50);
            this.jS7Btn2.Name = "jS7Btn2";
            this.jS7Btn2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn2.Size = new System.Drawing.Size(150, 50);
            this.jS7Btn2.TabIndex = 1;
            this.jS7Btn2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn2.Click += new System.EventHandler(this.JS7Btn2Click);
            // 
            // jS7Btn1
            // 
            this.jS7Btn1.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Update;
            this.jS7Btn1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn1.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn1.ButtonText = "به روز رسانی";
            this.jS7Btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn1.Font = new System.Drawing.Font("Far.Dast Nevis", 15F);
            this.jS7Btn1.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn1.Image")));
            this.jS7Btn1.ImageSize = new System.Drawing.Size(32, 32);
            this.jS7Btn1.Location = new System.Drawing.Point(8, 56);
            this.jS7Btn1.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn1.MinimumSize = new System.Drawing.Size(150, 50);
            this.jS7Btn1.Name = "jS7Btn1";
            this.jS7Btn1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn1.Size = new System.Drawing.Size(150, 50);
            this.jS7Btn1.TabIndex = 0;
            this.jS7Btn1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn1.Click += new System.EventHandler(this.JS7Btn1Click);
            // 
            // jsPanel2
            // 
            this.jsPanel2.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel2.Controls.Add(this.jsGroupBox1);
            this.jsPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsPanel2.Location = new System.Drawing.Point(165, 0);
            this.jsPanel2.Name = "jsPanel2";
            this.jsPanel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel2.Size = new System.Drawing.Size(449, 262);
            this.jsPanel2.TabIndex = 2;
            // 
            // jsGroupBox1
            // 
            this.jsGroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox1.Controls.Add(this.jscTxtAppname);
            this.jsGroupBox1.Controls.Add(this.jsLabel1);
            this.jsGroupBox1.Location = new System.Drawing.Point(8, 70);
            this.jsGroupBox1.Name = "jsGroupBox1";
            this.jsGroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox1.Size = new System.Drawing.Size(435, 100);
            this.jsGroupBox1.TabIndex = 0;
            this.jsGroupBox1.TabStop = false;
            this.jsGroupBox1.Text = "نام فروشگاه خود را وارد نمایید";
            // 
            // jscTxtAppname
            // 
            this.jscTxtAppname.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jscTxtAppname.Digit = 0D;
            this.jscTxtAppname.Location = new System.Drawing.Point(6, 55);
            this.jscTxtAppname.MaxLength = 200;
            this.jscTxtAppname.Name = "jscTxtAppname";
            this.jscTxtAppname.PersianText = true;
            this.jscTxtAppname.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscTxtAppname.Size = new System.Drawing.Size(307, 33);
            this.jscTxtAppname.TabIndex = 1;
            // 
            // jsLabel1
            // 
            this.jsLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel1.AutoSize = true;
            this.jsLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel1.Location = new System.Drawing.Point(319, 58);
            this.jsLabel1.Name = "jsLabel1";
            this.jsLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel1.Size = new System.Drawing.Size(110, 26);
            this.jsLabel1.TabIndex = 0;
            this.jsLabel1.Text = "سامانه مدیریت";
            this.jsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmGlobalSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(694, 262);
            this.Controls.Add(this.jsPanel2);
            this.Controls.Add(this.jsPanel1);
            this.Name = "FrmGlobalSettings";
            this.Text = "تنظیمات سامانه مدیریت فروشگاه";
            this.Load += new System.EventHandler(this.FrmGlobalSettingsLoad);
            this.Controls.SetChildIndex(this.jsPanel1, 0);
            this.Controls.SetChildIndex(this.jsPanel2, 0);
            this.jsPanel1.ResumeLayout(false);
            this.jsPanel2.ResumeLayout(false);
            this.jsGroupBox1.ResumeLayout(false);
            this.jsGroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSPanel jsPanel1;
        private JSRequirement.Controls.JS7Btn jS7Btn1;
        private JSRequirement.Controls.JS7Btn jS7Btn2;
        private JSRequirement.Controls.JSPanel jsPanel2;
        private JSRequirement.Controls.JSGroupBox jsGroupBox1;
        private JSRequirement.Controls.JSLabel jsLabel1;
        private JSRequirement.Controls.JSTextBox jscTxtAppname;
    }
}
