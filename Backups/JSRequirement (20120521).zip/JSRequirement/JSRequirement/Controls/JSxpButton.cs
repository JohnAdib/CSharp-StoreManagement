using System;
using System.Drawing;
using System.Windows.Forms;

namespace JSRequirement.Controls
{
    internal class JSxpButton : Button
    {
        //private static readonly Font NormalFont = new Font("Arial", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
        private static readonly Font NormalFont = new Font("Far.Dast Nevis", 16F);
        private static readonly Color Back = Color.Gray;
        private static readonly Color Border = Color.DodgerBlue;
        private static readonly Color ActiveBorder = Color.Red;
        private static readonly Color Fore = Color.YellowGreen;
        private static readonly Padding BtnMargin = new Padding(5, 0, 5, 0);
        private static readonly Padding BtnPadding = new Padding(3, 3, 3, 3);
        private static readonly Size MinSize = new Size(140, 40);

        private bool _active;

        public JSxpButton()
        {
            base.Font = NormalFont;
            base.BackColor = Border;
            base.ForeColor = Fore;
            FlatAppearance.BorderColor = Back;
            FlatStyle = FlatStyle.Standard;
            Margin = BtnMargin;
            Padding = BtnPadding;
            base.MinimumSize = MinSize;
            TextImageRelation = TextImageRelation.ImageBeforeText;
        }

        protected override void OnControlAdded(ControlEventArgs e)
        {
            base.OnControlAdded(e);
            UseVisualStyleBackColor = true;
        }

        protected override void OnMouseEnter(EventArgs e)
        {
            base.OnMouseEnter(e);
            if (!_active)
                FlatAppearance.BorderColor = ActiveBorder;
        }

        protected override void OnMouseLeave(EventArgs e)
        {
            base.OnMouseLeave(e);
            if (!_active)
                FlatAppearance.BorderColor = Border;
        }

        public void SetStateActive()
        {
            _active = true;
            FlatAppearance.BorderColor = ActiveBorder;
        }

        public void SetStateNormal()
        {
            _active = false;
            FlatAppearance.BorderColor = Border;
        }
    }
}