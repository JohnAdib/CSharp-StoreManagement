﻿using System;

namespace JSRequirement.Codes
{
    class JSUtility
    {
    }


    /// <summary>
    /// Classes to convert a number to its persian written form. It accepts both an Integer or Long as input parameter.
    /// </summary>
    /// <exception>Thrown when input number is larger than 999999999999</exception>
    /// <example>
    /// An example on how to convert a Integer number to words.
    /// <code>
    ///		class MyClass 
    ///     {
    ///		   public static void Main() 
    ///        {
    ///		      Console.WriteLine(FarsiLibrary.Utils.ToWords.ToString(1452));
    ///		   }
    ///		}
    /// </code>
    /// </example>
    /// <exception cref="ArgumentOutOfRangeException"></exception>
    public sealed class ToWords
    {
        static private readonly string[] CvtText = new string[1000];

        static private void BuildMapping()
        {
            CvtText[1] = "يک";
            CvtText[2] = "دو";
            CvtText[3] = "سه";
            CvtText[4] = "چهار";
            CvtText[5] = "پنج";
            CvtText[6] = "شش";
            CvtText[7] = "هفت";
            CvtText[8] = "هشت";
            CvtText[9] = "نه";
            CvtText[10] = "ده";
            CvtText[11] = "یازده";
            CvtText[12] = "دوازده";
            CvtText[13] = "سیزده";
            CvtText[14] = "چهارده";
            CvtText[15] = "پانزده";
            CvtText[16] = "شانزده";
            CvtText[17] = "هفده";
            CvtText[18] = "هجده";
            CvtText[19] = "نوزده";
            CvtText[20] = "بيست";
            CvtText[21] = "سی";
            CvtText[22] = "چهل";
            CvtText[23] = "پنجاه";
            CvtText[24] = "شصت";
            CvtText[25] = "هفتاد";
            CvtText[26] = "هشتاد";
            CvtText[27] = "نود";
            CvtText[28] = "صد";
            CvtText[29] = "هزار";
            CvtText[30] = "میلیون";
            CvtText[31] = "میلیارد";
            CvtText[100] = "صد";
            CvtText[200] = "دویست";
            CvtText[300] = "سیصد";
            CvtText[400] = "چهارصد";
            CvtText[500] = "پانصد";
            CvtText[600] = "ششصد";
            CvtText[700] = "هفتصد";
            CvtText[800] = "هشتصد";
            CvtText[900] = "نهصد";
        }

        static private string Cvt100(long number)
        {
            var x = (int)number;
            int t;
            string result = string.Empty;

            if (x > 999)
                throw new ArgumentOutOfRangeException("number");

            if (x > 99)
            {
                t = x / 100;
                switch (t)
                {
                    case 1:
                        result = CvtText[100];
                        break;
                    case 2:
                        result = CvtText[200];
                        break;
                    case 3:
                        result = CvtText[300];
                        break;
                    case 4:
                        result = CvtText[400];
                        break;
                    case 5:
                        result = CvtText[500];
                        break;
                    case 6:
                        result = CvtText[600];
                        break;
                    case 7:
                        result = CvtText[700];
                        break;
                    case 8:
                        result = CvtText[800];
                        break;
                    case 9:
                        result = CvtText[900];
                        break;
                }

                x = x - (t * 100);

                if (x <= 0)
                {
                    return result;
                }
                result += String.Format(" {0} ", " و ");
            }

            if (x > 20)
            {
                t = x / 10;
                result = result + CvtText[t + 18];
                x = x - (t * 10);

                if (x <= 0)
                {
                    return result;
                }
                result += String.Format(" {0} ", " و ");
            }

            if (x > 0)
            {
                result += CvtText[x];
            }

            return result;
        }


        /// <overloads>Has two overloads.</overloads>
        /// <summary>Converts an integer number to its written form in Persian</summary>
        /// <param name="x"></param>
        /// <returns></returns>
        static public string ToString(int x)
        {
            return (ToString(long.Parse(x.ToString())));
        }


        /// <summary>Converts a long number to its written form in Persian</summary>
        /// <param name="x"></param>
        /// <returns></returns>
        /// <exception cref="ArgumentOutOfRangeException"></exception>
        static public string ToString(long x)
        {
            //Build array for number to words mapping
            BuildMapping();

            long t;
            string result = string.Empty;

            if (x > 999999999999)
                throw new ArgumentOutOfRangeException("x");

            if (x > 999999999)
            {
                t = x / 1000000000;
                result += Cvt100(t) + " " + CvtText[31];
                x = x - (t * 1000000000);

                if (x <= 0)
                {
                    return result;
                }
                result += String.Format(" {0} ", " و ");
            }

            if (x > 999999)
            {
                t = x / 1000000;
                result += Cvt100(t) + " " + CvtText[30];
                x = x - (t * 1000000);

                if (x <= 0)
                {
                    return result;
                }
                result += String.Format(" {0} ", " و ");
            }

            if (x > 999)
            {
                t = x / 1000;
                result += Cvt100(t) + " " + CvtText[29];
                x = x - (t * 1000);

                if (x <= 0)
                {
                    return result;
                }
                result += String.Format(" {0} ", " و ");
            }

            if (x > 0)
            {
                result += Cvt100(x);
            }

            return result;
        }
    }
}
