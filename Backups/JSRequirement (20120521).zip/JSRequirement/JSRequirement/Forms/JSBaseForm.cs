﻿using System.Windows.Forms;

namespace JSRequirement.Forms
{
    public partial class JSBaseForm : Form
    {
        public JSBaseForm()
        {
            InitializeComponent();
        }

    }
}
