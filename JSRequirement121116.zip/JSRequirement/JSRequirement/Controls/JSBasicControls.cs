﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.Drawing;
using System.ComponentModel;

namespace JSRequirement.Controls
{
    public sealed class JSTextBox : TextBox
    {
        public JSTextBox()
        {
            Anchor = (AnchorStyles.Top | AnchorStyles.Right);
            RightToLeft = RightToLeft.Yes;
            MaxLength = 200;
        }

        public string Copyright { get { return "Copyright © by Javad Evazzadeh, all right reserved. www.Evazzadeh.com"; } }

        protected override void OnValidating(CancelEventArgs e)
        {
            base.OnValidating(e);
            string clearString = Text.Where(c => c != '\'').Aggregate("", (current, c) => current + c);
            Text = clearString;
            char[] charsToTrim = { ' ', '\'' };
            Text = Text.Trim(charsToTrim);

            BackColor = Text == "" ? Color.SkyBlue : Color.White;
        }

        public override string Text
        {
            get { return base.Text.Trim(); }
            set { base.Text = value.Trim(); }
        }

        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("Enter default number and press enter")]
        public double NumDouble
        {
            get
            {
                double tmpDigit;
                double.TryParse(Text, out tmpDigit);
                return tmpDigit;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value.ToString()) || value.ToString().Trim() == "0") return;
                Text = value.ToString();
            }
        }

        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("Enter default number and press enter")]
        public float NumFloat
        {
            get
            {
                float tmpDigit;
                float.TryParse(Text, out tmpDigit);
                return tmpDigit;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value.ToString()) || value.ToString().Trim() == "0") return;
                Text = value.ToString();
            }
        }

        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("Enter default number and press enter")]
        public byte NumByte
        {
            get
            {
                byte tmpDigit;
                byte.TryParse(Text, out tmpDigit);
                return tmpDigit;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value.ToString()) || value.ToString().Trim() == "0") return;
                Text = value.ToString();
            }
        }

        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("Enter default number and press enter")]
        public Int16 Num16
        {
            get
            {
                Int16 tmpDigit;
                Int16.TryParse(Text, out tmpDigit);
                return tmpDigit;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value.ToString()) || value.ToString().Trim() == "0") return;
                Text = value.ToString();
            }
        }

        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("Enter default number and press enter")]
        public Int32 Num32
        {
            get
            {
                Int32 tmpDigit;
                Int32.TryParse(Text, out tmpDigit);
                return tmpDigit;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value.ToString()) || value.ToString().Trim() == "0") return;
                Text = value.ToString();
            }
        }

        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("Enter default number and press enter")]
        public Int64 Num64
        {
            get
            {
                Int64 tmpDigit;
                Int64.TryParse(Text, out tmpDigit);
                return tmpDigit;
            }
            set
            {
                if (string.IsNullOrWhiteSpace(value.ToString()) || value.ToString().Trim() == "0") return;
                Text = value.ToString();
            }
        }

        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("is empty ?")]
        public bool TxtEmpty
        {
            get
            {
                if (Text.Length > 0) return false;
                return true;
            }
        }

        protected override void OnEnter(EventArgs e)
        {
            base.OnEnter(e);
            try
            {
                if (PersianText)
                {
                    var language = new System.Globalization.CultureInfo("fa-ir");
                    InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(language);
                }
                else
                {
                    var language = new System.Globalization.CultureInfo("en-us");
                    InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(language);
                }
            }
            catch (Exception) { return; }
        }
        private bool _persianText = true;
        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("if true default input language is Persian else is English")]
        public bool PersianText
        {
            get { return _persianText; }
            set { _persianText = value; }
        }

    }

    public sealed class JSNumericTextBox : TextBox
    {
        public JSNumericTextBox()
        {
            Anchor = (AnchorStyles.Top | AnchorStyles.Right);
            RightToLeft = RightToLeft.Yes;
        }

        public string Copyright { get { return "Copyright © by Javad Evazzadeh, all right reserved. www.Evazzadeh.com"; } }

        protected override void OnValidating(CancelEventArgs e)
        {
            base.OnValidating(e);

            BackColor = Text == "" ? Color.SkyBlue : Color.White;
        }

        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            base.OnKeyPress(e);
            if (!System.Text.RegularExpressions.Regex.IsMatch(e.KeyChar.ToString(), "\\d+"))
                e.Handled = true;
        }
    }

    public sealed class JSBarCodeBox : TextBox
    {
        public JSBarCodeBox()
        {
            Anchor = (AnchorStyles.Top | AnchorStyles.Right);
            TextAlign = HorizontalAlignment.Center;
            RightToLeft = RightToLeft.No;
            Enabled = false;
            ReadOnly = true;
            TabStop = false;
            MaxLength = 20;
            Font = new Font(FontFamily.GenericSansSerif, 12.0F);

        }

        private bool _persianText = true;
        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("if true default input language is Persian else is English")]
        public bool PersianText
        {
            get { return _persianText; }
            set { _persianText = value; }
        }

        protected override void OnEnter(EventArgs e)
        {
            base.OnEnter(e);
            try
            {
                if (PersianText)
                {
                    var language = new System.Globalization.CultureInfo("fa-ir");
                    InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(language);
                }
                else
                {
                    var language = new System.Globalization.CultureInfo("en-us");
                    InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(language);
                }
            }
            catch (Exception) { return; }
        }

        public string Copyright { get { return "Copyright © by Javad Evazzadeh, all right reserved. www.Evazzadeh.com"; } }
    }

    public sealed class JSDataGrid : DataGridView
    {
        public JSDataGrid()
        {
            Anchor = (AnchorStyles.Top | AnchorStyles.Right);
        }

        public string Copyright { get { return "Copyright © by Javad Evazzadeh, all right reserved. www.Evazzadeh.com"; } }

        private bool _jsSetting = true;
        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("if possitive(>0) all JS Custom setting is appear;" +
                             " if zero(0) only basic setting is appear" +
                             "and if nagative(<0) default control is appear to you")]
        public bool JSCustomSetting
        {
            get { return _jsSetting; }
            set
            {
                _jsSetting = value;
                if (_jsSetting)
                {
                    AutoGenerateColumns = false;
                    //AlternatingRowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    BackgroundColor = Color.White;
                    BorderStyle = BorderStyle.Fixed3D;
                    ColumnHeadersVisible = true;
                    ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
                    ColumnHeadersHeight = 40;
                    //DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
                    RowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
                    GridColor = Color.LightGray;
                    RowHeadersVisible = false;
                    AllowUserToAddRows = false;
                    AllowUserToDeleteRows = false;
                    AllowUserToOrderColumns = true;
                    AllowUserToResizeColumns = true;
                    AllowUserToResizeRows = false;
                    EditMode = DataGridViewEditMode.EditProgrammatically;
                    MultiSelect = false;
                    ReadOnly = false;
                    SelectionMode = DataGridViewSelectionMode.FullRowSelect;
                    AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
                    AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.None;
                }
            }
        }
    }

 
    public sealed class JSComboBox : ComboBox
    {
        public JSComboBox()
        {
            Anchor = (AnchorStyles.Top | AnchorStyles.Right);
            RightToLeft = RightToLeft.Yes;
            DropDownStyle = ComboBoxStyle.DropDownList;
        }

        public string Copyright { get { return "Copyright © by Javad Evazzadeh, all right reserved. www.Evazzadeh.com"; } }

        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("return the selected value, if null return 0")]
        public Int16 SValue
        {
            get
            {
                if (SelectedValue == null) return 0;
                Int16 selectedval;
                Int16.TryParse(SelectedValue.ToString(), out selectedval);
                return selectedval;
            }
        }
        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("return the selected value, if null return 0")]
        public byte SValueByte
        {
            get
            {
                if (SelectedValue == null) return 0;
                byte selectedval;
                byte.TryParse(SelectedValue.ToString(), out selectedval);
                return selectedval;
            }
        }

        private bool _persianText = true;
        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("if true default input language is Persian else is English")]
        public bool PersianText
        {
            get { return _persianText; }
            set { _persianText = value; }
        }

        protected override void OnEnter(EventArgs e)
        {
            base.OnEnter(e);
            try
            {
                if (PersianText)
                {
                    var language = new System.Globalization.CultureInfo("fa-ir");
                    InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(language);
                }
                else
                {
                    var language = new System.Globalization.CultureInfo("en-us");
                    InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(language);
                }
            }
            catch (Exception) { return; }
        }

    }

    public sealed class JSLabel : Label
    {
        public JSLabel()
        {
            Anchor = (AnchorStyles.Top | AnchorStyles.Right);
            TextAlign = ContentAlignment.MiddleCenter;
            RightToLeft = RightToLeft.Yes;
            BackColor = Color.Transparent;
        }

        public string Copyright { get { return "Copyright © by Javad Evazzadeh, all right reserved. www.Evazzadeh.com"; } }
    }

    public sealed class JSCheckBox : CheckBox
    {
        public JSCheckBox()
        {
            Anchor = (AnchorStyles.Top | AnchorStyles.Right);
            RightToLeft = RightToLeft.Yes;
            BackColor = Color.Transparent;
            TextAlign = ContentAlignment.MiddleCenter;
        }

        public string Copyright { get { return "Copyright © by Javad Evazzadeh, all right reserved. www.Evazzadeh.com"; } }
    }

    public sealed class JSGroupBox : GroupBox
    {
        public JSGroupBox()
        {
            Anchor = (AnchorStyles.Top | AnchorStyles.Right);
            RightToLeft = RightToLeft.Yes;
            BackColor = Color.Transparent;
        }

        public string Copyright { get { return "Copyright © by Javad Evazzadeh, all right reserved. www.Evazzadeh.com"; } }
    }


    public sealed class JSPanel : Panel
    {
        public JSPanel()
        {
            Anchor = (AnchorStyles.Top | AnchorStyles.Right);
            RightToLeft = RightToLeft.Yes;
            BackColor = Color.Transparent;
        }

        public string Copyright { get { return "Copyright © by Javad Evazzadeh, all right reserved. www.Evazzadeh.com"; } }
    }

    public sealed class JSPictureBox : PictureBox
    {
        public JSPictureBox()
        {
            Anchor = (AnchorStyles.Top | AnchorStyles.Right);
            BackColor = Color.Transparent;
            ErrorImage = Properties.Resources.Aerror;
            InitialImage = Properties.Resources.loading;
        }

        public string Copyright { get { return "Copyright © by Javad Evazzadeh, all right reserved. www.Evazzadeh.com"; } }
    }

    public class JSTimer : Timer
    {
        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute("Count Tick of Timer!")]
        public int TickTimes { get; set; }

        public JSTimer()
        {
            TickTimes = 0;
        }

        public string Copyright { get { return "Copyright © by Javad Evazzadeh, all right reserved. www.Evazzadeh.com"; } }

        private int _maxTickTimes = 7;
        [CategoryAttribute("JSCustomizer"),
        DescriptionAttribute(@"Max Tick of Timer!" + @"\n" + @" 0 = extreme")]
        public int MaxTickTimes
        {
            get { return _maxTickTimes; }
            set { _maxTickTimes = value; }
        }

        protected override void OnTick(EventArgs e)
        {
            base.OnTick(e);
            TickTimes += 1;
            if (MaxTickTimes == 0) return;
            if (TickTimes > MaxTickTimes)
            {
                Enabled = false;
                TickTimes = 0;
            }
        }
    }




}
