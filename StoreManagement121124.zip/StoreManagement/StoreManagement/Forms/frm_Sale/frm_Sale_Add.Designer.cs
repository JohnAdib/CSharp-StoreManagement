﻿namespace StoreManagement.Forms.frm_Sale
{
    partial class FrmSaleAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSaleAdd));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.jsPanelBottom = new JSRequirement.Controls.JSPanel();
            this.jS7BtnPrevSale = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnHome = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnDel = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnSeri = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnSale = new JSRequirement.Controls.JS7Btn();
            this.jsPanelTop = new JSRequirement.Controls.JSPanel();
            this.jsGroupBox1 = new JSRequirement.Controls.JSGroupBox();
            this.jsPanelTopLeft = new JSRequirement.Controls.JSPanel();
            this.jsclblAddValue = new JSRequirement.Controls.JSLabel();
            this.jstxtSDesc = new JSRequirement.Controls.JSTextBox();
            this.jsPanelTopRight = new JSRequirement.Controls.JSPanel();
            this.jsLblSaleDesc = new JSRequirement.Controls.JSLabel();
            this.jsLblCustomer = new JSRequirement.Controls.JSLabel();
            this.jsChkCredit = new JSRequirement.Controls.JSCheckBox();
            this.jsCmbCustomer = new JSRequirement.Controls.JSComboBox();
            this.jsBarCodeBox1 = new JSRequirement.Controls.JSBarCodeBox();
            this.jsLabel1 = new JSRequirement.Controls.JSLabel();
            this.jsPanelCenter = new JSRequirement.Controls.JSPanel();
            this.jsDataGrid1 = new JSRequirement.Controls.JSDataGrid();
            this.jsPanel1 = new JSRequirement.Controls.JSPanel();
            this.jsclblTDiscountCaption = new JSRequirement.Controls.JSLabel();
            this.jsLabel3 = new JSRequirement.Controls.JSLabel();
            this.jsLblTotalSalePersianDesc = new JSRequirement.Controls.JSLabel();
            this.jsclblTDiscount = new JSRequirement.Controls.JSLabel();
            this.jsclblTPrice = new JSRequirement.Controls.JSLabel();
            this.jsLabel2 = new JSRequirement.Controls.JSLabel();
            this.jsPanelBottom.SuspendLayout();
            this.jsPanelTop.SuspendLayout();
            this.jsGroupBox1.SuspendLayout();
            this.jsPanelTopLeft.SuspendLayout();
            this.jsPanelTopRight.SuspendLayout();
            this.jsPanelCenter.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).BeginInit();
            this.jsPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsPanelBottom
            // 
            this.jsPanelBottom.BackColor = System.Drawing.Color.Transparent;
            this.jsPanelBottom.Controls.Add(this.jS7BtnPrevSale);
            this.jsPanelBottom.Controls.Add(this.jS7BtnHome);
            this.jsPanelBottom.Controls.Add(this.jS7BtnDel);
            this.jsPanelBottom.Controls.Add(this.jS7BtnSeri);
            this.jsPanelBottom.Controls.Add(this.jS7BtnSale);
            this.jsPanelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.jsPanelBottom.Location = new System.Drawing.Point(0, 507);
            this.jsPanelBottom.Name = "jsPanelBottom";
            this.jsPanelBottom.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanelBottom.Size = new System.Drawing.Size(809, 55);
            this.jsPanelBottom.TabIndex = 2;
            // 
            // jS7BtnPrevSale
            // 
            this.jS7BtnPrevSale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnPrevSale.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnPrevSale.ButtonText = "فروش قبلی";
            this.jS7BtnPrevSale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnPrevSale.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnPrevSale.Location = new System.Drawing.Point(284, 10);
            this.jS7BtnPrevSale.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnPrevSale.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnPrevSale.Name = "jS7BtnPrevSale";
            this.jS7BtnPrevSale.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnPrevSale.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnPrevSale.TabIndex = 4;
            this.jS7BtnPrevSale.Text = "jS7Btn1";
            this.jS7BtnPrevSale.UseVisualStyleBackColor = false;
            this.jS7BtnPrevSale.Click += new System.EventHandler(this.JS7BtnPrevSaleClick);
            // 
            // jS7BtnHome
            // 
            this.jS7BtnHome.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Home;
            this.jS7BtnHome.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnHome.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnHome.ButtonText = "بازگشت";
            this.jS7BtnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnHome.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnHome.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnHome.Image")));
            this.jS7BtnHome.Location = new System.Drawing.Point(16, 10);
            this.jS7BtnHome.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnHome.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnHome.Name = "jS7BtnHome";
            this.jS7BtnHome.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnHome.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnHome.TabIndex = 3;
            this.jS7BtnHome.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnHome.UseVisualStyleBackColor = false;
            this.jS7BtnHome.Click += new System.EventHandler(this.JS7BtnHomeClick);
            // 
            // jS7BtnDel
            // 
            this.jS7BtnDel.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Delete;
            this.jS7BtnDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnDel.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnDel.ButtonText = "حذف";
            this.jS7BtnDel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnDel.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnDel.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnDel.Image")));
            this.jS7BtnDel.Location = new System.Drawing.Point(150, 10);
            this.jS7BtnDel.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnDel.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnDel.Name = "jS7BtnDel";
            this.jS7BtnDel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnDel.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnDel.TabIndex = 2;
            this.jS7BtnDel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnDel.UseVisualStyleBackColor = false;
            this.jS7BtnDel.Click += new System.EventHandler(this.JS7BtnDelClick);
            // 
            // jS7BtnSeri
            // 
            this.jS7BtnSeri.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnSeri.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnSeri.ButtonText = "فروش موازی";
            this.jS7BtnSeri.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnSeri.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnSeri.Location = new System.Drawing.Point(418, 10);
            this.jS7BtnSeri.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnSeri.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnSeri.Name = "jS7BtnSeri";
            this.jS7BtnSeri.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnSeri.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnSeri.TabIndex = 1;
            this.jS7BtnSeri.Text = "jS7Btn2";
            this.jS7BtnSeri.UseVisualStyleBackColor = false;
            this.jS7BtnSeri.Click += new System.EventHandler(this.JS7BtnSeriClick);
            // 
            // jS7BtnSale
            // 
            this.jS7BtnSale.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnSale.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnSale.ButtonText = "ثبت";
            this.jS7BtnSale.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnSale.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnSale.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnSale.Image")));
            this.jS7BtnSale.Location = new System.Drawing.Point(552, 10);
            this.jS7BtnSale.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnSale.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnSale.Name = "jS7BtnSale";
            this.jS7BtnSale.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnSale.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnSale.TabIndex = 0;
            this.jS7BtnSale.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnSale.UseVisualStyleBackColor = false;
            this.jS7BtnSale.Click += new System.EventHandler(this.JS7BtnSaleClick);
            // 
            // jsPanelTop
            // 
            this.jsPanelTop.BackColor = System.Drawing.Color.Transparent;
            this.jsPanelTop.Controls.Add(this.jsGroupBox1);
            this.jsPanelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.jsPanelTop.Location = new System.Drawing.Point(0, 0);
            this.jsPanelTop.Name = "jsPanelTop";
            this.jsPanelTop.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanelTop.Size = new System.Drawing.Size(809, 116);
            this.jsPanelTop.TabIndex = 3;
            // 
            // jsGroupBox1
            // 
            this.jsGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox1.Controls.Add(this.jsPanelTopLeft);
            this.jsGroupBox1.Controls.Add(this.jsPanelTopRight);
            this.jsGroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.jsGroupBox1.Name = "jsGroupBox1";
            this.jsGroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox1.Size = new System.Drawing.Size(809, 116);
            this.jsGroupBox1.TabIndex = 0;
            this.jsGroupBox1.TabStop = false;
            this.jsGroupBox1.Text = "لطفا پس از انتخاب مشتری و نوع فروش در صورت لزوم توضیحات لازم را نیز وارد نمایید";
            // 
            // jsPanelTopLeft
            // 
            this.jsPanelTopLeft.BackColor = System.Drawing.Color.Transparent;
            this.jsPanelTopLeft.Controls.Add(this.jsclblAddValue);
            this.jsPanelTopLeft.Controls.Add(this.jstxtSDesc);
            this.jsPanelTopLeft.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsPanelTopLeft.Location = new System.Drawing.Point(3, 26);
            this.jsPanelTopLeft.Name = "jsPanelTopLeft";
            this.jsPanelTopLeft.Padding = new System.Windows.Forms.Padding(7);
            this.jsPanelTopLeft.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanelTopLeft.Size = new System.Drawing.Size(414, 87);
            this.jsPanelTopLeft.TabIndex = 7;
            // 
            // jsclblAddValue
            // 
            this.jsclblAddValue.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsclblAddValue.AutoSize = true;
            this.jsclblAddValue.BackColor = System.Drawing.Color.Transparent;
            this.jsclblAddValue.Location = new System.Drawing.Point(7, 59);
            this.jsclblAddValue.Name = "jsclblAddValue";
            this.jsclblAddValue.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsclblAddValue.Size = new System.Drawing.Size(17, 22);
            this.jsclblAddValue.TabIndex = 0;
            this.jsclblAddValue.Text = "+";
            this.jsclblAddValue.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtSDesc
            // 
            this.jstxtSDesc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jstxtSDesc.Location = new System.Drawing.Point(7, 7);
            this.jstxtSDesc.MaxLength = 200;
            this.jstxtSDesc.Multiline = true;
            this.jstxtSDesc.Name = "jstxtSDesc";
            this.jstxtSDesc.Num16 = ((short)(0));
            this.jstxtSDesc.Num32 = 0;
            this.jstxtSDesc.Num64 = ((long)(0));
            this.jstxtSDesc.NumByte = ((byte)(0));
            this.jstxtSDesc.NumDouble = 0D;
            this.jstxtSDesc.NumFloat = 0F;
            this.jstxtSDesc.PersianText = true;
            this.jstxtSDesc.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtSDesc.Size = new System.Drawing.Size(400, 73);
            this.jstxtSDesc.TabIndex = 0;
            // 
            // jsPanelTopRight
            // 
            this.jsPanelTopRight.BackColor = System.Drawing.Color.Transparent;
            this.jsPanelTopRight.Controls.Add(this.jsLblSaleDesc);
            this.jsPanelTopRight.Controls.Add(this.jsLblCustomer);
            this.jsPanelTopRight.Controls.Add(this.jsChkCredit);
            this.jsPanelTopRight.Controls.Add(this.jsCmbCustomer);
            this.jsPanelTopRight.Controls.Add(this.jsBarCodeBox1);
            this.jsPanelTopRight.Controls.Add(this.jsLabel1);
            this.jsPanelTopRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.jsPanelTopRight.Location = new System.Drawing.Point(417, 26);
            this.jsPanelTopRight.Name = "jsPanelTopRight";
            this.jsPanelTopRight.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanelTopRight.Size = new System.Drawing.Size(389, 87);
            this.jsPanelTopRight.TabIndex = 6;
            // 
            // jsLblSaleDesc
            // 
            this.jsLblSaleDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLblSaleDesc.AutoSize = true;
            this.jsLblSaleDesc.BackColor = System.Drawing.Color.Transparent;
            this.jsLblSaleDesc.Location = new System.Drawing.Point(3, 10);
            this.jsLblSaleDesc.Name = "jsLblSaleDesc";
            this.jsLblSaleDesc.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLblSaleDesc.Size = new System.Drawing.Size(39, 22);
            this.jsLblSaleDesc.TabIndex = 6;
            this.jsLblSaleDesc.Text = "توضیح";
            this.jsLblSaleDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLblCustomer
            // 
            this.jsLblCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLblCustomer.AutoSize = true;
            this.jsLblCustomer.BackColor = System.Drawing.Color.Transparent;
            this.jsLblCustomer.Location = new System.Drawing.Point(319, 16);
            this.jsLblCustomer.Name = "jsLblCustomer";
            this.jsLblCustomer.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLblCustomer.Size = new System.Drawing.Size(42, 22);
            this.jsLblCustomer.TabIndex = 2;
            this.jsLblCustomer.Text = "مشتری";
            this.jsLblCustomer.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsChkCredit
            // 
            this.jsChkCredit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsChkCredit.BackColor = System.Drawing.Color.Transparent;
            this.jsChkCredit.Location = new System.Drawing.Point(2, 48);
            this.jsChkCredit.Name = "jsChkCredit";
            this.jsChkCredit.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsChkCredit.Size = new System.Drawing.Size(97, 28);
            this.jsChkCredit.TabIndex = 1;
            this.jsChkCredit.Text = "فروش اعتباری";
            this.jsChkCredit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.jsChkCredit.UseVisualStyleBackColor = false;
            // 
            // jsCmbCustomer
            // 
            this.jsCmbCustomer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsCmbCustomer.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.jsCmbCustomer.FormattingEnabled = true;
            this.jsCmbCustomer.Location = new System.Drawing.Point(105, 14);
            this.jsCmbCustomer.Name = "jsCmbCustomer";
            this.jsCmbCustomer.PersianText = true;
            this.jsCmbCustomer.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsCmbCustomer.Size = new System.Drawing.Size(208, 30);
            this.jsCmbCustomer.TabIndex = 5;
            // 
            // jsBarCodeBox1
            // 
            this.jsBarCodeBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsBarCodeBox1.Enabled = false;
            this.jsBarCodeBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jsBarCodeBox1.Location = new System.Drawing.Point(105, 50);
            this.jsBarCodeBox1.MaxLength = 20;
            this.jsBarCodeBox1.Name = "jsBarCodeBox1";
            this.jsBarCodeBox1.PersianText = true;
            this.jsBarCodeBox1.ReadOnly = true;
            this.jsBarCodeBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jsBarCodeBox1.Size = new System.Drawing.Size(208, 26);
            this.jsBarCodeBox1.TabIndex = 3;
            this.jsBarCodeBox1.TabStop = false;
            this.jsBarCodeBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel1
            // 
            this.jsLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel1.AutoSize = true;
            this.jsLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel1.Location = new System.Drawing.Point(319, 54);
            this.jsLabel1.Name = "jsLabel1";
            this.jsLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel1.Size = new System.Drawing.Size(63, 22);
            this.jsLabel1.TabIndex = 4;
            this.jsLabel1.Text = "آخرین بارکد";
            this.jsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsPanelCenter
            // 
            this.jsPanelCenter.BackColor = System.Drawing.Color.Transparent;
            this.jsPanelCenter.Controls.Add(this.jsDataGrid1);
            this.jsPanelCenter.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsPanelCenter.Location = new System.Drawing.Point(0, 116);
            this.jsPanelCenter.Name = "jsPanelCenter";
            this.jsPanelCenter.Padding = new System.Windows.Forms.Padding(3);
            this.jsPanelCenter.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanelCenter.Size = new System.Drawing.Size(809, 309);
            this.jsPanelCenter.TabIndex = 0;
            // 
            // jsDataGrid1
            // 
            this.jsDataGrid1.AllowUserToOrderColumns = true;
            this.jsDataGrid1.AllowUserToResizeRows = false;
            this.jsDataGrid1.BackgroundColor = System.Drawing.Color.White;
            this.jsDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("B Mitra", 12F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.jsDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.jsDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.jsDataGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsDataGrid1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnEnter;
            this.jsDataGrid1.GridColor = System.Drawing.Color.LightGray;
            this.jsDataGrid1.JSCustomSetting = false;
            this.jsDataGrid1.Location = new System.Drawing.Point(3, 3);
            this.jsDataGrid1.MultiSelect = false;
            this.jsDataGrid1.Name = "jsDataGrid1";
            this.jsDataGrid1.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.jsDataGrid1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.jsDataGrid1.RowTemplate.Height = 26;
            this.jsDataGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.jsDataGrid1.Size = new System.Drawing.Size(803, 303);
            this.jsDataGrid1.StandardTab = true;
            this.jsDataGrid1.TabIndex = 0;
            this.jsDataGrid1.CellValidated += new System.Windows.Forms.DataGridViewCellEventHandler(this.JSDataGrid1CellValidated);
            this.jsDataGrid1.CellValidating += new System.Windows.Forms.DataGridViewCellValidatingEventHandler(this.JSDataGrid1CellValidating);
            this.jsDataGrid1.RowEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.JSDataGrid1RowEnter);
            this.jsDataGrid1.Enter += new System.EventHandler(this.JSDataGrid1Enter);
            // 
            // jsPanel1
            // 
            this.jsPanel1.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel1.Controls.Add(this.jsclblTDiscountCaption);
            this.jsPanel1.Controls.Add(this.jsLabel3);
            this.jsPanel1.Controls.Add(this.jsLblTotalSalePersianDesc);
            this.jsPanel1.Controls.Add(this.jsclblTDiscount);
            this.jsPanel1.Controls.Add(this.jsclblTPrice);
            this.jsPanel1.Controls.Add(this.jsLabel2);
            this.jsPanel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.jsPanel1.Location = new System.Drawing.Point(0, 425);
            this.jsPanel1.Name = "jsPanel1";
            this.jsPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel1.Size = new System.Drawing.Size(809, 82);
            this.jsPanel1.TabIndex = 4;
            // 
            // jsclblTDiscountCaption
            // 
            this.jsclblTDiscountCaption.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsclblTDiscountCaption.AutoSize = true;
            this.jsclblTDiscountCaption.BackColor = System.Drawing.Color.Transparent;
            this.jsclblTDiscountCaption.Location = new System.Drawing.Point(141, 23);
            this.jsclblTDiscountCaption.Name = "jsclblTDiscountCaption";
            this.jsclblTDiscountCaption.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsclblTDiscountCaption.Size = new System.Drawing.Size(69, 22);
            this.jsclblTDiscountCaption.TabIndex = 6;
            this.jsclblTDiscountCaption.Text = "تومان تخفیف";
            this.jsclblTDiscountCaption.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel3
            // 
            this.jsLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel3.AutoSize = true;
            this.jsLabel3.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel3.Location = new System.Drawing.Point(410, 21);
            this.jsLabel3.Name = "jsLabel3";
            this.jsLabel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel3.Size = new System.Drawing.Size(34, 22);
            this.jsLabel3.TabIndex = 5;
            this.jsLabel3.Text = "تومان";
            this.jsLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLblTotalSalePersianDesc
            // 
            this.jsLblTotalSalePersianDesc.BackColor = System.Drawing.Color.Transparent;
            this.jsLblTotalSalePersianDesc.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.jsLblTotalSalePersianDesc.Font = new System.Drawing.Font("B Mitra", 16F);
            this.jsLblTotalSalePersianDesc.Location = new System.Drawing.Point(0, 49);
            this.jsLblTotalSalePersianDesc.Name = "jsLblTotalSalePersianDesc";
            this.jsLblTotalSalePersianDesc.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jsLblTotalSalePersianDesc.Size = new System.Drawing.Size(809, 33);
            this.jsLblTotalSalePersianDesc.TabIndex = 4;
            this.jsLblTotalSalePersianDesc.Text = "...";
            this.jsLblTotalSalePersianDesc.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // jsclblTDiscount
            // 
            this.jsclblTDiscount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsclblTDiscount.AutoSize = true;
            this.jsclblTDiscount.BackColor = System.Drawing.Color.Transparent;
            this.jsclblTDiscount.Font = new System.Drawing.Font("B Mitra", 24F);
            this.jsclblTDiscount.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.jsclblTDiscount.Location = new System.Drawing.Point(216, 8);
            this.jsclblTDiscount.Name = "jsclblTDiscount";
            this.jsclblTDiscount.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsclblTDiscount.Size = new System.Drawing.Size(33, 45);
            this.jsclblTDiscount.TabIndex = 2;
            this.jsclblTDiscount.Text = "0";
            this.jsclblTDiscount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsclblTPrice
            // 
            this.jsclblTPrice.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsclblTPrice.AutoSize = true;
            this.jsclblTPrice.BackColor = System.Drawing.Color.Transparent;
            this.jsclblTPrice.Font = new System.Drawing.Font("B Mitra", 30F, System.Drawing.FontStyle.Bold);
            this.jsclblTPrice.ForeColor = System.Drawing.Color.MidnightBlue;
            this.jsclblTPrice.Location = new System.Drawing.Point(450, 1);
            this.jsclblTPrice.Name = "jsclblTPrice";
            this.jsclblTPrice.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsclblTPrice.Size = new System.Drawing.Size(46, 60);
            this.jsclblTPrice.TabIndex = 1;
            this.jsclblTPrice.Text = "0";
            this.jsclblTPrice.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel2
            // 
            this.jsLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel2.AutoSize = true;
            this.jsLabel2.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel2.Font = new System.Drawing.Font("B Mitra", 16F);
            this.jsLabel2.Location = new System.Drawing.Point(701, 18);
            this.jsLabel2.Name = "jsLabel2";
            this.jsLabel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel2.Size = new System.Drawing.Size(105, 30);
            this.jsLabel2.TabIndex = 3;
            this.jsLabel2.Text = "جمع کل فاکتور";
            this.jsLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmSaleAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(884, 562);
            this.Controls.Add(this.jsPanelCenter);
            this.Controls.Add(this.jsPanel1);
            this.Controls.Add(this.jsPanelTop);
            this.Controls.Add(this.jsPanelBottom);
            this.DoubleBuffered = true;
            this.FormTitle = "فروش";
            this.MinimumSize = new System.Drawing.Size(800, 600);
            this.Name = "FrmSaleAdd";
            this.Text = "سامانه مدیریت فروشگاه | فروش";
            this.BarcodeTaken += new System.EventHandler(this.FrmSaleAddBarcodeTaken);
            this.NumberTaken += new System.EventHandler(this.FrmSaleAddNumberTaken);
            this.OneNumTaken += new System.EventHandler(this.FrmSaleAdd_OneNumTaken);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmSaleAddFormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmSaleAddKeyDown);
            this.Controls.SetChildIndex(this.jsPanelBottom, 0);
            this.Controls.SetChildIndex(this.jsPanelTop, 0);
            this.Controls.SetChildIndex(this.jsPanel1, 0);
            this.Controls.SetChildIndex(this.jsPanelCenter, 0);
            this.jsPanelBottom.ResumeLayout(false);
            this.jsPanelTop.ResumeLayout(false);
            this.jsGroupBox1.ResumeLayout(false);
            this.jsPanelTopLeft.ResumeLayout(false);
            this.jsPanelTopLeft.PerformLayout();
            this.jsPanelTopRight.ResumeLayout(false);
            this.jsPanelTopRight.PerformLayout();
            this.jsPanelCenter.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).EndInit();
            this.jsPanel1.ResumeLayout(false);
            this.jsPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSPanel jsPanelBottom;
        private JSRequirement.Controls.JSPanel jsPanelTop;
        private JSRequirement.Controls.JS7Btn jS7BtnDel;
        private JSRequirement.Controls.JS7Btn jS7BtnSeri;
        private JSRequirement.Controls.JS7Btn jS7BtnSale;
        private JSRequirement.Controls.JS7Btn jS7BtnHome;
        private JSRequirement.Controls.JSPanel jsPanelCenter;
        private JSRequirement.Controls.JSGroupBox jsGroupBox1;
        private JSRequirement.Controls.JSCheckBox jsChkCredit;
        private JSRequirement.Controls.JSLabel jsLblCustomer;
        private JSRequirement.Controls.JSLabel jsLabel1;
        private JSRequirement.Controls.JSBarCodeBox jsBarCodeBox1;
        private JSRequirement.Controls.JSComboBox jsCmbCustomer;
        private JSRequirement.Controls.JSPanel jsPanelTopRight;
        private JSRequirement.Controls.JSPanel jsPanelTopLeft;
        private JSRequirement.Controls.JSTextBox jstxtSDesc;
        private JSRequirement.Controls.JSLabel jsLblSaleDesc;
        private JSRequirement.Controls.JSDataGrid jsDataGrid1;
        private JSRequirement.Controls.JSPanel jsPanel1;
        private JSRequirement.Controls.JSLabel jsclblAddValue;
        private JSRequirement.Controls.JSLabel jsclblTDiscount;
        private JSRequirement.Controls.JSLabel jsclblTPrice;
        private JSRequirement.Controls.JSLabel jsLabel2;
        private JSRequirement.Controls.JSLabel jsLblTotalSalePersianDesc;
        private JSRequirement.Controls.JSLabel jsLabel3;
        private JSRequirement.Controls.JSLabel jsclblTDiscountCaption;
        private JSRequirement.Controls.JS7Btn jS7BtnPrevSale;
    }
}
