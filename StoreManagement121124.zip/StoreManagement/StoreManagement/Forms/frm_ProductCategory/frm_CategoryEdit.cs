﻿using System;

namespace StoreManagement.Forms.frm_ProductCategory
{
    public partial class FrmCategoryEdit : Requirement.FrmPopup
    {
        private readonly Int16 _catid;
        public FrmCategoryEdit(Int16 cid, string cName)
        {
            InitializeComponent();
            _catid = cid;
            jsTextBox1.Text = cName;
        }

        private void JS7Btn2Click(object sender, EventArgs e)
        {
            Close();
        }

        private void JSTextBox1TextChanged(object sender, EventArgs e)
        {
            jS7Btn1.Enabled = !string.IsNullOrWhiteSpace(jsTextBox1.Text);
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {
            new Requirement.SMLinqDataContext()
                .JSP_SM_ProductsCategory_Edit(_catid,jsTextBox1.Text,DateTime.Now);
            Close();
        }
    }
}
