﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace StoreManagement.Forms.frm_User
{
    public partial class FrmUser : Requirement.JSfrmBase
    {
        public FrmUser()
        {
            InitializeComponent();
            UpdateDateGrid();
        }

        public void UpdateDateGrid()
        {
            jsDataGrid1.DataSource = new Requirement.SMLinqDataContext().tbl_DB_Users;
        }



        private void JS7Btn3Click(object sender, EventArgs e)
        {
            try
            {
                if (jsDataGrid1.CurrentRow == null)
                    return;

                var uid = Convert.ToByte(jsDataGrid1.CurrentRow.Cells["UserID"].Value);
                if (new Requirement.SMLinqDataContext().tbl_SM_Sales.Where(c => c.UserID == uid).Count() > 0)
                {
                    MessageBox.Show(@"این کاربر فروش داشته است" + Environment.NewLine
                                    + @"برای حذف کاربر ابتدا فروش های مربوط به این کاربر را پاک نمایید",
                                    @"توجه"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }

                if (
                    MessageBox.Show(Properties.Settings.Default.AppMsgDelete, @"حذف", MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Question) == DialogResult.No)
                    return;

                new Requirement.SMLinqDataContext().JSP_DB_Users_Delete(uid);
                UpdateDateGrid();
            }
            catch
            {
                MessageBox.Show(@"خطایی در حذف رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void JS7Btn4Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnAddClick(object sender, EventArgs e)
        {
            new FrmUserAdd().ShowDialog();
            UpdateDateGrid();
        }

        private void BtnUpdateClick(object sender, EventArgs e)
        {
            try
            {

                if (jsDataGrid1.CurrentRow == null)
                    return;
                new FrmUserEdit(Convert.ToByte(jsDataGrid1.CurrentRow.Cells["UserID"].Value)).ShowDialog();
                UpdateDateGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                MessageBox.Show(@"خطایی در ویرایش رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
    }
}
