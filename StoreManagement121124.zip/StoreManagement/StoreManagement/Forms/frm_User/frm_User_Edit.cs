﻿using System;
using System.Drawing;
using System.Linq;
using JSRequirement.Codes;

namespace StoreManagement.Forms.frm_User
{
    public partial class FrmUserEdit : Requirement.FrmPopup
    {
        private readonly byte _uid;
        private readonly bool _admin;
        private readonly Int64 _totalsale;
        private readonly bool? _status;
        private string _passcode;

        public FrmUserEdit(byte uid)
        {
            InitializeComponent();

            cmbQuestion.DataSource = new Requirement.SMLinqDataContext().tbl_DB_UsersQuestions;
            cmbQuestion.DisplayMember = "Question";
            cmbQuestion.ValueMember = "QuestionID";

            _uid = uid;
            var db = new Requirement.SMLinqDataContext().tbl_DB_Users.Where(c=> c.UserID == uid).Select(c=>c).First();
            
            txtUserCode.Text = db.UserCode;
            _passcode = db.PassCode;
            txtNicName.Text = db.NikName;
            _admin = db.Admin;
            if (db.Question1 != null) cmbQuestion.SelectedValue = db.Question1.Value;
            if (db.Answer1 != null) txtAnswer.Text = db.Answer1;
            if (db.FName != null) txtFName.Text = db.FName;
            if (db.LName != null) txtLName.Text = db.LName;
            if (db.BirthDate != null) txtBirthDate.Value = (DateTime) db.BirthDate;
            if (db.EMail != null) txtEmail.Text = db.EMail;
            if (db.UDesc != null) txtDesc.Text = db.UDesc;
            _totalsale = db.TotalSales;
            _status = db.Status;
            
        }

        private void BtnCloseClick(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnUpdateClick(object sender, EventArgs e)
        {
            if (txtUserCode.TxtEmpty  || txtNicName.TxtEmpty)
            {
                txtUserCode.BackColor = Color.Red;
                txtNicName.BackColor = Color.Red;
                return;
            }
            if (txtpasscode.Text != txtpasscodeconfirm.Text)
            {
                txtpasscode.BackColor = Color.Red;
                txtpasscodeconfirm.BackColor = Color.Red;
                return;
            }
            if (!txtpasscode.TxtEmpty)
            {
                _passcode = JSSaltHashing.ComputeHash(txtpasscode.Text, txtUserCode.Text);
            }
            
            new Requirement.SMLinqDataContext().JSP_DB_Users_Edit(_uid,txtUserCode.Text, _passcode, txtNicName.Text,
                                                                 _admin, cmbQuestion.SValueByte, txtAnswer.Text,
                                                                 txtFName.Text, txtLName.Text, txtBirthDate.Value,
                                                                 txtEmail.Text, txtDesc.Text, _totalsale, _status, DateTime.Now);
            Close();

        }

        private void TxtpasscodeKeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            txtpasscodeconfirm.Visible = true;
            lblPassCodeConfirm.Visible = true;
        }

    }
}
