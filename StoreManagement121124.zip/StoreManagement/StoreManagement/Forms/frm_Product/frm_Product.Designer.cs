﻿namespace StoreManagement.Forms.frm_Product
{
    partial class FrmProduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmProduct));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.jsPanel1 = new JSRequirement.Controls.JSPanel();
            this.jS7BtnHome = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnDel = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnUpdate = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnAdd = new JSRequirement.Controls.JS7Btn();
            this.jsPanel2 = new JSRequirement.Controls.JSPanel();
            this.jsDataGrid1 = new JSRequirement.Controls.JSDataGrid();
            this.ProductID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCategory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductCategoryID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductsUnit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProductsUnitID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PSize = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PBuyPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PDiscount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PStock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PMinInventory = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PSold = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PBarCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PBarCode2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jsPanel3 = new JSRequirement.Controls.JSPanel();
            this.jsGroupBox1 = new JSRequirement.Controls.JSGroupBox();
            this.jsCmbCategory = new JSRequirement.Controls.JSComboBox();
            this.jsLabel1 = new JSRequirement.Controls.JSLabel();
            this.jsGroupBox2 = new JSRequirement.Controls.JSGroupBox();
            this.jscDataDesc = new JSRequirement.Controls.JSLabel();
            this.jsPanel1.SuspendLayout();
            this.jsPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).BeginInit();
            this.jsPanel3.SuspendLayout();
            this.jsGroupBox1.SuspendLayout();
            this.jsGroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsPanel1
            // 
            this.jsPanel1.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel1.Controls.Add(this.jS7BtnHome);
            this.jsPanel1.Controls.Add(this.jS7BtnDel);
            this.jsPanel1.Controls.Add(this.jS7BtnUpdate);
            this.jsPanel1.Controls.Add(this.jS7BtnAdd);
            this.jsPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.jsPanel1.Location = new System.Drawing.Point(0, 69);
            this.jsPanel1.Name = "jsPanel1";
            this.jsPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel1.Size = new System.Drawing.Size(140, 253);
            this.jsPanel1.TabIndex = 2;
            // 
            // jS7BtnHome
            // 
            this.jS7BtnHome.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Home;
            this.jS7BtnHome.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnHome.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnHome.ButtonText = "بازگشت";
            this.jS7BtnHome.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnHome.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnHome.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnHome.Image")));
            this.jS7BtnHome.Location = new System.Drawing.Point(10, 197);
            this.jS7BtnHome.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnHome.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnHome.Name = "jS7BtnHome";
            this.jS7BtnHome.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnHome.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnHome.TabIndex = 3;
            this.jS7BtnHome.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnHome.UseVisualStyleBackColor = false;
            this.jS7BtnHome.Click += new System.EventHandler(this.JS7BtnHomeClick);
            // 
            // jS7BtnDel
            // 
            this.jS7BtnDel.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Delete;
            this.jS7BtnDel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnDel.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnDel.ButtonText = "حذف";
            this.jS7BtnDel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnDel.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnDel.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnDel.Image")));
            this.jS7BtnDel.Location = new System.Drawing.Point(10, 143);
            this.jS7BtnDel.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnDel.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnDel.Name = "jS7BtnDel";
            this.jS7BtnDel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnDel.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnDel.TabIndex = 2;
            this.jS7BtnDel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnDel.UseVisualStyleBackColor = false;
            this.jS7BtnDel.Click += new System.EventHandler(this.JS7BtnDelClick);
            // 
            // jS7BtnUpdate
            // 
            this.jS7BtnUpdate.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Update;
            this.jS7BtnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnUpdate.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnUpdate.ButtonText = "به روز رسانی";
            this.jS7BtnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnUpdate.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnUpdate.Image")));
            this.jS7BtnUpdate.Location = new System.Drawing.Point(10, 89);
            this.jS7BtnUpdate.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnUpdate.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnUpdate.Name = "jS7BtnUpdate";
            this.jS7BtnUpdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnUpdate.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnUpdate.TabIndex = 1;
            this.jS7BtnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnUpdate.UseVisualStyleBackColor = false;
            this.jS7BtnUpdate.Click += new System.EventHandler(this.JS7BtnUpdateClick);
            // 
            // jS7BtnAdd
            // 
            this.jS7BtnAdd.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Add;
            this.jS7BtnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnAdd.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnAdd.ButtonText = "اضافه کردن";
            this.jS7BtnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnAdd.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnAdd.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnAdd.Image")));
            this.jS7BtnAdd.Location = new System.Drawing.Point(10, 35);
            this.jS7BtnAdd.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnAdd.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnAdd.Name = "jS7BtnAdd";
            this.jS7BtnAdd.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnAdd.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnAdd.TabIndex = 0;
            this.jS7BtnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnAdd.UseVisualStyleBackColor = false;
            this.jS7BtnAdd.Click += new System.EventHandler(this.JS7BtnAddClick);
            // 
            // jsPanel2
            // 
            this.jsPanel2.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel2.Controls.Add(this.jsDataGrid1);
            this.jsPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsPanel2.Location = new System.Drawing.Point(0, 69);
            this.jsPanel2.Name = "jsPanel2";
            this.jsPanel2.Padding = new System.Windows.Forms.Padding(3);
            this.jsPanel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel2.Size = new System.Drawing.Size(927, 253);
            this.jsPanel2.TabIndex = 3;
            // 
            // jsDataGrid1
            // 
            this.jsDataGrid1.AllowUserToAddRows = false;
            this.jsDataGrid1.AllowUserToDeleteRows = false;
            this.jsDataGrid1.AllowUserToOrderColumns = true;
            this.jsDataGrid1.AllowUserToResizeRows = false;
            this.jsDataGrid1.BackgroundColor = System.Drawing.Color.White;
            this.jsDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("B Mitra", 12F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.jsDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.jsDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.jsDataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ProductID,
            this.PName,
            this.ProductCategory,
            this.ProductCategoryID,
            this.ProductsUnit,
            this.ProductsUnitID,
            this.PSize,
            this.PBuyPrice,
            this.PPrice,
            this.PDiscount,
            this.PStock,
            this.PMinInventory,
            this.PSold,
            this.PBarCode,
            this.PBarCode2});
            this.jsDataGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsDataGrid1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.jsDataGrid1.GridColor = System.Drawing.Color.LightGray;
            this.jsDataGrid1.JSCustomSetting = true;
            this.jsDataGrid1.Location = new System.Drawing.Point(3, 3);
            this.jsDataGrid1.MultiSelect = false;
            this.jsDataGrid1.Name = "jsDataGrid1";
            this.jsDataGrid1.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.jsDataGrid1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.jsDataGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.jsDataGrid1.Size = new System.Drawing.Size(921, 247);
            this.jsDataGrid1.TabIndex = 0;
            // 
            // ProductID
            // 
            this.ProductID.DataPropertyName = "ProductID";
            this.ProductID.HeaderText = "کد کالا";
            this.ProductID.Name = "ProductID";
            this.ProductID.Visible = false;
            this.ProductID.Width = 5;
            // 
            // PName
            // 
            this.PName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.PName.DataPropertyName = "PName";
            this.PName.HeaderText = "نام";
            this.PName.MinimumWidth = 120;
            this.PName.Name = "PName";
            // 
            // ProductCategory
            // 
            this.ProductCategory.DataPropertyName = "ProductCategory";
            this.ProductCategory.HeaderText = "دسته بندی";
            this.ProductCategory.MinimumWidth = 120;
            this.ProductCategory.Name = "ProductCategory";
            this.ProductCategory.Width = 150;
            // 
            // ProductCategoryID
            // 
            this.ProductCategoryID.DataPropertyName = "ProductCategoryID";
            this.ProductCategoryID.HeaderText = "ProductCategoryID";
            this.ProductCategoryID.Name = "ProductCategoryID";
            this.ProductCategoryID.Visible = false;
            // 
            // ProductsUnit
            // 
            this.ProductsUnit.DataPropertyName = "ProductsUnit";
            this.ProductsUnit.HeaderText = "واحد شمارش";
            this.ProductsUnit.Name = "ProductsUnit";
            this.ProductsUnit.Width = 92;
            // 
            // ProductsUnitID
            // 
            this.ProductsUnitID.DataPropertyName = "ProductsUnitID";
            this.ProductsUnitID.HeaderText = "ProductsUnitID";
            this.ProductsUnitID.Name = "ProductsUnitID";
            this.ProductsUnitID.Visible = false;
            // 
            // PSize
            // 
            this.PSize.DataPropertyName = "PSize";
            this.PSize.HeaderText = "تعداد در کارتن";
            this.PSize.Name = "PSize";
            this.PSize.Width = 98;
            // 
            // PBuyPrice
            // 
            this.PBuyPrice.DataPropertyName = "PBuyPrice";
            this.PBuyPrice.HeaderText = "قیمت خرید";
            this.PBuyPrice.Name = "PBuyPrice";
            this.PBuyPrice.Width = 85;
            // 
            // PPrice
            // 
            this.PPrice.DataPropertyName = "PPrice";
            this.PPrice.HeaderText = "قیمت فروش";
            this.PPrice.Name = "PPrice";
            this.PPrice.Width = 91;
            // 
            // PDiscount
            // 
            this.PDiscount.DataPropertyName = "PDiscount";
            this.PDiscount.HeaderText = "تخفیف";
            this.PDiscount.Name = "PDiscount";
            this.PDiscount.Width = 66;
            // 
            // PStock
            // 
            this.PStock.DataPropertyName = "PStock";
            this.PStock.HeaderText = "موجودی";
            this.PStock.Name = "PStock";
            this.PStock.Width = 72;
            // 
            // PMinInventory
            // 
            this.PMinInventory.DataPropertyName = "PMinInventory";
            this.PMinInventory.HeaderText = "حداقل موجودی لازم";
            this.PMinInventory.Name = "PMinInventory";
            this.PMinInventory.Visible = false;
            // 
            // PSold
            // 
            this.PSold.DataPropertyName = "PSold";
            this.PSold.HeaderText = "فروخته شده";
            this.PSold.Name = "PSold";
            this.PSold.Visible = false;
            // 
            // PBarCode
            // 
            this.PBarCode.DataPropertyName = "PBarCode";
            this.PBarCode.HeaderText = "بارکد";
            this.PBarCode.Name = "PBarCode";
            this.PBarCode.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.PBarCode.Visible = false;
            // 
            // PBarCode2
            // 
            this.PBarCode2.DataPropertyName = "PBarCode2";
            this.PBarCode2.HeaderText = "ایران بارکد";
            this.PBarCode2.Name = "PBarCode2";
            this.PBarCode2.Visible = false;
            // 
            // jsPanel3
            // 
            this.jsPanel3.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel3.Controls.Add(this.jsGroupBox1);
            this.jsPanel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.jsPanel3.Location = new System.Drawing.Point(0, 0);
            this.jsPanel3.Name = "jsPanel3";
            this.jsPanel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel3.Size = new System.Drawing.Size(927, 69);
            this.jsPanel3.TabIndex = 4;
            // 
            // jsGroupBox1
            // 
            this.jsGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox1.Controls.Add(this.jsCmbCategory);
            this.jsGroupBox1.Controls.Add(this.jsLabel1);
            this.jsGroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.jsGroupBox1.Name = "jsGroupBox1";
            this.jsGroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox1.Size = new System.Drawing.Size(927, 69);
            this.jsGroupBox1.TabIndex = 0;
            this.jsGroupBox1.TabStop = false;
            this.jsGroupBox1.Text = "فیلتر کردن کالاها";
            // 
            // jsCmbCategory
            // 
            this.jsCmbCategory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsCmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.jsCmbCategory.FormattingEnabled = true;
            this.jsCmbCategory.Location = new System.Drawing.Point(3, 26);
            this.jsCmbCategory.Name = "jsCmbCategory";
            this.jsCmbCategory.PersianText = true;
            this.jsCmbCategory.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsCmbCategory.Size = new System.Drawing.Size(479, 30);
            this.jsCmbCategory.TabIndex = 1;
            this.jsCmbCategory.SelectedIndexChanged += new System.EventHandler(this.JSCmbCategorySelectedIndexChanged);
            // 
            // jsLabel1
            // 
            this.jsLabel1.AutoSize = true;
            this.jsLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel1.Dock = System.Windows.Forms.DockStyle.Right;
            this.jsLabel1.Location = new System.Drawing.Point(482, 26);
            this.jsLabel1.Name = "jsLabel1";
            this.jsLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel1.Size = new System.Drawing.Size(442, 22);
            this.jsLabel1.TabIndex = 0;
            this.jsLabel1.Text = "دسته بندی را از لیست روبرو انتخاب نموده تا فقط محصولات موجود در آن دسته نمایش داد" +
    "ه شوند";
            this.jsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.jsLabel1.Click += new System.EventHandler(this.JSLabel1Click);
            // 
            // jsGroupBox2
            // 
            this.jsGroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox2.Controls.Add(this.jscDataDesc);
            this.jsGroupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.jsGroupBox2.Location = new System.Drawing.Point(0, 322);
            this.jsGroupBox2.Name = "jsGroupBox2";
            this.jsGroupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox2.Size = new System.Drawing.Size(927, 54);
            this.jsGroupBox2.TabIndex = 5;
            this.jsGroupBox2.TabStop = false;
            this.jsGroupBox2.Text = "توضیحات";
            // 
            // jscDataDesc
            // 
            this.jscDataDesc.BackColor = System.Drawing.Color.Transparent;
            this.jscDataDesc.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jscDataDesc.Location = new System.Drawing.Point(3, 26);
            this.jscDataDesc.Name = "jscDataDesc";
            this.jscDataDesc.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jscDataDesc.Size = new System.Drawing.Size(921, 25);
            this.jscDataDesc.TabIndex = 0;
            this.jscDataDesc.Text = "---";
            this.jscDataDesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(1002, 376);
            this.Controls.Add(this.jsPanel1);
            this.Controls.Add(this.jsPanel2);
            this.Controls.Add(this.jsGroupBox2);
            this.Controls.Add(this.jsPanel3);
            this.FormTitle = "کالاها";
            this.Name = "FrmProduct";
            this.Text = "سامانه مدیریت فروشگاه | کالاها";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.BarcodeTaken += new System.EventHandler(this.FrmProductBarcodeTaken);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmProductKeyDown);
            this.Controls.SetChildIndex(this.jsPanel3, 0);
            this.Controls.SetChildIndex(this.jsGroupBox2, 0);
            this.Controls.SetChildIndex(this.jsPanel2, 0);
            this.Controls.SetChildIndex(this.jsPanel1, 0);
            this.jsPanel1.ResumeLayout(false);
            this.jsPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).EndInit();
            this.jsPanel3.ResumeLayout(false);
            this.jsGroupBox1.ResumeLayout(false);
            this.jsGroupBox1.PerformLayout();
            this.jsGroupBox2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSPanel jsPanel1;
        private JSRequirement.Controls.JSPanel jsPanel2;
        private JSRequirement.Controls.JSDataGrid jsDataGrid1;
        private JSRequirement.Controls.JS7Btn jS7BtnHome;
        private JSRequirement.Controls.JS7Btn jS7BtnDel;
        private JSRequirement.Controls.JS7Btn jS7BtnUpdate;
        private JSRequirement.Controls.JS7Btn jS7BtnAdd;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCategory;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductCategoryID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductsUnit;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProductsUnitID;
        private System.Windows.Forms.DataGridViewTextBoxColumn PSize;
        private System.Windows.Forms.DataGridViewTextBoxColumn PBuyPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn PPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn PDiscount;
        private System.Windows.Forms.DataGridViewTextBoxColumn PStock;
        private System.Windows.Forms.DataGridViewTextBoxColumn PMinInventory;
        private System.Windows.Forms.DataGridViewTextBoxColumn PSold;
        private System.Windows.Forms.DataGridViewTextBoxColumn PBarCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn PBarCode2;
        private JSRequirement.Controls.JSPanel jsPanel3;
        private JSRequirement.Controls.JSGroupBox jsGroupBox1;
        private JSRequirement.Controls.JSLabel jsLabel1;
        private JSRequirement.Controls.JSComboBox jsCmbCategory;
        private JSRequirement.Controls.JSGroupBox jsGroupBox2;
        private JSRequirement.Controls.JSLabel jscDataDesc;
    }
}
