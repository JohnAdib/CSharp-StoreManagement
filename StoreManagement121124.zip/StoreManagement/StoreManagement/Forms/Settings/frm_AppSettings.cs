﻿using System;
using System.Windows.Forms;
using Microsoft.Win32;

namespace StoreManagement.Forms.Settings
{
    public partial class FrmAppSettings : Requirement.JSfrmBase
    {
        public FrmAppSettings()
        {
            InitializeComponent();
            try
            {
                jsTxtAppname.Text = Properties.Settings.Default.AppName;
                jsTxtAppLoginTryCount.Text = Properties.Settings.Default.AppLoginTryCount.ToString();

                jsCmbDefaultUserCode.DataSource = new Requirement.SMLinqDataContext().tbl_DB_Users;
                jsCmbDefaultUserCode.DisplayMember = "NikName";
                jsCmbDefaultUserCode.ValueMember = "UserCode";


                jsCmbDefaultProduct.DataSource = new Requirement.SMLinqDataContext().tbl_SM_Products;
                jsCmbDefaultProduct.DisplayMember = "PName";
                jsCmbDefaultProduct.ValueMember = "ProductID";


                jsCmbDefaultUserCode.SelectedValue = Properties.Settings.Default.AppLoginDefaultUser;
                jsCmbDefaultProduct.SelectedValue = Convert.ToInt16(Properties.Settings.Default.AppLoginDefaultProduct);
                
            }
            catch (Exception)
            {
                MessageBox.Show(@"خطایی در بارگزاری تنظیمات رخ داده است",@"خطا");
                return;
            }
        }

        private void JS7BtnUpdateClick(object sender, EventArgs e)
        {
            try
            {
                Properties.Settings.Default.AppName = jsTxtAppname.Text;
                Properties.Settings.Default.AppLoginTryCount = jsTxtAppLoginTryCount.NumByte;
                Properties.Settings.Default.AppLoginDefaultUser = jsCmbDefaultUserCode.SelectedValue.ToString();
                Properties.Settings.Default.AppLoginDefaultProduct = jsCmbDefaultProduct.SValue.ToString();
                Properties.Settings.Default.Save();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, @"خطا");
                return;
            }
            Close();
        }

        private void JS7BtnCloseClick(object sender, EventArgs e)
        {
            Close();
        }

        private void JSChkStartupRunCheckedChanged(object sender, EventArgs e)
        {
            try
            {
                var rk = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
                //Registry.LocalMachine.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true);
                if (rk != null)
                {
                    if (jsChkStartupRun.Checked)
                        rk.SetValue(Application.ProductName, Application.ExecutablePath);
                    else
                        rk.DeleteValue(Application.ProductName, false);
                }
            }
            catch(Exception ex )
            {
                MessageBox.Show(ex.Source, @"خطا");
            }
        }
    }
}
