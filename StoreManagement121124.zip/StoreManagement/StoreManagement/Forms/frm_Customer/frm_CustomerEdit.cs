﻿using System;

namespace StoreManagement.Forms.frm_Customer
{
    public partial class FrmCustomerEdit : Requirement.FrmPopup
    {
        private readonly short _cid;

        public FrmCustomerEdit(Int16 cid, string cName, string cAddress, string cTel, string cMobile, bool cCredit)
        {
            InitializeComponent();
            _cid = cid;
            jstxtCName.Text = cName;
            jstxtAddress.Text = cAddress;
            jstxtTel.Text = cTel;
            jstxtMobile.Text = cMobile;
            jsChkCredit.Checked = cCredit;
        }

        private void JS7BtnEditClick(object sender, EventArgs e)
        {
            new Requirement.SMLinqDataContext().JSP_SM_Customers_Edit(_cid, jstxtCName.Text, 
                jstxtAddress.Text, jstxtTel.Text, jstxtMobile.Text,jsChkCredit.Checked, DateTime.Now);
            Close();
        }

        private void JS7BtnCloseClick(object sender, EventArgs e)
        {
            Close();
        }

    }
}
