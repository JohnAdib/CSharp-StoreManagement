﻿namespace StoreManagement.Forms.frm_Supplier
{
    partial class FrmSupplierAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmSupplierAdd));
            this.jsGroupBox1 = new JSRequirement.Controls.JSGroupBox();
            this.jS7BtnAdd = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnClose = new JSRequirement.Controls.JS7Btn();
            this.jsLabel5 = new JSRequirement.Controls.JSLabel();
            this.jsLabel4 = new JSRequirement.Controls.JSLabel();
            this.jsLabel3 = new JSRequirement.Controls.JSLabel();
            this.jsLabel2 = new JSRequirement.Controls.JSLabel();
            this.jsLabel1 = new JSRequirement.Controls.JSLabel();
            this.jstxtDesc = new JSRequirement.Controls.JSTextBox();
            this.jstxtTel = new JSRequirement.Controls.JSTextBox();
            this.jstxtAddress = new JSRequirement.Controls.JSTextBox();
            this.jstxtVisitor = new JSRequirement.Controls.JSTextBox();
            this.jsTxtName = new JSRequirement.Controls.JSTextBox();
            this.jsLabel6 = new JSRequirement.Controls.JSLabel();
            this.jsTxtMobile = new JSRequirement.Controls.JSTextBox();
            this.jsGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsGroupBox1
            // 
            this.jsGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox1.Controls.Add(this.jsLabel6);
            this.jsGroupBox1.Controls.Add(this.jsTxtMobile);
            this.jsGroupBox1.Controls.Add(this.jS7BtnAdd);
            this.jsGroupBox1.Controls.Add(this.jS7BtnClose);
            this.jsGroupBox1.Controls.Add(this.jsLabel5);
            this.jsGroupBox1.Controls.Add(this.jsLabel4);
            this.jsGroupBox1.Controls.Add(this.jsLabel3);
            this.jsGroupBox1.Controls.Add(this.jsLabel2);
            this.jsGroupBox1.Controls.Add(this.jsLabel1);
            this.jsGroupBox1.Controls.Add(this.jstxtDesc);
            this.jsGroupBox1.Controls.Add(this.jstxtTel);
            this.jsGroupBox1.Controls.Add(this.jstxtAddress);
            this.jsGroupBox1.Controls.Add(this.jstxtVisitor);
            this.jsGroupBox1.Controls.Add(this.jsTxtName);
            this.jsGroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.jsGroupBox1.Name = "jsGroupBox1";
            this.jsGroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox1.Size = new System.Drawing.Size(475, 292);
            this.jsGroupBox1.TabIndex = 0;
            this.jsGroupBox1.TabStop = false;
            this.jsGroupBox1.Text = "مشخصات شرکت توزیع کننده را وارد نمایید";
            // 
            // jS7BtnAdd
            // 
            this.jS7BtnAdd.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Add;
            this.jS7BtnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnAdd.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnAdd.ButtonText = "اضافه کردن";
            this.jS7BtnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnAdd.Enabled = false;
            this.jS7BtnAdd.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnAdd.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnAdd.Image")));
            this.jS7BtnAdd.Location = new System.Drawing.Point(158, 242);
            this.jS7BtnAdd.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnAdd.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnAdd.Name = "jS7BtnAdd";
            this.jS7BtnAdd.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnAdd.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnAdd.TabIndex = 1;
            this.jS7BtnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnAdd.UseVisualStyleBackColor = false;
            this.jS7BtnAdd.Click += new System.EventHandler(this.JS7Btn1Click);
            // 
            // jS7BtnClose
            // 
            this.jS7BtnClose.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Close;
            this.jS7BtnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnClose.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnClose.ButtonText = "بستن";
            this.jS7BtnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnClose.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnClose.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnClose.Image")));
            this.jS7BtnClose.Location = new System.Drawing.Point(24, 242);
            this.jS7BtnClose.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnClose.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnClose.Name = "jS7BtnClose";
            this.jS7BtnClose.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnClose.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnClose.TabIndex = 2;
            this.jS7BtnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnClose.UseVisualStyleBackColor = false;
            this.jS7BtnClose.Click += new System.EventHandler(this.JS7Btn2Click);
            // 
            // jsLabel5
            // 
            this.jsLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel5.AutoSize = true;
            this.jsLabel5.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel5.Location = new System.Drawing.Point(391, 161);
            this.jsLabel5.Name = "jsLabel5";
            this.jsLabel5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel5.Size = new System.Drawing.Size(39, 22);
            this.jsLabel5.TabIndex = 9;
            this.jsLabel5.Text = "توضیح";
            this.jsLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel4
            // 
            this.jsLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel4.AutoSize = true;
            this.jsLabel4.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel4.Location = new System.Drawing.Point(167, 53);
            this.jsLabel4.Name = "jsLabel4";
            this.jsLabel4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel4.Size = new System.Drawing.Size(30, 22);
            this.jsLabel4.TabIndex = 8;
            this.jsLabel4.Text = "تلفن";
            this.jsLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel3
            // 
            this.jsLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel3.AutoSize = true;
            this.jsLabel3.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel3.Location = new System.Drawing.Point(391, 125);
            this.jsLabel3.Name = "jsLabel3";
            this.jsLabel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel3.Size = new System.Drawing.Size(55, 22);
            this.jsLabel3.TabIndex = 7;
            this.jsLabel3.Text = "نام ویزیتور";
            this.jsLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel2
            // 
            this.jsLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel2.AutoSize = true;
            this.jsLabel2.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel2.Location = new System.Drawing.Point(391, 89);
            this.jsLabel2.Name = "jsLabel2";
            this.jsLabel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel2.Size = new System.Drawing.Size(35, 22);
            this.jsLabel2.TabIndex = 6;
            this.jsLabel2.Text = "آدرس";
            this.jsLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel1
            // 
            this.jsLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel1.AutoSize = true;
            this.jsLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel1.Location = new System.Drawing.Point(391, 53);
            this.jsLabel1.Name = "jsLabel1";
            this.jsLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel1.Size = new System.Drawing.Size(55, 22);
            this.jsLabel1.TabIndex = 5;
            this.jsLabel1.Text = "نام شرکت";
            this.jsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtDesc
            // 
            this.jstxtDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtDesc.Location = new System.Drawing.Point(24, 158);
            this.jstxtDesc.MaxLength = 200;
            this.jstxtDesc.Multiline = true;
            this.jstxtDesc.Name = "jstxtDesc";
            this.jstxtDesc.Num16 = ((short)(0));
            this.jstxtDesc.Num32 = 0;
            this.jstxtDesc.Num64 = ((long)(0));
            this.jstxtDesc.NumByte = ((byte)(0));
            this.jstxtDesc.NumDouble = 0D;
            this.jstxtDesc.PersianText = true;
            this.jstxtDesc.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtDesc.Size = new System.Drawing.Size(361, 60);
            this.jstxtDesc.TabIndex = 4;
            // 
            // jstxtTel
            // 
            this.jstxtTel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtTel.Location = new System.Drawing.Point(24, 50);
            this.jstxtTel.MaxLength = 200;
            this.jstxtTel.Name = "jstxtTel";
            this.jstxtTel.Num16 = ((short)(0));
            this.jstxtTel.Num32 = 0;
            this.jstxtTel.Num64 = ((long)(0));
            this.jstxtTel.NumByte = ((byte)(0));
            this.jstxtTel.NumDouble = 0D;
            this.jstxtTel.PersianText = true;
            this.jstxtTel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtTel.Size = new System.Drawing.Size(137, 30);
            this.jstxtTel.TabIndex = 3;
            // 
            // jstxtAddress
            // 
            this.jstxtAddress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtAddress.Location = new System.Drawing.Point(24, 86);
            this.jstxtAddress.MaxLength = 200;
            this.jstxtAddress.Name = "jstxtAddress";
            this.jstxtAddress.Num16 = ((short)(0));
            this.jstxtAddress.Num32 = 0;
            this.jstxtAddress.Num64 = ((long)(0));
            this.jstxtAddress.NumByte = ((byte)(0));
            this.jstxtAddress.NumDouble = 0D;
            this.jstxtAddress.PersianText = true;
            this.jstxtAddress.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtAddress.Size = new System.Drawing.Size(361, 30);
            this.jstxtAddress.TabIndex = 2;
            // 
            // jstxtVisitor
            // 
            this.jstxtVisitor.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtVisitor.Location = new System.Drawing.Point(203, 122);
            this.jstxtVisitor.MaxLength = 200;
            this.jstxtVisitor.Name = "jstxtVisitor";
            this.jstxtVisitor.Num16 = ((short)(0));
            this.jstxtVisitor.Num32 = 0;
            this.jstxtVisitor.Num64 = ((long)(0));
            this.jstxtVisitor.NumByte = ((byte)(0));
            this.jstxtVisitor.NumDouble = 0D;
            this.jstxtVisitor.PersianText = true;
            this.jstxtVisitor.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtVisitor.Size = new System.Drawing.Size(182, 30);
            this.jstxtVisitor.TabIndex = 1;
            // 
            // jsTxtName
            // 
            this.jsTxtName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsTxtName.Location = new System.Drawing.Point(203, 50);
            this.jsTxtName.MaxLength = 200;
            this.jsTxtName.Name = "jsTxtName";
            this.jsTxtName.Num16 = ((short)(0));
            this.jsTxtName.Num32 = 0;
            this.jsTxtName.Num64 = ((long)(0));
            this.jsTxtName.NumByte = ((byte)(0));
            this.jsTxtName.NumDouble = 0D;
            this.jsTxtName.PersianText = true;
            this.jsTxtName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsTxtName.Size = new System.Drawing.Size(182, 30);
            this.jsTxtName.TabIndex = 0;
            this.jsTxtName.TextChanged += new System.EventHandler(this.JSTxtNameTextChanged);
            // 
            // jsLabel6
            // 
            this.jsLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel6.AutoSize = true;
            this.jsLabel6.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel6.Location = new System.Drawing.Point(167, 125);
            this.jsLabel6.Name = "jsLabel6";
            this.jsLabel6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel6.Size = new System.Drawing.Size(38, 22);
            this.jsLabel6.TabIndex = 11;
            this.jsLabel6.Text = "موبایل";
            this.jsLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsTxtMobile
            // 
            this.jsTxtMobile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsTxtMobile.Location = new System.Drawing.Point(24, 122);
            this.jsTxtMobile.MaxLength = 200;
            this.jsTxtMobile.Name = "jsTxtMobile";
            this.jsTxtMobile.Num16 = ((short)(0));
            this.jsTxtMobile.Num32 = 0;
            this.jsTxtMobile.Num64 = ((long)(0));
            this.jsTxtMobile.NumByte = ((byte)(0));
            this.jsTxtMobile.NumDouble = 0D;
            this.jsTxtMobile.PersianText = true;
            this.jsTxtMobile.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsTxtMobile.Size = new System.Drawing.Size(137, 30);
            this.jsTxtMobile.TabIndex = 10;
            // 
            // FrmSupplierAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(475, 292);
            this.Controls.Add(this.jsGroupBox1);
            this.Name = "FrmSupplierAdd";
            this.Text = "افزودن شرکت توزیع کننده جدید";
            this.jsGroupBox1.ResumeLayout(false);
            this.jsGroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSGroupBox jsGroupBox1;
        private JSRequirement.Controls.JSTextBox jstxtDesc;
        private JSRequirement.Controls.JSTextBox jstxtTel;
        private JSRequirement.Controls.JSTextBox jstxtAddress;
        private JSRequirement.Controls.JSTextBox jstxtVisitor;
        private JSRequirement.Controls.JSTextBox jsTxtName;
        private JSRequirement.Controls.JSLabel jsLabel5;
        private JSRequirement.Controls.JSLabel jsLabel4;
        private JSRequirement.Controls.JSLabel jsLabel3;
        private JSRequirement.Controls.JSLabel jsLabel2;
        private JSRequirement.Controls.JSLabel jsLabel1;
        private JSRequirement.Controls.JS7Btn jS7BtnAdd;
        private JSRequirement.Controls.JS7Btn jS7BtnClose;
        private JSRequirement.Controls.JSLabel jsLabel6;
        private JSRequirement.Controls.JSTextBox jsTxtMobile;
    }
}
