﻿namespace StoreManagement.Requirement
{
    partial class JSMenuStripStoreManagement
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.JSMenuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmHomeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.FrmLoginToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.FrmAppSettingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmUserToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmUnitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmCategoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmProductToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmCustomerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmSupplierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.frmSaleAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmSaleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.frmPurchaseAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.frmPurchaseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notePadToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calculatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.pCDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.serverDetailToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.fileWiperToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.systemToolsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hibernateToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shutDownToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logOffToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.rebootToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.standbyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontsListToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.internetCheckerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.creatorwebsiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sysUpTimeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.JSMenuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // JSMenuStrip
            // 
            this.JSMenuStrip.BackgroundImage = global::StoreManagement.Properties.Resources.LightBackgroundTile;
            this.JSMenuStrip.Dock = System.Windows.Forms.DockStyle.Fill;
            this.JSMenuStrip.Font = new System.Drawing.Font("B Mitra", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(178)));
            this.JSMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolStripMenuItem3,
            this.formsToolStripMenuItem,
            this.toolsToolStripMenuItem,
            this.aboutToolStripMenuItem});
            this.JSMenuStrip.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.JSMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.JSMenuStrip.Margin = new System.Windows.Forms.Padding(3);
            this.JSMenuStrip.Name = "JSMenuStrip";
            this.JSMenuStrip.Padding = new System.Windows.Forms.Padding(3);
            this.JSMenuStrip.Size = new System.Drawing.Size(75, 250);
            this.JSMenuStrip.TabIndex = 0;
            this.JSMenuStrip.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FrmHomeToolStripMenuItem,
            this.toolStripSeparator2,
            this.FrmLoginToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4);
            this.fileToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.fileToolStripMenuItem.RightToLeftAutoMirrorImage = true;
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(68, 34);
            this.fileToolStripMenuItem.Text = "فایل";
            this.fileToolStripMenuItem.ToolTipText = "از طریق این گزینه ها بین قسمت های مختلف برنامه جابجا شوید";
            // 
            // FrmHomeToolStripMenuItem
            // 
            this.FrmHomeToolStripMenuItem.Image = global::StoreManagement.Properties.Resources.home;
            this.FrmHomeToolStripMenuItem.Name = "FrmHomeToolStripMenuItem";
            this.FrmHomeToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
            this.FrmHomeToolStripMenuItem.Text = "صفحه اصلی";
            this.FrmHomeToolStripMenuItem.Click += new System.EventHandler(this.HomePageToolStripMenuItemClick);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(132, 6);
            // 
            // FrmLoginToolStripMenuItem
            // 
            this.FrmLoginToolStripMenuItem.Name = "FrmLoginToolStripMenuItem";
            this.FrmLoginToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
            this.FrmLoginToolStripMenuItem.Text = "تغییر کاربر";
            this.FrmLoginToolStripMenuItem.Click += new System.EventHandler(this.FormloginToolStripMenuItemClick);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(132, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Image = global::StoreManagement.Properties.Resources.exit;
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(135, 26);
            this.exitToolStripMenuItem.Text = "خروج";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.ExitToolStripMenuItemClick);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.FrmAppSettingsToolStripMenuItem,
            this.frmUserToolStripMenuItem});
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Padding = new System.Windows.Forms.Padding(4);
            this.toolStripMenuItem3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.toolStripMenuItem3.Size = new System.Drawing.Size(68, 34);
            this.toolStripMenuItem3.Text = "ویرایش";
            this.toolStripMenuItem3.ToolTipText = "از طریق این گزینه ها بین قسمت های مختلف برنامه جابجا شوید";
            // 
            // FrmAppSettingsToolStripMenuItem
            // 
            this.FrmAppSettingsToolStripMenuItem.Name = "FrmAppSettingsToolStripMenuItem";
            this.FrmAppSettingsToolStripMenuItem.Size = new System.Drawing.Size(157, 26);
            this.FrmAppSettingsToolStripMenuItem.Text = "تنظیمات نرم افزار";
            this.FrmAppSettingsToolStripMenuItem.Click += new System.EventHandler(this.SettingsToolStripMenuItemClick);
            // 
            // frmUserToolStripMenuItem
            // 
            this.frmUserToolStripMenuItem.Name = "frmUserToolStripMenuItem";
            this.frmUserToolStripMenuItem.Size = new System.Drawing.Size(157, 26);
            this.frmUserToolStripMenuItem.Text = "کاربران";
            this.frmUserToolStripMenuItem.Click += new System.EventHandler(this.FrmUserToolStripMenuItemClick);
            // 
            // formsToolStripMenuItem
            // 
            this.formsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.frmUnitToolStripMenuItem,
            this.frmCategoryToolStripMenuItem,
            this.frmProductToolStripMenuItem,
            this.frmCustomerToolStripMenuItem,
            this.frmSupplierToolStripMenuItem,
            this.toolStripSeparator6,
            this.toolStripSeparator8,
            this.frmSaleAddToolStripMenuItem,
            this.frmSaleToolStripMenuItem,
            this.toolStripSeparator7,
            this.frmPurchaseAddToolStripMenuItem,
            this.frmPurchaseToolStripMenuItem});
            this.formsToolStripMenuItem.Name = "formsToolStripMenuItem";
            this.formsToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4);
            this.formsToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.formsToolStripMenuItem.Size = new System.Drawing.Size(68, 34);
            this.formsToolStripMenuItem.Text = "فرم ها";
            this.formsToolStripMenuItem.ToolTipText = "از طریق این گزینه ها بین قسمت های مختلف برنامه جابجا شوید";
            // 
            // frmUnitToolStripMenuItem
            // 
            this.frmUnitToolStripMenuItem.Name = "frmUnitToolStripMenuItem";
            this.frmUnitToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.frmUnitToolStripMenuItem.Text = "واحدهای شمارش کالا";
            this.frmUnitToolStripMenuItem.Click += new System.EventHandler(this.FrmUnitToolStripMenuItemClick);
            // 
            // frmCategoryToolStripMenuItem
            // 
            this.frmCategoryToolStripMenuItem.Name = "frmCategoryToolStripMenuItem";
            this.frmCategoryToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.frmCategoryToolStripMenuItem.Text = "دسته بندی های کالا";
            this.frmCategoryToolStripMenuItem.Click += new System.EventHandler(this.FrmCategoryToolStripMenuItemClick);
            // 
            // frmProductToolStripMenuItem
            // 
            this.frmProductToolStripMenuItem.Name = "frmProductToolStripMenuItem";
            this.frmProductToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.frmProductToolStripMenuItem.Text = "کالاها";
            this.frmProductToolStripMenuItem.Click += new System.EventHandler(this.FrmProductToolStripMenuItemClick);
            // 
            // frmCustomerToolStripMenuItem
            // 
            this.frmCustomerToolStripMenuItem.Name = "frmCustomerToolStripMenuItem";
            this.frmCustomerToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.frmCustomerToolStripMenuItem.Text = "مشتریان";
            this.frmCustomerToolStripMenuItem.Click += new System.EventHandler(this.FrmCustomerToolStripMenuItemClick);
            // 
            // frmSupplierToolStripMenuItem
            // 
            this.frmSupplierToolStripMenuItem.Name = "frmSupplierToolStripMenuItem";
            this.frmSupplierToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.frmSupplierToolStripMenuItem.Text = "توزیع کنندگان کالا";
            this.frmSupplierToolStripMenuItem.Click += new System.EventHandler(this.FrmSupplierToolStripMenuItemClick);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(191, 6);
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(191, 6);
            // 
            // frmSaleAddToolStripMenuItem
            // 
            this.frmSaleAddToolStripMenuItem.Name = "frmSaleAddToolStripMenuItem";
            this.frmSaleAddToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.frmSaleAddToolStripMenuItem.Text = "فروش کالا (صدور فاکتور)";
            this.frmSaleAddToolStripMenuItem.Click += new System.EventHandler(this.FrmSaleAddToolStripMenuItemClick);
            // 
            // frmSaleToolStripMenuItem
            // 
            this.frmSaleToolStripMenuItem.Name = "frmSaleToolStripMenuItem";
            this.frmSaleToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.frmSaleToolStripMenuItem.Text = "فروش ها";
            this.frmSaleToolStripMenuItem.Click += new System.EventHandler(this.FrmSaleToolStripMenuItemClick);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(191, 6);
            // 
            // frmPurchaseAddToolStripMenuItem
            // 
            this.frmPurchaseAddToolStripMenuItem.Name = "frmPurchaseAddToolStripMenuItem";
            this.frmPurchaseAddToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.frmPurchaseAddToolStripMenuItem.Text = "خرید کالا";
            this.frmPurchaseAddToolStripMenuItem.Click += new System.EventHandler(this.FrmPurchaseAddToolStripMenuItemClick);
            // 
            // frmPurchaseToolStripMenuItem
            // 
            this.frmPurchaseToolStripMenuItem.Name = "frmPurchaseToolStripMenuItem";
            this.frmPurchaseToolStripMenuItem.Size = new System.Drawing.Size(194, 26);
            this.frmPurchaseToolStripMenuItem.Text = "خریدها";
            this.frmPurchaseToolStripMenuItem.Click += new System.EventHandler(this.FrmPurchaseToolStripMenuItemClick);
            // 
            // toolsToolStripMenuItem
            // 
            this.toolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.notePadToolStripMenuItem,
            this.calculatorToolStripMenuItem,
            this.toolStripSeparator3,
            this.pCDetailToolStripMenuItem,
            this.serverDetailToolStripMenuItem,
            this.internetCheckerToolStripMenuItem,
            this.toolStripSeparator4,
            this.fileWiperToolStripMenuItem,
            this.systemToolsToolStripMenuItem,
            this.fontsListToolStripMenuItem,
            this.sysUpTimeToolStripMenuItem});
            this.toolsToolStripMenuItem.Name = "toolsToolStripMenuItem";
            this.toolsToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4);
            this.toolsToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.toolsToolStripMenuItem.Size = new System.Drawing.Size(68, 34);
            this.toolsToolStripMenuItem.Text = "امکانات";
            this.toolsToolStripMenuItem.ToolTipText = "از طریق این گزینه ها بین قسمت های مختلف برنامه جابجا شوید";
            // 
            // notePadToolStripMenuItem
            // 
            this.notePadToolStripMenuItem.Image = global::StoreManagement.Properties.Resources.notepad;
            this.notePadToolStripMenuItem.Name = "notePadToolStripMenuItem";
            this.notePadToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.notePadToolStripMenuItem.Text = "دفترچه یادداشت";
            this.notePadToolStripMenuItem.Click += new System.EventHandler(this.NotePadToolStripMenuItemClick);
            // 
            // calculatorToolStripMenuItem
            // 
            this.calculatorToolStripMenuItem.Image = global::StoreManagement.Properties.Resources.Calculator;
            this.calculatorToolStripMenuItem.Name = "calculatorToolStripMenuItem";
            this.calculatorToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.calculatorToolStripMenuItem.Text = "ماشین حساب";
            this.calculatorToolStripMenuItem.Click += new System.EventHandler(this.CalculatorToolStripMenuItemClick);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(210, 6);
            // 
            // pCDetailToolStripMenuItem
            // 
            this.pCDetailToolStripMenuItem.Name = "pCDetailToolStripMenuItem";
            this.pCDetailToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.pCDetailToolStripMenuItem.Text = "مشخصات ویندوز رایانه";
            this.pCDetailToolStripMenuItem.Click += new System.EventHandler(this.PcDetailToolStripMenuItemClick);
            // 
            // serverDetailToolStripMenuItem
            // 
            this.serverDetailToolStripMenuItem.Name = "serverDetailToolStripMenuItem";
            this.serverDetailToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.serverDetailToolStripMenuItem.Text = "مشخصات رایانه در شبکه";
            this.serverDetailToolStripMenuItem.Click += new System.EventHandler(this.ServerDetailToolStripMenuItemClick);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(210, 6);
            // 
            // fileWiperToolStripMenuItem
            // 
            this.fileWiperToolStripMenuItem.Name = "fileWiperToolStripMenuItem";
            this.fileWiperToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.fileWiperToolStripMenuItem.Text = "حذف دائمی فایل";
            this.fileWiperToolStripMenuItem.Click += new System.EventHandler(this.FileWiperToolStripMenuItemClick);
            // 
            // systemToolsToolStripMenuItem
            // 
            this.systemToolsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hibernateToolStripMenuItem,
            this.shutDownToolStripMenuItem,
            this.logOffToolStripMenuItem,
            this.rebootToolStripMenuItem,
            this.standbyToolStripMenuItem});
            this.systemToolsToolStripMenuItem.Name = "systemToolsToolStripMenuItem";
            this.systemToolsToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.systemToolsToolStripMenuItem.Text = "امکانات سیستمی";
            // 
            // hibernateToolStripMenuItem
            // 
            this.hibernateToolStripMenuItem.Name = "hibernateToolStripMenuItem";
            this.hibernateToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.hibernateToolStripMenuItem.Text = "خواب زمستانی";
            this.hibernateToolStripMenuItem.Click += new System.EventHandler(this.HibernateToolStripMenuItemClick);
            // 
            // shutDownToolStripMenuItem
            // 
            this.shutDownToolStripMenuItem.Name = "shutDownToolStripMenuItem";
            this.shutDownToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.shutDownToolStripMenuItem.Text = "خاموش کردن رایانه";
            this.shutDownToolStripMenuItem.Click += new System.EventHandler(this.ShutDownToolStripMenuItemClick);
            // 
            // logOffToolStripMenuItem
            // 
            this.logOffToolStripMenuItem.Name = "logOffToolStripMenuItem";
            this.logOffToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.logOffToolStripMenuItem.Text = "خروج از اکانت ویندوز";
            this.logOffToolStripMenuItem.Click += new System.EventHandler(this.LogOffToolStripMenuItemClick);
            // 
            // rebootToolStripMenuItem
            // 
            this.rebootToolStripMenuItem.Name = "rebootToolStripMenuItem";
            this.rebootToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.rebootToolStripMenuItem.Text = "راه اندازی مجدد رایانه";
            this.rebootToolStripMenuItem.Click += new System.EventHandler(this.RebootToolStripMenuItemClick);
            // 
            // standbyToolStripMenuItem
            // 
            this.standbyToolStripMenuItem.Name = "standbyToolStripMenuItem";
            this.standbyToolStripMenuItem.Size = new System.Drawing.Size(175, 26);
            this.standbyToolStripMenuItem.Text = "حالت آماده باش";
            this.standbyToolStripMenuItem.Click += new System.EventHandler(this.StandbyToolStripMenuItemClick);
            // 
            // fontsListToolStripMenuItem
            // 
            this.fontsListToolStripMenuItem.Name = "fontsListToolStripMenuItem";
            this.fontsListToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.fontsListToolStripMenuItem.Text = "لیست فونت های نصب شده";
            this.fontsListToolStripMenuItem.Click += new System.EventHandler(this.FontsListToolStripMenuItemClick);
            // 
            // internetCheckerToolStripMenuItem
            // 
            this.internetCheckerToolStripMenuItem.Name = "internetCheckerToolStripMenuItem";
            this.internetCheckerToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.internetCheckerToolStripMenuItem.Text = "بررسی دسترسی به اینترنت";
            this.internetCheckerToolStripMenuItem.Click += new System.EventHandler(this.InternetCheckerToolStripMenuItemClick);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem,
            this.creatorwebsiteToolStripMenuItem,
            this.toolStripSeparator5,
            this.aboutusToolStripMenuItem});
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Padding = new System.Windows.Forms.Padding(4);
            this.aboutToolStripMenuItem.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(68, 34);
            this.aboutToolStripMenuItem.Text = "درباره";
            this.aboutToolStripMenuItem.ToolTipText = "از طریق این گزینه ها بین قسمت های مختلف برنامه جابجا شوید";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(150, 26);
            this.helpToolStripMenuItem.Text = "راهنمای استفاده";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.HelpToolStripMenuItemClick);
            // 
            // creatorwebsiteToolStripMenuItem
            // 
            this.creatorwebsiteToolStripMenuItem.Name = "creatorwebsiteToolStripMenuItem";
            this.creatorwebsiteToolStripMenuItem.Size = new System.Drawing.Size(150, 26);
            this.creatorwebsiteToolStripMenuItem.Text = "سایت سازنده";
            this.creatorwebsiteToolStripMenuItem.Click += new System.EventHandler(this.CreatorwebsiteToolStripMenuItemClick);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(147, 6);
            // 
            // aboutusToolStripMenuItem
            // 
            this.aboutusToolStripMenuItem.Name = "aboutusToolStripMenuItem";
            this.aboutusToolStripMenuItem.Size = new System.Drawing.Size(150, 26);
            this.aboutusToolStripMenuItem.Text = "درباره ما";
            this.aboutusToolStripMenuItem.Click += new System.EventHandler(this.AboutusToolStripMenuItemClick);
            // 
            // sysUpTimeToolStripMenuItem
            // 
            this.sysUpTimeToolStripMenuItem.Name = "sysUpTimeToolStripMenuItem";
            this.sysUpTimeToolStripMenuItem.Size = new System.Drawing.Size(213, 26);
            this.sysUpTimeToolStripMenuItem.Text = "مدت زمان روشن بودن سیستم";
            this.sysUpTimeToolStripMenuItem.Click += new System.EventHandler(this.SysUpTimeToolStripMenuItemClick);
            // 
            // JSMenuStripStoreManagement
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.JSMenuStrip);
            this.MaximumSize = new System.Drawing.Size(80, 0);
            this.MinimumSize = new System.Drawing.Size(75, 250);
            this.Name = "JSMenuStripStoreManagement";
            this.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.Size = new System.Drawing.Size(75, 250);
            this.Load += new System.EventHandler(this.JSMenuStripStoreManagementLoad);
            this.JSMenuStrip.ResumeLayout(false);
            this.JSMenuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calculatorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutusToolStripMenuItem;
        protected System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        protected System.Windows.Forms.ToolStripMenuItem formsToolStripMenuItem;
        protected System.Windows.Forms.ToolStripMenuItem toolsToolStripMenuItem;
        protected System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        protected System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.MenuStrip JSMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem notePadToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem FrmLoginToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem FrmHomeToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem systemToolsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hibernateToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shutDownToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logOffToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem rebootToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem standbyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fileWiperToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem serverDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem pCDetailToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem FrmAppSettingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem creatorwebsiteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmCategoryToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem frmUnitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmCustomerToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem frmProductToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmSaleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmSupplierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmSaleAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripMenuItem frmPurchaseToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmPurchaseAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem frmUserToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontsListToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem internetCheckerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sysUpTimeToolStripMenuItem;
    }
}
