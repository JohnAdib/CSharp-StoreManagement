﻿using System;
using System.IO;
using System.Linq;
using System.Media;
using System.Net;
using System.Drawing.Text;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace StoreManagement.Requirement
{
    public partial class JSMenuStripStoreManagement : UserControl
    {
        public new Form ParentForm { get; set; }
        public JSMenuStripStoreManagement()
        {
            InitializeComponent();
        }

        private void JSMenuStripStoreManagementLoad(object sender, EventArgs e)
        {
            if (ParentForm == null) return;
            foreach (ToolStripMenuItem x in JSMenuStrip.Items)
                for (int i = 0; i < x.DropDownItems.Count; i++)
                    if (ParentForm.Name.ToLower() + "toolstripmenuitem" == x.DropDownItems[i].Name.ToLower())
                        x.DropDownItems[i].Enabled = false;
        }


        private void CalculatorToolStripMenuItemClick(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("calc.exe");
        }
        private void NotePadToolStripMenuItemClick(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("notepad.exe");
        }
        private void CreatorwebsiteToolStripMenuItemClick(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.evazzadeh.com");
        }

        private void HibernateToolStripMenuItemClick(object sender, EventArgs e)
        {
            // Hibernate
            Application.SetSuspendState(PowerState.Hibernate, true, true);
        }

        private void ShutDownToolStripMenuItemClick(object sender, EventArgs e)
        {
            // Shutdown
            System.Diagnostics.Process.Start("ShutDown", "/s");
        }

        private void LogOffToolStripMenuItemClick(object sender, EventArgs e)
        {
            // Log Off
            System.Diagnostics.Process.Start("ShutDown", "/l");
        }

        private void RebootToolStripMenuItemClick(object sender, EventArgs e)
        {
            // Reboot
            System.Diagnostics.Process.Start("ShutDown", "/r");
        }

        private void StandbyToolStripMenuItemClick(object sender, EventArgs e)
        {
            // Standby
            Application.SetSuspendState(PowerState.Suspend, true, true);
        }

        private void FileWiperToolStripMenuItemClick(object sender, EventArgs e)
        {
            var z = new OpenFileDialog {Title = @"فایل مورد نظر را برای حذف بدون بازگشت انتخاب کنید"};
            z.ShowDialog();
            string filename = z.FileName;

            if (File.Exists(filename))
            {
                File.SetAttributes(filename, FileAttributes.Normal);
                var rnd = new Random((int) DateTime.Now.Ticks);
                FileStream file = File.Open(filename, FileMode.Open, FileAccess.Write);
                var fileLength = (int) file.Length;
                int offset = 0;

                const int bufferSize = 100;
                var buffers = new byte[4][];
                buffers[0] = new byte[bufferSize];
                buffers[1] = new byte[bufferSize];
                buffers[2] = new byte[bufferSize];
                buffers[3] = new byte[bufferSize];

                rnd.NextBytes(buffers[0]);
                rnd.NextBytes(buffers[2]);
                for (int i = 0; i < bufferSize; i++)
                {
                    buffers[1][i] = 0;
                    buffers[3][i] = 0xff;
                }

                while (offset < (fileLength - bufferSize))
                {
                    foreach (var t in buffers)
                    {
                        file.Seek(offset, SeekOrigin.Begin);
                        file.Write(buffers[0], 0, bufferSize);
                        file.Flush();
                        if (t == null)
                        {
                        }
                    }
                    offset += 100;
                }

                foreach (var t in buffers)
                {
                    file.Seek(offset, SeekOrigin.Begin);
                    file.Write(buffers[0], 0, fileLength - offset);
                    file.Flush();
                    if (t == null)
                    {
                    }
                }

                file.Close();

                file = File.Open(filename, FileMode.Truncate, FileAccess.Write);
                file.Flush();
                file.Close();

                File.Delete(filename);
                MessageBox.Show(@"فایل مورد نظر با موفقیت پاک شد و دیگر قابل بازیابی نیست!", @"حذف موفقیت آمیز");

            }
        }

        private void ServerDetailToolStripMenuItemClick(object sender, EventArgs e)
        {
            MessageBox.Show(@"Computer Name: " + Dns.GetHostName() + Environment.NewLine
                + @"IP Adress: " + Dns.GetHostEntry(Dns.GetHostName()).AddressList[0]);
        }

        private void PcDetailToolStripMenuItemClick(object sender, EventArgs e)
        {
            OperatingSystem osDetail = Environment.OSVersion;
            Version ver = osDetail.Version;
            string osDetailmsg = @"OS Version: " + osDetail.Version + Environment.NewLine
                                 + @"OS Platoform: " + osDetail.Platform.ToString() + Environment.NewLine
                                 + @"OS SP: " + osDetail.ServicePack + Environment.NewLine 
                                 + @"OS Version String: " + osDetail.VersionString + Environment.NewLine
                                 + Environment.NewLine + @"Major version: " + ver.Major + Environment.NewLine
                                 + @"Major Revision: " + ver.MajorRevision + Environment.NewLine
                                 + @"Minor version: " + ver.Minor + Environment.NewLine
                                 + @"Minor Revision: " + ver.MinorRevision + Environment.NewLine
                                 + @"Build: " + ver.Build + Environment.NewLine
                                 + Environment.NewLine
                                 + @"Machine Name: " + Environment.MachineName + Environment.NewLine
                                 + @"User Name: " + Environment.UserName + Environment.NewLine
                                 + @"User Domain Name: " + Environment.UserDomainName + Environment.NewLine
                                 + @"System Directory: " + Environment.SystemDirectory+ Environment.NewLine
                                 + @"Processor Count: " + Environment.ProcessorCount + Environment.NewLine
                                 + @"64 bit Processor: " + Environment.Is64BitProcess + Environment.NewLine
                                 
                                 + @"Host Name: " + Environment.Is64BitProcess;
            MessageBox.Show(osDetailmsg, @"مشخصات ویندوز رایانه");
        }


        private void AboutusToolStripMenuItemClick(object sender, EventArgs e)
        {
            new JSAboutBox().ShowDialog();
        }

        private void ExitToolStripMenuItemClick(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void FormloginToolStripMenuItemClick(object sender, EventArgs e)
        {
            /*
            if (ParentForm != null)
            {
                if (ParentForm.Name != "FrmHome")
                    ParentForm.Close();
                ParentForm.Hide();
            }


            new Forms.Security.FrmLogin().ShowDialog();
             */
            Application.Restart();
        }

        private void HomePageToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (ParentForm != null && ParentForm.Name != "FrmHome")
                ParentForm.Close();
            //new Forms.FrmHome(Properties.Settings.Default.AppLoginedUser).ShowDialog();
        }
        private void SettingsToolStripMenuItemClick(object sender, EventArgs e)
        {
            new Forms.Settings.FrmAppSettings().ShowDialog(this);
        }

        private void HelpToolStripMenuItemClick(object sender, EventArgs e)
        {
            MessageBox.Show(@"به زودی تکمیل خواهد شد");
        }

        private void FrmCategoryToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (ParentForm != null && ParentForm.Name != "FrmHome")
                ParentForm.Close();
            new Forms.frm_ProductCategory.FrmCategory().ShowDialog(this);
        }

        private void FrmUnitToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (ParentForm != null && ParentForm.Name != "FrmHome")
                ParentForm.Close();
            new Forms.frm_ProductUnit.FrmUnit().ShowDialog(this);
        }

        private void FrmCustomerToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (ParentForm != null && ParentForm.Name != "FrmHome")
                ParentForm.Close();
            new Forms.frm_Customer.FrmCustomer().ShowDialog(this);
        }

        private void FrmProductToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (ParentForm != null && ParentForm.Name != "FrmHome")
                ParentForm.Close();
            new Forms.frm_Product.FrmProduct().ShowDialog(this);
        }

        private void FrmSaleToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (ParentForm != null && ParentForm.Name != "FrmHome")
                ParentForm.Close();
            new Forms.frm_Sale.FrmSale().ShowDialog(this);
        }

        private void FrmSupplierToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (ParentForm != null && ParentForm.Name != "FrmHome")
                ParentForm.Close();
            new Forms.frm_Supplier.FrmSupplier().ShowDialog(this);
        }

        private void FrmSaleAddToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (ParentForm != null && ParentForm.Name != "FrmHome")
                ParentForm.Close();
            new Forms.frm_Sale.FrmSaleAdd().ShowDialog(this);
        }

        private void FrmPurchaseAddToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (ParentForm != null && ParentForm.Name != "FrmHome")
                ParentForm.Close();
            new Forms.frm_Purchase.FrmPurchaseAdd().ShowDialog(this);
        }

        private void FrmPurchaseToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (ParentForm != null && ParentForm.Name != "FrmHome")
                ParentForm.Close();
            new Forms.frm_Purchase.FrmPurchase().ShowDialog(this);
        }

        private void FrmUserToolStripMenuItemClick(object sender, EventArgs e)
        {
            if (ParentForm != null && ParentForm.Name != "FrmHome")
                ParentForm.Close();
            new Forms.frm_User.FrmUser().ShowDialog(this);
        }

        private void FontsListToolStripMenuItemClick(object sender, EventArgs e)
        {
            SystemSounds.Exclamation.Play();
            var fonts = new InstalledFontCollection();
            var jsFontsList = new string[] {};
            jsFontsList = fonts.Families.Aggregate(jsFontsList, (current, font) => 
                new[] {current + font.Name + Environment.NewLine});
            MessageBox.Show(string.Join("\n", jsFontsList));
        }

        
        [DllImport("wininet.dll")]
        private extern static bool InternetGetConnectedState(out int description, int reservedValue);
        //Creating a function that uses the API function...
        bool IsConnectedToInternet()
        {
            int desc;
            var a = InternetGetConnectedState(out desc, 0);
            return a;
        }


        private void InternetCheckerToolStripMenuItemClick(object sender, EventArgs e)
        {
            MessageBox.Show(IsConnectedToInternet()
                                ? @"این رایانه متصل به اینترنت است"
                                : @"این رایانه به اینترنت دسترسی ندارد");
        }

        private void SysUpTimeToolStripMenuItemClick(object sender, EventArgs e)
        {
            String strResult = String.Empty;
            strResult += Convert.ToString(Environment.TickCount / 86400000) + " days, ";
            strResult += Convert.ToString(Environment.TickCount / 3600000 % 24) + " hours, ";
            strResult += Convert.ToString(Environment.TickCount / 120000 % 60) + " minutes, ";
            strResult += Convert.ToString(Environment.TickCount / 1000 % 60) + " seconds.";
            MessageBox.Show(strResult, @"مدت زمان روشن بودن سیستم");
        }
    }
}
