﻿namespace StoreManagement.Forms.frm_User
{
    partial class FrmUserEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmUserEdit));
            this.jsLabel11 = new JSRequirement.Controls.JSLabel();
            this.txtDesc = new JSRequirement.Controls.JSTextBox();
            this.txtBirthDate = new System.Windows.Forms.DateTimePicker();
            this.jsGroupBox1 = new JSRequirement.Controls.JSGroupBox();
            this.txtpasscodeconfirm = new JSRequirement.Controls.JSTextBox();
            this.txtUserCode = new JSRequirement.Controls.JSTextBox();
            this.txtpasscode = new JSRequirement.Controls.JSTextBox();
            this.txtNicName = new JSRequirement.Controls.JSTextBox();
            this.jsLabel4 = new JSRequirement.Controls.JSLabel();
            this.jsLabel1 = new JSRequirement.Controls.JSLabel();
            this.lblPassCodeConfirm = new JSRequirement.Controls.JSLabel();
            this.jsLabel2 = new JSRequirement.Controls.JSLabel();
            this.jsGroupBox3 = new JSRequirement.Controls.JSGroupBox();
            this.jsLabel10 = new JSRequirement.Controls.JSLabel();
            this.txtEmail = new JSRequirement.Controls.JSTextBox();
            this.jsLabel9 = new JSRequirement.Controls.JSLabel();
            this.jsLabel8 = new JSRequirement.Controls.JSLabel();
            this.txtFName = new JSRequirement.Controls.JSTextBox();
            this.txtLName = new JSRequirement.Controls.JSTextBox();
            this.jsLabel6 = new JSRequirement.Controls.JSLabel();
            this.btnUpdate = new JSRequirement.Controls.JS7Btn();
            this.jsLabel7 = new JSRequirement.Controls.JSLabel();
            this.jsGroupBox2 = new JSRequirement.Controls.JSGroupBox();
            this.cmbQuestion = new JSRequirement.Controls.JSComboBox();
            this.jsLabel5 = new JSRequirement.Controls.JSLabel();
            this.txtAnswer = new JSRequirement.Controls.JSTextBox();
            this.btnClose = new JSRequirement.Controls.JS7Btn();
            this.jsGroupBox1.SuspendLayout();
            this.jsGroupBox3.SuspendLayout();
            this.jsGroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsLabel11
            // 
            this.jsLabel11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel11.AutoSize = true;
            this.jsLabel11.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel11.Location = new System.Drawing.Point(423, 68);
            this.jsLabel11.Name = "jsLabel11";
            this.jsLabel11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel11.Size = new System.Drawing.Size(51, 22);
            this.jsLabel11.TabIndex = 19;
            this.jsLabel11.Text = "تاریخ تولد";
            this.jsLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtDesc
            // 
            this.txtDesc.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtDesc.Location = new System.Drawing.Point(32, 100);
            this.txtDesc.MaxLength = 200;
            this.txtDesc.Multiline = true;
            this.txtDesc.Name = "txtDesc";
            this.txtDesc.Num16 = ((short)(0));
            this.txtDesc.Num32 = 0;
            this.txtDesc.Num64 = ((long)(0));
            this.txtDesc.NumByte = ((byte)(0));
            this.txtDesc.NumDouble = 0D;
            this.txtDesc.NumFloat = 0F;
            this.txtDesc.PersianText = true;
            this.txtDesc.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtDesc.Size = new System.Drawing.Size(385, 55);
            this.txtDesc.TabIndex = 16;
            // 
            // txtBirthDate
            // 
            this.txtBirthDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtBirthDate.Location = new System.Drawing.Point(266, 65);
            this.txtBirthDate.Name = "txtBirthDate";
            this.txtBirthDate.Size = new System.Drawing.Size(151, 30);
            this.txtBirthDate.TabIndex = 18;
            // 
            // jsGroupBox1
            // 
            this.jsGroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox1.Controls.Add(this.txtpasscodeconfirm);
            this.jsGroupBox1.Controls.Add(this.txtUserCode);
            this.jsGroupBox1.Controls.Add(this.txtpasscode);
            this.jsGroupBox1.Controls.Add(this.txtNicName);
            this.jsGroupBox1.Controls.Add(this.jsLabel4);
            this.jsGroupBox1.Controls.Add(this.jsLabel1);
            this.jsGroupBox1.Controls.Add(this.lblPassCodeConfirm);
            this.jsGroupBox1.Controls.Add(this.jsLabel2);
            this.jsGroupBox1.Location = new System.Drawing.Point(16, 12);
            this.jsGroupBox1.Name = "jsGroupBox1";
            this.jsGroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox1.Size = new System.Drawing.Size(516, 108);
            this.jsGroupBox1.TabIndex = 16;
            this.jsGroupBox1.TabStop = false;
            this.jsGroupBox1.Text = "مشخصات اصلی";
            // 
            // txtpasscodeconfirm
            // 
            this.txtpasscodeconfirm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtpasscodeconfirm.Location = new System.Drawing.Point(32, 57);
            this.txtpasscodeconfirm.MaxLength = 200;
            this.txtpasscodeconfirm.Name = "txtpasscodeconfirm";
            this.txtpasscodeconfirm.Num16 = ((short)(0));
            this.txtpasscodeconfirm.Num32 = 0;
            this.txtpasscodeconfirm.Num64 = ((long)(0));
            this.txtpasscodeconfirm.NumByte = ((byte)(0));
            this.txtpasscodeconfirm.NumDouble = 0D;
            this.txtpasscodeconfirm.NumFloat = 0F;
            this.txtpasscodeconfirm.PersianText = true;
            this.txtpasscodeconfirm.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtpasscodeconfirm.Size = new System.Drawing.Size(151, 30);
            this.txtpasscodeconfirm.TabIndex = 2;
            this.txtpasscodeconfirm.Visible = false;
            // 
            // txtUserCode
            // 
            this.txtUserCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtUserCode.Location = new System.Drawing.Point(266, 21);
            this.txtUserCode.MaxLength = 200;
            this.txtUserCode.Name = "txtUserCode";
            this.txtUserCode.Num16 = ((short)(0));
            this.txtUserCode.Num32 = 0;
            this.txtUserCode.Num64 = ((long)(0));
            this.txtUserCode.NumByte = ((byte)(0));
            this.txtUserCode.NumDouble = 0D;
            this.txtUserCode.NumFloat = 0F;
            this.txtUserCode.PersianText = true;
            this.txtUserCode.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtUserCode.Size = new System.Drawing.Size(151, 30);
            this.txtUserCode.TabIndex = 0;
            // 
            // txtpasscode
            // 
            this.txtpasscode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtpasscode.Location = new System.Drawing.Point(266, 57);
            this.txtpasscode.MaxLength = 200;
            this.txtpasscode.Name = "txtpasscode";
            this.txtpasscode.Num16 = ((short)(0));
            this.txtpasscode.Num32 = 0;
            this.txtpasscode.Num64 = ((long)(0));
            this.txtpasscode.NumByte = ((byte)(0));
            this.txtpasscode.NumDouble = 0D;
            this.txtpasscode.NumFloat = 0F;
            this.txtpasscode.PersianText = true;
            this.txtpasscode.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtpasscode.Size = new System.Drawing.Size(151, 30);
            this.txtpasscode.TabIndex = 1;
            this.txtpasscode.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TxtpasscodeKeyDown);
            // 
            // txtNicName
            // 
            this.txtNicName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtNicName.Location = new System.Drawing.Point(32, 21);
            this.txtNicName.MaxLength = 200;
            this.txtNicName.Name = "txtNicName";
            this.txtNicName.Num16 = ((short)(0));
            this.txtNicName.Num32 = 0;
            this.txtNicName.Num64 = ((long)(0));
            this.txtNicName.NumByte = ((byte)(0));
            this.txtNicName.NumDouble = 0D;
            this.txtNicName.NumFloat = 0F;
            this.txtNicName.PersianText = true;
            this.txtNicName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtNicName.Size = new System.Drawing.Size(151, 30);
            this.txtNicName.TabIndex = 3;
            // 
            // jsLabel4
            // 
            this.jsLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel4.AutoSize = true;
            this.jsLabel4.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel4.ForeColor = System.Drawing.Color.Red;
            this.jsLabel4.Location = new System.Drawing.Point(188, 24);
            this.jsLabel4.Name = "jsLabel4";
            this.jsLabel4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel4.Size = new System.Drawing.Size(28, 22);
            this.jsLabel4.TabIndex = 7;
            this.jsLabel4.Text = "لقب";
            this.jsLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel1
            // 
            this.jsLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel1.AutoSize = true;
            this.jsLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel1.ForeColor = System.Drawing.Color.Red;
            this.jsLabel1.Location = new System.Drawing.Point(423, 24);
            this.jsLabel1.Name = "jsLabel1";
            this.jsLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel1.Size = new System.Drawing.Size(57, 22);
            this.jsLabel1.TabIndex = 4;
            this.jsLabel1.Text = "نام کاربری";
            this.jsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblPassCodeConfirm
            // 
            this.lblPassCodeConfirm.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.lblPassCodeConfirm.AutoSize = true;
            this.lblPassCodeConfirm.BackColor = System.Drawing.Color.Transparent;
            this.lblPassCodeConfirm.ForeColor = System.Drawing.Color.Red;
            this.lblPassCodeConfirm.Location = new System.Drawing.Point(188, 60);
            this.lblPassCodeConfirm.Name = "lblPassCodeConfirm";
            this.lblPassCodeConfirm.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblPassCodeConfirm.Size = new System.Drawing.Size(67, 22);
            this.lblPassCodeConfirm.TabIndex = 6;
            this.lblPassCodeConfirm.Text = "تکرار گذرواژه";
            this.lblPassCodeConfirm.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPassCodeConfirm.Visible = false;
            // 
            // jsLabel2
            // 
            this.jsLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel2.AutoSize = true;
            this.jsLabel2.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel2.ForeColor = System.Drawing.Color.Red;
            this.jsLabel2.Location = new System.Drawing.Point(423, 60);
            this.jsLabel2.Name = "jsLabel2";
            this.jsLabel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel2.Size = new System.Drawing.Size(42, 22);
            this.jsLabel2.TabIndex = 5;
            this.jsLabel2.Text = "گذرواژه";
            this.jsLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsGroupBox3
            // 
            this.jsGroupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGroupBox3.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox3.Controls.Add(this.jsLabel11);
            this.jsGroupBox3.Controls.Add(this.txtBirthDate);
            this.jsGroupBox3.Controls.Add(this.txtDesc);
            this.jsGroupBox3.Controls.Add(this.jsLabel10);
            this.jsGroupBox3.Controls.Add(this.txtEmail);
            this.jsGroupBox3.Controls.Add(this.jsLabel9);
            this.jsGroupBox3.Controls.Add(this.jsLabel8);
            this.jsGroupBox3.Controls.Add(this.txtFName);
            this.jsGroupBox3.Controls.Add(this.txtLName);
            this.jsGroupBox3.Controls.Add(this.jsLabel6);
            this.jsGroupBox3.Location = new System.Drawing.Point(16, 221);
            this.jsGroupBox3.Name = "jsGroupBox3";
            this.jsGroupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox3.Size = new System.Drawing.Size(516, 173);
            this.jsGroupBox3.TabIndex = 18;
            this.jsGroupBox3.TabStop = false;
            this.jsGroupBox3.Text = "اطلاعات فردی";
            // 
            // jsLabel10
            // 
            this.jsLabel10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel10.AutoSize = true;
            this.jsLabel10.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel10.Location = new System.Drawing.Point(423, 103);
            this.jsLabel10.Name = "jsLabel10";
            this.jsLabel10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel10.Size = new System.Drawing.Size(39, 22);
            this.jsLabel10.TabIndex = 17;
            this.jsLabel10.Text = "توضیح";
            this.jsLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtEmail
            // 
            this.txtEmail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtEmail.Location = new System.Drawing.Point(32, 65);
            this.txtEmail.MaxLength = 200;
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Num16 = ((short)(0));
            this.txtEmail.Num32 = 0;
            this.txtEmail.Num64 = ((long)(0));
            this.txtEmail.NumByte = ((byte)(0));
            this.txtEmail.NumDouble = 0D;
            this.txtEmail.NumFloat = 0F;
            this.txtEmail.PersianText = true;
            this.txtEmail.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtEmail.Size = new System.Drawing.Size(151, 30);
            this.txtEmail.TabIndex = 14;
            // 
            // jsLabel9
            // 
            this.jsLabel9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel9.AutoSize = true;
            this.jsLabel9.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel9.Location = new System.Drawing.Point(188, 68);
            this.jsLabel9.Name = "jsLabel9";
            this.jsLabel9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel9.Size = new System.Drawing.Size(39, 22);
            this.jsLabel9.TabIndex = 15;
            this.jsLabel9.Text = "رایانامه";
            this.jsLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel8
            // 
            this.jsLabel8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel8.AutoSize = true;
            this.jsLabel8.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel8.Location = new System.Drawing.Point(188, 32);
            this.jsLabel8.Name = "jsLabel8";
            this.jsLabel8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel8.Size = new System.Drawing.Size(65, 22);
            this.jsLabel8.TabIndex = 13;
            this.jsLabel8.Text = "نام خانوادگی";
            this.jsLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtFName
            // 
            this.txtFName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFName.Location = new System.Drawing.Point(266, 29);
            this.txtFName.MaxLength = 200;
            this.txtFName.Name = "txtFName";
            this.txtFName.Num16 = ((short)(0));
            this.txtFName.Num32 = 0;
            this.txtFName.Num64 = ((long)(0));
            this.txtFName.NumByte = ((byte)(0));
            this.txtFName.NumDouble = 0D;
            this.txtFName.NumFloat = 0F;
            this.txtFName.PersianText = true;
            this.txtFName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtFName.Size = new System.Drawing.Size(151, 30);
            this.txtFName.TabIndex = 9;
            // 
            // txtLName
            // 
            this.txtLName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLName.Location = new System.Drawing.Point(32, 29);
            this.txtLName.MaxLength = 200;
            this.txtLName.Name = "txtLName";
            this.txtLName.Num16 = ((short)(0));
            this.txtLName.Num32 = 0;
            this.txtLName.Num64 = ((long)(0));
            this.txtLName.NumByte = ((byte)(0));
            this.txtLName.NumDouble = 0D;
            this.txtLName.NumFloat = 0F;
            this.txtLName.PersianText = true;
            this.txtLName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtLName.Size = new System.Drawing.Size(151, 30);
            this.txtLName.TabIndex = 10;
            // 
            // jsLabel6
            // 
            this.jsLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel6.AutoSize = true;
            this.jsLabel6.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel6.Location = new System.Drawing.Point(421, 32);
            this.jsLabel6.Name = "jsLabel6";
            this.jsLabel6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel6.Size = new System.Drawing.Size(22, 22);
            this.jsLabel6.TabIndex = 12;
            this.jsLabel6.Text = "نام";
            this.jsLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnUpdate
            // 
            this.btnUpdate.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Update;
            this.btnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdate.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdate.ButtonText = "به روز رسانی";
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.btnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("btnUpdate.Image")));
            this.btnUpdate.Location = new System.Drawing.Point(182, 413);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(7);
            this.btnUpdate.MinimumSize = new System.Drawing.Size(120, 40);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnUpdate.Size = new System.Drawing.Size(120, 40);
            this.btnUpdate.TabIndex = 19;
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.BtnUpdateClick);
            // 
            // jsLabel7
            // 
            this.jsLabel7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel7.AutoSize = true;
            this.jsLabel7.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel7.Location = new System.Drawing.Point(423, 32);
            this.jsLabel7.Name = "jsLabel7";
            this.jsLabel7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel7.Size = new System.Drawing.Size(83, 22);
            this.jsLabel7.TabIndex = 15;
            this.jsLabel7.Text = "سوال امنیتی اول";
            this.jsLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsGroupBox2
            // 
            this.jsGroupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox2.Controls.Add(this.jsLabel7);
            this.jsGroupBox2.Controls.Add(this.cmbQuestion);
            this.jsGroupBox2.Controls.Add(this.jsLabel5);
            this.jsGroupBox2.Controls.Add(this.txtAnswer);
            this.jsGroupBox2.Location = new System.Drawing.Point(16, 126);
            this.jsGroupBox2.Name = "jsGroupBox2";
            this.jsGroupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox2.Size = new System.Drawing.Size(516, 89);
            this.jsGroupBox2.TabIndex = 17;
            this.jsGroupBox2.TabStop = false;
            this.jsGroupBox2.Text = "اطلاعات امنیتی";
            // 
            // cmbQuestion
            // 
            this.cmbQuestion.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbQuestion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbQuestion.FormattingEnabled = true;
            this.cmbQuestion.Location = new System.Drawing.Point(266, 29);
            this.cmbQuestion.Name = "cmbQuestion";
            this.cmbQuestion.PersianText = true;
            this.cmbQuestion.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.cmbQuestion.Size = new System.Drawing.Size(151, 30);
            this.cmbQuestion.TabIndex = 13;
            // 
            // jsLabel5
            // 
            this.jsLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel5.AutoSize = true;
            this.jsLabel5.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel5.Location = new System.Drawing.Point(188, 32);
            this.jsLabel5.Name = "jsLabel5";
            this.jsLabel5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel5.Size = new System.Drawing.Size(76, 22);
            this.jsLabel5.TabIndex = 11;
            this.jsLabel5.Text = "پاسخ سوال اول";
            this.jsLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtAnswer
            // 
            this.txtAnswer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtAnswer.Location = new System.Drawing.Point(32, 29);
            this.txtAnswer.MaxLength = 200;
            this.txtAnswer.Name = "txtAnswer";
            this.txtAnswer.Num16 = ((short)(0));
            this.txtAnswer.Num32 = 0;
            this.txtAnswer.Num64 = ((long)(0));
            this.txtAnswer.NumByte = ((byte)(0));
            this.txtAnswer.NumDouble = 0D;
            this.txtAnswer.NumFloat = 0F;
            this.txtAnswer.PersianText = true;
            this.txtAnswer.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txtAnswer.Size = new System.Drawing.Size(151, 30);
            this.txtAnswer.TabIndex = 8;
            // 
            // btnClose
            // 
            this.btnClose.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Close;
            this.btnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnClose.BackColor = System.Drawing.Color.Transparent;
            this.btnClose.ButtonText = "بستن";
            this.btnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnClose.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.btnClose.Image = ((System.Drawing.Image)(resources.GetObject("btnClose.Image")));
            this.btnClose.Location = new System.Drawing.Point(48, 413);
            this.btnClose.Margin = new System.Windows.Forms.Padding(7);
            this.btnClose.MinimumSize = new System.Drawing.Size(120, 40);
            this.btnClose.Name = "btnClose";
            this.btnClose.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnClose.Size = new System.Drawing.Size(120, 40);
            this.btnClose.TabIndex = 20;
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.BtnCloseClick);
            // 
            // FrmUserEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(544, 472);
            this.Controls.Add(this.jsGroupBox1);
            this.Controls.Add(this.jsGroupBox3);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.jsGroupBox2);
            this.Controls.Add(this.btnClose);
            this.Name = "FrmUserEdit";
            this.Text = "ویرایش کاربر";
            this.jsGroupBox1.ResumeLayout(false);
            this.jsGroupBox1.PerformLayout();
            this.jsGroupBox3.ResumeLayout(false);
            this.jsGroupBox3.PerformLayout();
            this.jsGroupBox2.ResumeLayout(false);
            this.jsGroupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSLabel jsLabel11;
        private JSRequirement.Controls.JSTextBox txtDesc;
        private System.Windows.Forms.DateTimePicker txtBirthDate;
        private JSRequirement.Controls.JSGroupBox jsGroupBox1;
        private JSRequirement.Controls.JSTextBox txtpasscodeconfirm;
        private JSRequirement.Controls.JSTextBox txtUserCode;
        private JSRequirement.Controls.JSTextBox txtpasscode;
        private JSRequirement.Controls.JSTextBox txtNicName;
        private JSRequirement.Controls.JSLabel jsLabel4;
        private JSRequirement.Controls.JSLabel jsLabel1;
        private JSRequirement.Controls.JSLabel lblPassCodeConfirm;
        private JSRequirement.Controls.JSLabel jsLabel2;
        private JSRequirement.Controls.JSGroupBox jsGroupBox3;
        private JSRequirement.Controls.JSLabel jsLabel10;
        private JSRequirement.Controls.JSTextBox txtEmail;
        private JSRequirement.Controls.JSLabel jsLabel9;
        private JSRequirement.Controls.JSLabel jsLabel8;
        private JSRequirement.Controls.JSTextBox txtFName;
        private JSRequirement.Controls.JSTextBox txtLName;
        private JSRequirement.Controls.JSLabel jsLabel6;
        private JSRequirement.Controls.JS7Btn btnUpdate;
        private JSRequirement.Controls.JSLabel jsLabel7;
        private JSRequirement.Controls.JSGroupBox jsGroupBox2;
        private JSRequirement.Controls.JSComboBox cmbQuestion;
        private JSRequirement.Controls.JSLabel jsLabel5;
        private JSRequirement.Controls.JSTextBox txtAnswer;
        private JSRequirement.Controls.JS7Btn btnClose;
    }
}
