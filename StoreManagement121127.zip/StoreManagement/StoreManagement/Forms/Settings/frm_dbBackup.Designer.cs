﻿namespace StoreManagement.Forms.Settings
{
    partial class FrmDBBackup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabServers = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lstLocalInstances = new System.Windows.Forms.ListBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lstNetworkInstances = new System.Windows.Forms.ListBox();
            this.txtLogin = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.btnConnect = new System.Windows.Forms.Button();
            this.ddlDatabase = new System.Windows.Forms.ComboBox();
            this.txtFileName = new System.Windows.Forms.TextBox();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.btnBackupDB = new System.Windows.Forms.Button();
            this.btnBackupLog = new System.Windows.Forms.Button();
            this.btnVerify = new System.Windows.Forms.Button();
            this.btnRestore = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.jsLabel1 = new JSRequirement.Controls.JSLabel();
            this.jsLabel2 = new JSRequirement.Controls.JSLabel();
            this.chkWindowsAuthentication = new JSRequirement.Controls.JSCheckBox();
            this.jsLabel3 = new JSRequirement.Controls.JSLabel();
            this.jsLabel4 = new JSRequirement.Controls.JSLabel();
            this.chkIncremental = new JSRequirement.Controls.JSCheckBox();
            this.tabServers.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabServers
            // 
            this.tabServers.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.tabServers.Controls.Add(this.tabPage1);
            this.tabServers.Controls.Add(this.tabPage2);
            this.tabServers.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabServers.Location = new System.Drawing.Point(8, 6);
            this.tabServers.Name = "tabServers";
            this.tabServers.SelectedIndex = 0;
            this.tabServers.Size = new System.Drawing.Size(367, 227);
            this.tabServers.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.lstLocalInstances);
            this.tabPage1.Location = new System.Drawing.Point(4, 23);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(359, 200);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Local Instances";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // lstLocalInstances
            // 
            this.lstLocalInstances.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstLocalInstances.FormattingEnabled = true;
            this.lstLocalInstances.ItemHeight = 14;
            this.lstLocalInstances.Location = new System.Drawing.Point(3, 3);
            this.lstLocalInstances.Name = "lstLocalInstances";
            this.lstLocalInstances.Size = new System.Drawing.Size(353, 194);
            this.lstLocalInstances.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.lstNetworkInstances);
            this.tabPage2.Location = new System.Drawing.Point(4, 23);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(359, 200);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Network Instances";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lstNetworkInstances
            // 
            this.lstNetworkInstances.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lstNetworkInstances.FormattingEnabled = true;
            this.lstNetworkInstances.ItemHeight = 14;
            this.lstNetworkInstances.Location = new System.Drawing.Point(3, 3);
            this.lstNetworkInstances.Name = "lstNetworkInstances";
            this.lstNetworkInstances.Size = new System.Drawing.Size(353, 194);
            this.lstNetworkInstances.TabIndex = 0;
            // 
            // txtLogin
            // 
            this.txtLogin.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtLogin.Enabled = false;
            this.txtLogin.Location = new System.Drawing.Point(461, 6);
            this.txtLogin.MaxLength = 100;
            this.txtLogin.Name = "txtLogin";
            this.txtLogin.Size = new System.Drawing.Size(186, 30);
            this.txtLogin.TabIndex = 3;
            // 
            // txtPassword
            // 
            this.txtPassword.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtPassword.Enabled = false;
            this.txtPassword.Location = new System.Drawing.Point(461, 42);
            this.txtPassword.MaxLength = 100;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.PasswordChar = '*';
            this.txtPassword.Size = new System.Drawing.Size(186, 30);
            this.txtPassword.TabIndex = 4;
            // 
            // btnConnect
            // 
            this.btnConnect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnConnect.Location = new System.Drawing.Point(381, 6);
            this.btnConnect.Name = "btnConnect";
            this.btnConnect.Size = new System.Drawing.Size(74, 65);
            this.btnConnect.TabIndex = 5;
            this.btnConnect.Text = "اتصال";
            this.btnConnect.UseVisualStyleBackColor = true;
            this.btnConnect.Click += new System.EventHandler(this.BtnConnectClick);
            // 
            // ddlDatabase
            // 
            this.ddlDatabase.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ddlDatabase.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ddlDatabase.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ddlDatabase.FormattingEnabled = true;
            this.ddlDatabase.Location = new System.Drawing.Point(381, 110);
            this.ddlDatabase.Name = "ddlDatabase";
            this.ddlDatabase.Size = new System.Drawing.Size(266, 22);
            this.ddlDatabase.TabIndex = 6;
            // 
            // txtFileName
            // 
            this.txtFileName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.txtFileName.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFileName.Location = new System.Drawing.Point(381, 138);
            this.txtFileName.Name = "txtFileName";
            this.txtFileName.Size = new System.Drawing.Size(219, 22);
            this.txtFileName.TabIndex = 8;
            this.txtFileName.Text = "C:\\StoreManagement.bak";
            this.txtFileName.TextChanged += new System.EventHandler(this.TxtFileNameTextChanged);
            // 
            // btnBrowse
            // 
            this.btnBrowse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBrowse.Font = new System.Drawing.Font("Verdana", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.Location = new System.Drawing.Point(606, 138);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(41, 22);
            this.btnBrowse.TabIndex = 9;
            this.btnBrowse.Text = "...";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.BtnBrowseClick);
            // 
            // btnBackupDB
            // 
            this.btnBackupDB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBackupDB.Location = new System.Drawing.Point(517, 166);
            this.btnBackupDB.Name = "btnBackupDB";
            this.btnBackupDB.Size = new System.Drawing.Size(130, 30);
            this.btnBackupDB.TabIndex = 12;
            this.btnBackupDB.Text = "پشتیبان گیری از داده ها";
            this.btnBackupDB.UseVisualStyleBackColor = true;
            this.btnBackupDB.Click += new System.EventHandler(this.BtnBackupDBClick);
            // 
            // btnBackupLog
            // 
            this.btnBackupLog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBackupLog.Location = new System.Drawing.Point(381, 166);
            this.btnBackupLog.Name = "btnBackupLog";
            this.btnBackupLog.Size = new System.Drawing.Size(130, 30);
            this.btnBackupLog.TabIndex = 13;
            this.btnBackupLog.Text = "پشتیبان گیری از لاگ ها";
            this.btnBackupLog.UseVisualStyleBackColor = true;
            this.btnBackupLog.Click += new System.EventHandler(this.BtnBackupLogClick);
            // 
            // btnVerify
            // 
            this.btnVerify.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnVerify.Location = new System.Drawing.Point(381, 202);
            this.btnVerify.Name = "btnVerify";
            this.btnVerify.Size = new System.Drawing.Size(130, 30);
            this.btnVerify.TabIndex = 14;
            this.btnVerify.Text = "تایید";
            this.btnVerify.UseVisualStyleBackColor = true;
            this.btnVerify.Click += new System.EventHandler(this.BtnVerifyClick);
            // 
            // btnRestore
            // 
            this.btnRestore.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnRestore.Location = new System.Drawing.Point(517, 202);
            this.btnRestore.Name = "btnRestore";
            this.btnRestore.Size = new System.Drawing.Size(130, 30);
            this.btnRestore.TabIndex = 15;
            this.btnRestore.Text = "بازیابی";
            this.btnRestore.UseVisualStyleBackColor = true;
            this.btnRestore.Click += new System.EventHandler(this.BtnRestoreClick);
            // 
            // dataGridView1
            // 
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.Location = new System.Drawing.Point(8, 239);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(639, 62);
            this.dataGridView1.TabIndex = 18;
            this.dataGridView1.Text = "dataGridView1";
            // 
            // progressBar1
            // 
            this.progressBar1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.progressBar1.Location = new System.Drawing.Point(8, 307);
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(639, 23);
            this.progressBar1.TabIndex = 17;
            // 
            // jsLabel1
            // 
            this.jsLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel1.AutoSize = true;
            this.jsLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel1.Location = new System.Drawing.Point(653, 9);
            this.jsLabel1.Name = "jsLabel1";
            this.jsLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel1.Size = new System.Drawing.Size(57, 22);
            this.jsLabel1.TabIndex = 19;
            this.jsLabel1.Text = "نام کاربری";
            this.jsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel2
            // 
            this.jsLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel2.AutoSize = true;
            this.jsLabel2.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel2.Location = new System.Drawing.Point(653, 45);
            this.jsLabel2.Name = "jsLabel2";
            this.jsLabel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel2.Size = new System.Drawing.Size(42, 22);
            this.jsLabel2.TabIndex = 20;
            this.jsLabel2.Text = "گذرواژه";
            this.jsLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkWindowsAuthentication
            // 
            this.chkWindowsAuthentication.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkWindowsAuthentication.AutoSize = true;
            this.chkWindowsAuthentication.BackColor = System.Drawing.Color.Transparent;
            this.chkWindowsAuthentication.Checked = true;
            this.chkWindowsAuthentication.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkWindowsAuthentication.Location = new System.Drawing.Point(506, 78);
            this.chkWindowsAuthentication.Name = "chkWindowsAuthentication";
            this.chkWindowsAuthentication.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chkWindowsAuthentication.Size = new System.Drawing.Size(141, 26);
            this.chkWindowsAuthentication.TabIndex = 21;
            this.chkWindowsAuthentication.Text = "استفاده از شناسایی ویندوز";
            this.chkWindowsAuthentication.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkWindowsAuthentication.UseVisualStyleBackColor = false;
            this.chkWindowsAuthentication.CheckedChanged += new System.EventHandler(this.ChkWindowsAuthenticationCheckedChanged);
            // 
            // jsLabel3
            // 
            this.jsLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel3.AutoSize = true;
            this.jsLabel3.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel3.Location = new System.Drawing.Point(653, 115);
            this.jsLabel3.Name = "jsLabel3";
            this.jsLabel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel3.Size = new System.Drawing.Size(46, 22);
            this.jsLabel3.TabIndex = 22;
            this.jsLabel3.Text = "دیتابیس";
            this.jsLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel4
            // 
            this.jsLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel4.AutoSize = true;
            this.jsLabel4.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel4.Location = new System.Drawing.Point(653, 143);
            this.jsLabel4.Name = "jsLabel4";
            this.jsLabel4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel4.Size = new System.Drawing.Size(58, 22);
            this.jsLabel4.TabIndex = 23;
            this.jsLabel4.Text = "آدرس فایل";
            this.jsLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // chkIncremental
            // 
            this.chkIncremental.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.chkIncremental.AutoSize = true;
            this.chkIncremental.BackColor = System.Drawing.Color.Transparent;
            this.chkIncremental.Location = new System.Drawing.Point(381, 78);
            this.chkIncremental.Name = "chkIncremental";
            this.chkIncremental.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.chkIncremental.Size = new System.Drawing.Size(62, 26);
            this.chkIncremental.TabIndex = 24;
            this.chkIncremental.Text = "افزایشی";
            this.chkIncremental.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.chkIncremental.UseVisualStyleBackColor = false;
            // 
            // FrmDBBackup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(791, 340);
            this.Controls.Add(this.jsLabel4);
            this.Controls.Add(this.jsLabel3);
            this.Controls.Add(this.chkWindowsAuthentication);
            this.Controls.Add(this.chkIncremental);
            this.Controls.Add(this.jsLabel2);
            this.Controls.Add(this.jsLabel1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txtFileName);
            this.Controls.Add(this.ddlDatabase);
            this.Controls.Add(this.btnBackupDB);
            this.Controls.Add(this.btnConnect);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.btnBackupLog);
            this.Controls.Add(this.btnVerify);
            this.Controls.Add(this.txtLogin);
            this.Controls.Add(this.btnRestore);
            this.Controls.Add(this.tabServers);
            this.FormTitle = "سیستم جامع پشتیبان گیری";
            this.Name = "FrmDBBackup";
            this.Text = "سامانه مدیریت فروشگاه | سیستم جامع پشتیبان گیری";
            this.Load += new System.EventHandler(this.FrmMainLoad);
            this.Controls.SetChildIndex(this.tabServers, 0);
            this.Controls.SetChildIndex(this.btnRestore, 0);
            this.Controls.SetChildIndex(this.txtLogin, 0);
            this.Controls.SetChildIndex(this.btnVerify, 0);
            this.Controls.SetChildIndex(this.btnBackupLog, 0);
            this.Controls.SetChildIndex(this.txtPassword, 0);
            this.Controls.SetChildIndex(this.btnConnect, 0);
            this.Controls.SetChildIndex(this.btnBackupDB, 0);
            this.Controls.SetChildIndex(this.ddlDatabase, 0);
            this.Controls.SetChildIndex(this.txtFileName, 0);
            this.Controls.SetChildIndex(this.btnBrowse, 0);
            this.Controls.SetChildIndex(this.progressBar1, 0);
            this.Controls.SetChildIndex(this.dataGridView1, 0);
            this.Controls.SetChildIndex(this.jsLabel1, 0);
            this.Controls.SetChildIndex(this.jsLabel2, 0);
            this.Controls.SetChildIndex(this.chkIncremental, 0);
            this.Controls.SetChildIndex(this.chkWindowsAuthentication, 0);
            this.Controls.SetChildIndex(this.jsLabel3, 0);
            this.Controls.SetChildIndex(this.jsLabel4, 0);
            this.tabServers.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabServers;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.ListBox lstLocalInstances;
        private System.Windows.Forms.ListBox lstNetworkInstances;
        private System.Windows.Forms.TextBox txtLogin;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Button btnConnect;
        private System.Windows.Forms.ComboBox ddlDatabase;
        private System.Windows.Forms.TextBox txtFileName;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Button btnBackupDB;
        private System.Windows.Forms.Button btnBackupLog;
        private System.Windows.Forms.Button btnVerify;
        private System.Windows.Forms.Button btnRestore;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ProgressBar progressBar1;
        private JSRequirement.Controls.JSLabel jsLabel1;
        private JSRequirement.Controls.JSLabel jsLabel2;
        private JSRequirement.Controls.JSCheckBox chkWindowsAuthentication;
        private JSRequirement.Controls.JSLabel jsLabel3;
        private JSRequirement.Controls.JSLabel jsLabel4;
        private JSRequirement.Controls.JSCheckBox chkIncremental;
    }
}


