﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace StoreManagement.Forms.frm_Supplier
{
    public partial class FrmSupplier : Requirement.JSfrmBase
    {
        public FrmSupplier()
        {
            InitializeComponent();
            UpdateDateGrid();
        }
        public void UpdateDateGrid()
        {
            jsDataGrid1.DataSource = new Requirement.SMLinqDataContext().tbl_SM_Suppliers;
        }

        private void JS7Btn4Click(object sender, EventArgs e)
        {
            Close();
        }

        private void JS7Btn3Click(object sender, EventArgs e)
        {
            try
            {
                if (jsDataGrid1.CurrentRow == null)
                    return;

                var sid = Convert.ToInt16(jsDataGrid1.CurrentRow.Cells["SupplierID"].Value);
                if (new Requirement.SMLinqDataContext().tbl_SM_Purchases.Where(c => c.SupplierID == sid).Count() > 0)
                {
                    MessageBox.Show(@"از این شرکت خرید انجام گرفته است" + Environment.NewLine
                                    + @"برای حذف واحد ابتدا خریدهایی که از این شرکت استفاده نموده اند را حذف فرمایید!",
                                    @"توجه"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }

                if (
                    MessageBox.Show(Properties.Settings.Default.AppMsgDelete, @"حذف", MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Question) == DialogResult.No)
                    return;

                new Requirement.SMLinqDataContext().JSP_SM_Suppliers_Delete(sid);
                UpdateDateGrid();
            }
            catch (Exception)
            {
                MessageBox.Show(@"خطایی در حذف رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void JS7Btn2Click(object sender, EventArgs e)
        {
            try
            {

                if (jsDataGrid1.CurrentRow == null)
                    return;
                new FrmSupplierEdit(
                    Convert.ToInt16(jsDataGrid1.CurrentRow.Cells["SupplierID"].Value),
                    jsDataGrid1.CurrentRow.Cells["SName"].Value.ToString(),
                    jsDataGrid1.CurrentRow.Cells["SAddress"].Value.ToString(),
                    jsDataGrid1.CurrentRow.Cells["STel"].Value.ToString(),
                    jsDataGrid1.CurrentRow.Cells["SDesc"].Value.ToString(),
                    jsDataGrid1.CurrentRow.Cells["SVisitor"].Value.ToString(),
                    jsDataGrid1.CurrentRow.Cells["SVMobile"].Value.ToString()
                    ).ShowDialog();
                UpdateDateGrid();
            }
            catch
            {
                MessageBox.Show(@"خطایی در ویرایش رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {
            new FrmSupplierAdd().ShowDialog();
            //UpdateDateGrid();
        }
    }
}
