﻿using System;

namespace StoreManagement.Forms.frm_ProductUnit
{
    public partial class FrmUnitAdd : Requirement.FrmPopup
    {
        public FrmUnitAdd()
        {
            InitializeComponent();
        }

        private void JS7Btn2Click(object sender, EventArgs e)
        {
            Close();
        }

        private void JSTextBox1TextChanged(object sender, EventArgs e)
        {
            jS7Btn1.Enabled = !string.IsNullOrWhiteSpace(jsTextBox1.Text);
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {
            new Requirement.SMLinqDataContext().JSP_SM_ProductsUnits_Add(jsTextBox1.Text, DateTime.Now);
            Close();
        }
    }
}
