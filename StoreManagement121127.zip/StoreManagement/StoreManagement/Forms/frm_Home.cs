﻿using System.Windows.Forms;
using StoreManagement.Forms.frm_ProductCategory;

namespace StoreManagement.Forms
{
    public partial class FrmHome : JSRequirement.Forms.JSBaseForm
    {
        private readonly string _usercode;
        public static FrmHome Instance { get; private set; }
        public static int LoadedForm { get; set; }

        public FrmHome(string usercode)
        {
            _usercode = usercode;
            InitializeComponent();
            Instance = this;
            jsMenuStripStoreManagement1.ParentForm = this;
        }

        private void FrmHomeFormClosing(object sender, FormClosingEventArgs e)
        {
            if (e.CloseReason.ToString() == string.Empty) { e.Cancel = true;
                MessageBox.Show(e.CloseReason.ToString());
            }
        }

        private void JS7Btn4Click(object sender, System.EventArgs e)
        {
            new Settings.FrmAppSettings().ShowDialog(this);
        }

        private void JS7Btn5Click(object sender, System.EventArgs e)
        {
            new FrmCategory().ShowDialog(this);
        }

        private void JS7Btn1Click(object sender, System.EventArgs e)
        {
            new frm_Customer.FrmCustomer().ShowDialog(this);
        }

        private void JS7Btn3Click(object sender, System.EventArgs e)
        {
            new frm_ProductUnit.FrmUnit().ShowDialog(this);
        }

        private void JS7Btn6Click(object sender, System.EventArgs e)
        {
            new frm_Supplier.FrmSupplier().ShowDialog(this);
        }

        private void JS7Btn7Click(object sender, System.EventArgs e)
        {
            new frm_Product.FrmProduct().ShowDialog(this);
        }

        private void JS7Btn8Click(object sender, System.EventArgs e)
        {
            new frm_Sale.FrmSale().ShowDialog(this);
        }

        private void JS7Btn9Click(object sender, System.EventArgs e)
        {
            LoadedForm++;
            new frm_Sale.FrmSaleAdd().ShowDialog(this);
        }

        private void JS7Btn2Click(object sender, System.EventArgs e)
        {
            new frm_Purchase.FrmPurchase().ShowDialog(this);
        }

        private void JS7Btn10Click(object sender, System.EventArgs e)
        {
            new frm_Purchase.FrmPurchaseAdd().ShowDialog(this);
        }

        private void JS7Btn11Click(object sender, System.EventArgs e)
        {
            new frm_User.FrmUser().ShowDialog(this);
        }

        private void FrmHomeLoad(object sender, System.EventArgs e)
        {
            try
            {
                Text = Program.AppTitle + @" | صفحه اصلی";
            }
            catch { return; }
        }

        private void JS7Btn12Click(object sender, System.EventArgs e)
        {
            new Reports.FrmStatistics().ShowDialog(this);
        }




    }
}
