﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace StoreManagement.Forms
{
    public partial class frm_Test_Database : StoreManagement.Requirement.JSfrmBase
    {
        public frm_Test_Database()
        {
            InitializeComponent();
        }
    }
}
