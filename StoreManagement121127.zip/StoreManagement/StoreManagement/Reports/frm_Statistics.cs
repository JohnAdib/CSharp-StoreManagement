﻿using System;
using System.Linq;

namespace StoreManagement.Reports
{
    public partial class FrmStatistics : Requirement.JSfrmBase
    {
        public FrmStatistics()
        {
            InitializeComponent();
        }

        private void FrmStatisticsLoad(object sender, EventArgs e)
        {
            CalcStatistics();
        }

        private void CalcStatistics()
        {
            jsCustomer1.Text = new Requirement.SMLinqDataContext().tbl_SM_Customers.Count().ToString();
            jsCustomer2.Text = new Requirement.SMLinqDataContext().tbl_SM_Sales.Select(c => c.CustomerID).Distinct().Count().ToString();
            jsCustomer3.Text =
                new Requirement.SMLinqDataContext().tbl_SM_Sales.Select(c => new {c.CustomerID, c.Credit}).Where(
                    c => c.Credit).Distinct().Count().ToString();
            jsCustomer4.Text = jsCustomer1.
        }

    }
}
