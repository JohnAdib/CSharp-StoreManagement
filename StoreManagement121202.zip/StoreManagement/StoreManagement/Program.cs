﻿using System;
using System.Threading;
using System.Windows.Forms;
using StoreManagement.Forms;
using StoreManagement.Forms.Security;
using StoreManagement.Forms.Settings;

namespace StoreManagement
{
    static class Program
    {
        public static string AppTitle { get; set; }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.ThreadException += ApplicationThreadException;
            //Application.Run(new FrmDBBackup());
            try
            {
                AppTitle = Properties.Settings.Default.AppNamePre + @" " + Properties.Settings.Default.AppName;

                var frmLogin = new FrmLogin();
                if (frmLogin.ShowDialog() == DialogResult.OK)
                {
                    Application.Run(new FrmHome(frmLogin.UserName));
                }
                
            }
            catch(Exception ex )
            {
                MessageBox.Show(ex.Message, @"خطا");
                return;
            }

        }

        static void ApplicationThreadException(object sender, ThreadExceptionEventArgs e)
        {
            MessageBox.Show(e.Exception.ToString(), @"خطا در اجرای دستورات");
        }

    }
}
