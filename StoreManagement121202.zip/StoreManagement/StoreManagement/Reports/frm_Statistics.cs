﻿using System;
using System.Data.Linq;
using System.Linq;
using StoreManagement.Requirement;

namespace StoreManagement.Reports
{
    public partial class FrmStatistics : JSfrmBase
    {
        public FrmStatistics()
        {
            InitializeComponent();
        }

        private readonly Table<tbl_DB_User> _dataUser = new SMLinqDataContext().tbl_DB_Users;
        private readonly Table<tbl_SM_ProductsUnit> _dataUnit = new SMLinqDataContext().tbl_SM_ProductsUnits;
        private readonly Table<tbl_SM_Supplier> _dataSupplier = new SMLinqDataContext().tbl_SM_Suppliers;
        private readonly Table<tbl_SM_Customer> _dataCustomer = new SMLinqDataContext().tbl_SM_Customers;
        private readonly Table<Requirement.tbl_SM_ProductsCategory> _dataCategory =
            new SMLinqDataContext().tbl_SM_ProductsCategories;
        private readonly Table<tbl_SM_Product> _dataProduct = new SMLinqDataContext().tbl_SM_Products;

        private readonly Table<tbl_SM_Sale> _dataSale = new SMLinqDataContext().tbl_SM_Sales;
        private readonly Table<tbl_SM_SalesDetail> _dataSaleDetail = new SMLinqDataContext().tbl_SM_SalesDetails;
        private readonly Table<View_SM_Sale> _dataSaleView = new SMLinqDataContext().View_SM_Sales;

        private readonly Table<tbl_SM_Purchase> _dataPurchase = new SMLinqDataContext().tbl_SM_Purchases;
        private readonly Table<View_SM_Purchase> _dataPurchaseView = new SMLinqDataContext().View_SM_Purchases;


        private void FrmStatisticsLoad(object sender, EventArgs e)
        {
            JsfGeneralStats();
            JsfProductStats();
            JsfUserStats();
            JsfSaleStats();
            JsfPurchaseStats();
        }

        private void JsfGeneralStats()
        {
            
            // Customers General Information
            jstxtCustomer1.Text = _dataCustomer.Count().ToString();
            jstxtCustomer2.Text = _dataSale.Select(c => c.CustomerID).Distinct().Count().ToString();
            jstxtCustomer3.Text =
                _dataSale.Select(c => new {c.CustomerID, c.Credit}).Where(c => c.Credit).Distinct().Count().ToString();
            jstxtCustomer4.Num32 = jstxtCustomer1.Num32 - jstxtCustomer2.Num32;

            // Product Category General Information
            jstxtCategory1.Text = _dataCategory.Count().ToString();

            // Product Unit General Information            
            jstxtUnit1.Text = _dataUnit.Count().ToString();

            // Supplier General Information
            jstxtSupplier1.Text = _dataSupplier.Count().ToString();
            
        }

        private void JsfProductStats()
        {

            
            // General Information
            jstxtProduct1.Text = _dataProduct.Count().ToString();
            jstxtProduct2.Text = _dataSaleDetail.Select(c => c.ProductID).Distinct().Count().ToString();
            jstxtProduct3.Num32 = jstxtProduct1.Num32 - jstxtProduct2.Num32;

            // Barcode Information
            jstxtProductBarcode1.Text = _dataProduct.Select(c => c.PBarCode).Count().ToString();
            jstxtProductBarcode2.Text = (jstxtProduct1.Num32 - jstxtProductBarcode1.Num32).ToString();
            jstxtProductBarcode3.Text = _dataProduct.Select(c => c.PBarCode2).Count().ToString();
            jstxtProductBarcode4.Text = (jstxtProduct1.Num32 - jstxtProductBarcode3.Num32).ToString();
            // Product Information


            jstxtProductWarehouse1.Text = _dataProduct.Select(c => c.PSize).Average().ToString();
            jstxtProductWarehouse2.Text = _dataProduct.Select(c => c.PMinInventory).Average().ToString();
            jstxtProductWarehouse3.Text = _dataProduct.Select(c => c.PStock).Average().ToString();
            jstxtProductWarehouse4.Text = _dataProduct.Select(c => c.PStock).Sum().ToString();
            jstxtProductWarehouse5.Text = _dataProduct.Select(c => c.PSold).Sum().ToString();
            jstxtProductWarehouse6.Text = _dataProduct.Select(c => c.PBuyPrice).Average().ToString();
            jstxtProductWarehouse7.Text = _dataProduct.Select(c => c.PPrice).Average().ToString();
            jstxtProductWarehouse8.Text = _dataProduct.Select(c => c.PDiscount).Average().ToString();
            jstxtProductWarehouse9.Text = _dataProduct.Select(c => c.PDiscount).Max().ToString();
            jstxtProductWarehouse10.Text = (jstxtProductWarehouse7.Num32 - jstxtProductWarehouse6.Num32).ToString();
            jstxtProductWarehouse11.Text =
                (Math.Round(
                    ((jstxtProductWarehouse7.NumFloat - jstxtProductWarehouse6.NumFloat)/jstxtProductWarehouse6.NumFloat)*
                    100, 2)).ToString();
        }

        private void JsfUserStats()
        {
            //var dataUser = new Requirement.SMLinqDataContext().tbl_DB_Users;

            // User General Information
            jstxtUser1.Text = _dataUser.Count().ToString();
            jstxtUser2.Text = _dataUser.Where(c => c.Status == true).Count().ToString();
            jstxtUser3.Text = _dataUser.Where(c => c.Admin).Count().ToString();
            jstxtUser4.Text = _dataUser.Select(c => c.TotalSales).Average().ToString();
            jstxtUser5.Text = _dataUser.Select(c => c.TotalSales).Max().ToString();
            jstxtUser6.Text = _dataSale.Select(c => c.UserID).Distinct().Count().ToString();
        }

        private void JsfSaleStats()
        {
            // Sale General Information
            jstxtSaleGeneral1.Text = _dataSale.Count().ToString();
            jstxtSaleGeneral2.Text = _dataSale.Where(c => c.Credit).Count().ToString();
            jstxtSaleGeneral3.Text = _dataSale.Where(c => c.Credit == false).Count().ToString();

            // Sale Detailes Information
            jstxtSaleDetail1.Text = _dataSaleView.Select(c => c.totalsalecount).Average().ToString();
            jstxtSaleDetail2.Text = _dataSaleView.Select(c => c.totalcount).Average().ToString();
            jstxtSaleDetail3.Text = _dataSaleView.Select(c => c.totalsalecount).Sum().ToString();
            jstxtSaleDetail4.Text = _dataSaleView.Select(c => c.totalcount).Sum().ToString();
        }

        private void JsfPurchaseStats()
        {


            // Sale General Information
            jstxtPurchaseGeneral1.Text = _dataPurchase.Count().ToString();
            jstxtPurchaseGeneral2.Text = _dataPurchase.Where(c => c.Credit).Count().ToString();
            jstxtPurchaseGeneral3.Text = _dataPurchase.Where(c => c.Credit == false).Count().ToString();

            // Sale Detailes Information
            jstxtPurchaseDetail1.Text = _dataPurchaseView.Select(c => c.totalsalecount).Average().ToString();
            jstxtPurchaseDetail2.Text = _dataPurchaseView.Select(c => c.totalcount).Average().ToString();
            jstxtPurchaseDetail2.Text = jstxtPurchaseDetail2.NumFloat.ToString();
            
            jstxtPurchaseDetail3.Text = _dataPurchaseView.Select(c => c.totalsalecount).Sum().ToString();
            jstxtPurchaseDetail4.Text = _dataPurchaseView.Select(c => c.totalcount).Sum().ToString();
        }
    }
}
