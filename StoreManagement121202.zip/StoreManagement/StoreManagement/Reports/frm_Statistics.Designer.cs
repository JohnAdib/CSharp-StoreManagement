﻿namespace StoreManagement.Reports
{
    partial class FrmStatistics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StatisticsTab = new System.Windows.Forms.TabControl();
            this.tabCustomers = new System.Windows.Forms.TabPage();
            this.jsGbxSupplierGeneral = new JSRequirement.Controls.JSGroupBox();
            this.jstxtSupplier1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel34 = new JSRequirement.Controls.JSLabel();
            this.jsGbxUnitGeneral = new JSRequirement.Controls.JSGroupBox();
            this.jstxtUnit1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel21 = new JSRequirement.Controls.JSLabel();
            this.jsGbxCategoryGeneral = new JSRequirement.Controls.JSGroupBox();
            this.jstxtCategory1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel24 = new JSRequirement.Controls.JSLabel();
            this.jsGbxCustomerGeneral = new JSRequirement.Controls.JSGroupBox();
            this.jstxtCustomer4 = new JSRequirement.Controls.JSTextBox();
            this.jstxtCustomer3 = new JSRequirement.Controls.JSTextBox();
            this.jstxtCustomer2 = new JSRequirement.Controls.JSTextBox();
            this.jstxtCustomer1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel7 = new JSRequirement.Controls.JSLabel();
            this.jsLabel3 = new JSRequirement.Controls.JSLabel();
            this.jsLabel2 = new JSRequirement.Controls.JSLabel();
            this.jsLabel1 = new JSRequirement.Controls.JSLabel();
            this.tabSale = new System.Windows.Forms.TabPage();
            this.jsGbxSaleDetail = new JSRequirement.Controls.JSGroupBox();
            this.jstxtSaleDetail4 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel36 = new JSRequirement.Controls.JSLabel();
            this.jstxtSaleDetail3 = new JSRequirement.Controls.JSTextBox();
            this.jstxtSaleDetail2 = new JSRequirement.Controls.JSTextBox();
            this.jstxtSaleDetail1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel32 = new JSRequirement.Controls.JSLabel();
            this.jsLabel33 = new JSRequirement.Controls.JSLabel();
            this.jsLabel35 = new JSRequirement.Controls.JSLabel();
            this.jsGbxSaleGeneral = new JSRequirement.Controls.JSGroupBox();
            this.jstxtSaleGeneral3 = new JSRequirement.Controls.JSTextBox();
            this.jstxtSaleGeneral2 = new JSRequirement.Controls.JSTextBox();
            this.jstxtSaleGeneral1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel27 = new JSRequirement.Controls.JSLabel();
            this.jsLabel30 = new JSRequirement.Controls.JSLabel();
            this.jsLabel31 = new JSRequirement.Controls.JSLabel();
            this.tabPurchase = new System.Windows.Forms.TabPage();
            this.jsGbxPurchaseDetail = new JSRequirement.Controls.JSGroupBox();
            this.jstxtPurchaseDetail4 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel42 = new JSRequirement.Controls.JSLabel();
            this.jstxtPurchaseDetail3 = new JSRequirement.Controls.JSTextBox();
            this.jstxtPurchaseDetail2 = new JSRequirement.Controls.JSTextBox();
            this.jstxtPurchaseDetail1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel43 = new JSRequirement.Controls.JSLabel();
            this.jsLabel44 = new JSRequirement.Controls.JSLabel();
            this.jsLabel45 = new JSRequirement.Controls.JSLabel();
            this.jsGbxPurchaseGeneral = new JSRequirement.Controls.JSGroupBox();
            this.jstxtPurchaseGeneral3 = new JSRequirement.Controls.JSTextBox();
            this.jstxtPurchaseGeneral2 = new JSRequirement.Controls.JSTextBox();
            this.jstxtPurchaseGeneral1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel37 = new JSRequirement.Controls.JSLabel();
            this.jsLabel38 = new JSRequirement.Controls.JSLabel();
            this.jsLabel39 = new JSRequirement.Controls.JSLabel();
            this.tabProducts = new System.Windows.Forms.TabPage();
            this.jsGbxProductWarehouse = new JSRequirement.Controls.JSGroupBox();
            this.jstxtProductWarehouse11 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel41 = new JSRequirement.Controls.JSLabel();
            this.jstxtProductWarehouse10 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel40 = new JSRequirement.Controls.JSLabel();
            this.jstxtProductWarehouse9 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel20 = new JSRequirement.Controls.JSLabel();
            this.jstxtProductWarehouse8 = new JSRequirement.Controls.JSTextBox();
            this.jstxtProductWarehouse7 = new JSRequirement.Controls.JSTextBox();
            this.jstxtProductWarehouse6 = new JSRequirement.Controls.JSTextBox();
            this.jstxtProductWarehouse5 = new JSRequirement.Controls.JSTextBox();
            this.jstxtProductWarehouse4 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel19 = new JSRequirement.Controls.JSLabel();
            this.jsLabel18 = new JSRequirement.Controls.JSLabel();
            this.jsLabel15 = new JSRequirement.Controls.JSLabel();
            this.jsLabel16 = new JSRequirement.Controls.JSLabel();
            this.jsLabel17 = new JSRequirement.Controls.JSLabel();
            this.jstxtProductWarehouse3 = new JSRequirement.Controls.JSTextBox();
            this.jstxtProductWarehouse2 = new JSRequirement.Controls.JSTextBox();
            this.jstxtProductWarehouse1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel12 = new JSRequirement.Controls.JSLabel();
            this.jsLabel13 = new JSRequirement.Controls.JSLabel();
            this.jsLabel14 = new JSRequirement.Controls.JSLabel();
            this.jsGbxProductGeneral = new JSRequirement.Controls.JSGroupBox();
            this.jstxtProduct3 = new JSRequirement.Controls.JSTextBox();
            this.jstxtProduct2 = new JSRequirement.Controls.JSTextBox();
            this.jstxtProduct1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel5 = new JSRequirement.Controls.JSLabel();
            this.jsLabel6 = new JSRequirement.Controls.JSLabel();
            this.jsLabel8 = new JSRequirement.Controls.JSLabel();
            this.jsGbxProductBarcode = new JSRequirement.Controls.JSGroupBox();
            this.jstxtProductBarcode4 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel11 = new JSRequirement.Controls.JSLabel();
            this.jstxtProductBarcode2 = new JSRequirement.Controls.JSTextBox();
            this.jstxtProductBarcode3 = new JSRequirement.Controls.JSTextBox();
            this.jstxtProductBarcode1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel10 = new JSRequirement.Controls.JSLabel();
            this.jsLabel4 = new JSRequirement.Controls.JSLabel();
            this.jsLabel9 = new JSRequirement.Controls.JSLabel();
            this.tabUser = new System.Windows.Forms.TabPage();
            this.jsGbxUserGeneral = new JSRequirement.Controls.JSGroupBox();
            this.jstxtUser6 = new JSRequirement.Controls.JSTextBox();
            this.jstxtUser5 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel28 = new JSRequirement.Controls.JSLabel();
            this.jsLabel29 = new JSRequirement.Controls.JSLabel();
            this.jstxtUser4 = new JSRequirement.Controls.JSTextBox();
            this.jstxtUser3 = new JSRequirement.Controls.JSTextBox();
            this.jstxtUser2 = new JSRequirement.Controls.JSTextBox();
            this.jstxtUser1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel22 = new JSRequirement.Controls.JSLabel();
            this.jsLabel23 = new JSRequirement.Controls.JSLabel();
            this.jsLabel25 = new JSRequirement.Controls.JSLabel();
            this.jsLabel26 = new JSRequirement.Controls.JSLabel();
            this.StatisticsTab.SuspendLayout();
            this.tabCustomers.SuspendLayout();
            this.jsGbxSupplierGeneral.SuspendLayout();
            this.jsGbxUnitGeneral.SuspendLayout();
            this.jsGbxCategoryGeneral.SuspendLayout();
            this.jsGbxCustomerGeneral.SuspendLayout();
            this.tabSale.SuspendLayout();
            this.jsGbxSaleDetail.SuspendLayout();
            this.jsGbxSaleGeneral.SuspendLayout();
            this.tabPurchase.SuspendLayout();
            this.jsGbxPurchaseDetail.SuspendLayout();
            this.jsGbxPurchaseGeneral.SuspendLayout();
            this.tabProducts.SuspendLayout();
            this.jsGbxProductWarehouse.SuspendLayout();
            this.jsGbxProductGeneral.SuspendLayout();
            this.jsGbxProductBarcode.SuspendLayout();
            this.tabUser.SuspendLayout();
            this.jsGbxUserGeneral.SuspendLayout();
            this.SuspendLayout();
            // 
            // StatisticsTab
            // 
            this.StatisticsTab.Controls.Add(this.tabCustomers);
            this.StatisticsTab.Controls.Add(this.tabSale);
            this.StatisticsTab.Controls.Add(this.tabPurchase);
            this.StatisticsTab.Controls.Add(this.tabProducts);
            this.StatisticsTab.Controls.Add(this.tabUser);
            this.StatisticsTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.StatisticsTab.Location = new System.Drawing.Point(0, 0);
            this.StatisticsTab.Name = "StatisticsTab";
            this.StatisticsTab.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StatisticsTab.RightToLeftLayout = true;
            this.StatisticsTab.SelectedIndex = 0;
            this.StatisticsTab.Size = new System.Drawing.Size(786, 458);
            this.StatisticsTab.TabIndex = 4;
            // 
            // tabCustomers
            // 
            this.tabCustomers.Controls.Add(this.jsGbxSupplierGeneral);
            this.tabCustomers.Controls.Add(this.jsGbxUnitGeneral);
            this.tabCustomers.Controls.Add(this.jsGbxCategoryGeneral);
            this.tabCustomers.Controls.Add(this.jsGbxCustomerGeneral);
            this.tabCustomers.Location = new System.Drawing.Point(4, 31);
            this.tabCustomers.Name = "tabCustomers";
            this.tabCustomers.Padding = new System.Windows.Forms.Padding(3);
            this.tabCustomers.Size = new System.Drawing.Size(778, 423);
            this.tabCustomers.TabIndex = 0;
            this.tabCustomers.Text = "آمار عمومی";
            this.tabCustomers.UseVisualStyleBackColor = true;
            // 
            // jsGbxSupplierGeneral
            // 
            this.jsGbxSupplierGeneral.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGbxSupplierGeneral.BackColor = System.Drawing.Color.Transparent;
            this.jsGbxSupplierGeneral.Controls.Add(this.jstxtSupplier1);
            this.jsGbxSupplierGeneral.Controls.Add(this.jsLabel34);
            this.jsGbxSupplierGeneral.Location = new System.Drawing.Point(12, 6);
            this.jsGbxSupplierGeneral.Name = "jsGbxSupplierGeneral";
            this.jsGbxSupplierGeneral.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGbxSupplierGeneral.Size = new System.Drawing.Size(377, 87);
            this.jsGbxSupplierGeneral.TabIndex = 33;
            this.jsGbxSupplierGeneral.TabStop = false;
            this.jsGbxSupplierGeneral.Text = "آمار کلی شرکت های پخش";
            // 
            // jstxtSupplier1
            // 
            this.jstxtSupplier1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtSupplier1.BarcodeBox = true;
            this.jstxtSupplier1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtSupplier1.Location = new System.Drawing.Point(30, 29);
            this.jstxtSupplier1.MaxLength = 20;
            this.jstxtSupplier1.Name = "jstxtSupplier1";
            this.jstxtSupplier1.Num16 = ((short)(0));
            this.jstxtSupplier1.Num32 = 0;
            this.jstxtSupplier1.Num64 = ((long)(0));
            this.jstxtSupplier1.NumByte = ((byte)(0));
            this.jstxtSupplier1.NumDouble = 0D;
            this.jstxtSupplier1.NumericTextBox = false;
            this.jstxtSupplier1.NumFloat = 0F;
            this.jstxtSupplier1.PersianText = true;
            this.jstxtSupplier1.ReadOnly = true;
            this.jstxtSupplier1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtSupplier1.Size = new System.Drawing.Size(100, 26);
            this.jstxtSupplier1.TabIndex = 13;
            this.jstxtSupplier1.TabStop = false;
            this.jstxtSupplier1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.jstxtSupplier1.Validating += new System.ComponentModel.CancelEventHandler(this.jstxtSupplier1_Validating);
            // 
            // jsLabel34
            // 
            this.jsLabel34.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel34.AutoSize = true;
            this.jsLabel34.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel34.Location = new System.Drawing.Point(136, 33);
            this.jsLabel34.Name = "jsLabel34";
            this.jsLabel34.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel34.Size = new System.Drawing.Size(176, 22);
            this.jsLabel34.TabIndex = 4;
            this.jsLabel34.Text = "مجموع تعداد توزیع کنندگان ثبت شده";
            this.jsLabel34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsGbxUnitGeneral
            // 
            this.jsGbxUnitGeneral.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGbxUnitGeneral.BackColor = System.Drawing.Color.Transparent;
            this.jsGbxUnitGeneral.Controls.Add(this.jstxtUnit1);
            this.jsGbxUnitGeneral.Controls.Add(this.jsLabel21);
            this.jsGbxUnitGeneral.Location = new System.Drawing.Point(395, 280);
            this.jsGbxUnitGeneral.Name = "jsGbxUnitGeneral";
            this.jsGbxUnitGeneral.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGbxUnitGeneral.Size = new System.Drawing.Size(377, 86);
            this.jsGbxUnitGeneral.TabIndex = 32;
            this.jsGbxUnitGeneral.TabStop = false;
            this.jsGbxUnitGeneral.Text = "آمار کلی واحد شمارش";
            // 
            // jstxtUnit1
            // 
            this.jstxtUnit1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtUnit1.BarcodeBox = true;
            this.jstxtUnit1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtUnit1.Location = new System.Drawing.Point(30, 29);
            this.jstxtUnit1.MaxLength = 20;
            this.jstxtUnit1.Name = "jstxtUnit1";
            this.jstxtUnit1.Num16 = ((short)(0));
            this.jstxtUnit1.Num32 = 0;
            this.jstxtUnit1.Num64 = ((long)(0));
            this.jstxtUnit1.NumByte = ((byte)(0));
            this.jstxtUnit1.NumDouble = 0D;
            this.jstxtUnit1.NumericTextBox = false;
            this.jstxtUnit1.NumFloat = 0F;
            this.jstxtUnit1.PersianText = true;
            this.jstxtUnit1.ReadOnly = true;
            this.jstxtUnit1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtUnit1.Size = new System.Drawing.Size(100, 26);
            this.jstxtUnit1.TabIndex = 13;
            this.jstxtUnit1.TabStop = false;
            this.jstxtUnit1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel21
            // 
            this.jsLabel21.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel21.AutoSize = true;
            this.jsLabel21.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel21.Location = new System.Drawing.Point(136, 33);
            this.jsLabel21.Name = "jsLabel21";
            this.jsLabel21.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel21.Size = new System.Drawing.Size(146, 22);
            this.jsLabel21.TabIndex = 4;
            this.jsLabel21.Text = "مجموع تعداد واحدهای شمارش";
            this.jsLabel21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsGbxCategoryGeneral
            // 
            this.jsGbxCategoryGeneral.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGbxCategoryGeneral.BackColor = System.Drawing.Color.Transparent;
            this.jsGbxCategoryGeneral.Controls.Add(this.jstxtCategory1);
            this.jsGbxCategoryGeneral.Controls.Add(this.jsLabel24);
            this.jsGbxCategoryGeneral.Location = new System.Drawing.Point(395, 188);
            this.jsGbxCategoryGeneral.Name = "jsGbxCategoryGeneral";
            this.jsGbxCategoryGeneral.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGbxCategoryGeneral.Size = new System.Drawing.Size(377, 86);
            this.jsGbxCategoryGeneral.TabIndex = 31;
            this.jsGbxCategoryGeneral.TabStop = false;
            this.jsGbxCategoryGeneral.Text = "آمار کلی دسته بندی ها";
            // 
            // jstxtCategory1
            // 
            this.jstxtCategory1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtCategory1.BarcodeBox = true;
            this.jstxtCategory1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtCategory1.Location = new System.Drawing.Point(30, 29);
            this.jstxtCategory1.MaxLength = 20;
            this.jstxtCategory1.Name = "jstxtCategory1";
            this.jstxtCategory1.Num16 = ((short)(0));
            this.jstxtCategory1.Num32 = 0;
            this.jstxtCategory1.Num64 = ((long)(0));
            this.jstxtCategory1.NumByte = ((byte)(0));
            this.jstxtCategory1.NumDouble = 0D;
            this.jstxtCategory1.NumericTextBox = false;
            this.jstxtCategory1.NumFloat = 0F;
            this.jstxtCategory1.PersianText = true;
            this.jstxtCategory1.ReadOnly = true;
            this.jstxtCategory1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtCategory1.Size = new System.Drawing.Size(100, 26);
            this.jstxtCategory1.TabIndex = 13;
            this.jstxtCategory1.TabStop = false;
            this.jstxtCategory1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel24
            // 
            this.jsLabel24.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel24.AutoSize = true;
            this.jsLabel24.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel24.Location = new System.Drawing.Point(136, 33);
            this.jsLabel24.Name = "jsLabel24";
            this.jsLabel24.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel24.Size = new System.Drawing.Size(163, 22);
            this.jsLabel24.TabIndex = 4;
            this.jsLabel24.Text = "مجموع تعداد دسته بندی های کالا";
            this.jsLabel24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsGbxCustomerGeneral
            // 
            this.jsGbxCustomerGeneral.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGbxCustomerGeneral.BackColor = System.Drawing.Color.Transparent;
            this.jsGbxCustomerGeneral.Controls.Add(this.jstxtCustomer4);
            this.jsGbxCustomerGeneral.Controls.Add(this.jstxtCustomer3);
            this.jsGbxCustomerGeneral.Controls.Add(this.jstxtCustomer2);
            this.jsGbxCustomerGeneral.Controls.Add(this.jstxtCustomer1);
            this.jsGbxCustomerGeneral.Controls.Add(this.jsLabel7);
            this.jsGbxCustomerGeneral.Controls.Add(this.jsLabel3);
            this.jsGbxCustomerGeneral.Controls.Add(this.jsLabel2);
            this.jsGbxCustomerGeneral.Controls.Add(this.jsLabel1);
            this.jsGbxCustomerGeneral.Location = new System.Drawing.Point(395, 6);
            this.jsGbxCustomerGeneral.Name = "jsGbxCustomerGeneral";
            this.jsGbxCustomerGeneral.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGbxCustomerGeneral.Size = new System.Drawing.Size(377, 176);
            this.jsGbxCustomerGeneral.TabIndex = 29;
            this.jsGbxCustomerGeneral.TabStop = false;
            this.jsGbxCustomerGeneral.Text = "آمار کلی مشتریان";
            // 
            // jstxtCustomer4
            // 
            this.jstxtCustomer4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtCustomer4.BarcodeBox = true;
            this.jstxtCustomer4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtCustomer4.Location = new System.Drawing.Point(30, 125);
            this.jstxtCustomer4.MaxLength = 20;
            this.jstxtCustomer4.Name = "jstxtCustomer4";
            this.jstxtCustomer4.Num16 = ((short)(0));
            this.jstxtCustomer4.Num32 = 0;
            this.jstxtCustomer4.Num64 = ((long)(0));
            this.jstxtCustomer4.NumByte = ((byte)(0));
            this.jstxtCustomer4.NumDouble = 0D;
            this.jstxtCustomer4.NumericTextBox = false;
            this.jstxtCustomer4.NumFloat = 0F;
            this.jstxtCustomer4.PersianText = true;
            this.jstxtCustomer4.ReadOnly = true;
            this.jstxtCustomer4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtCustomer4.Size = new System.Drawing.Size(100, 26);
            this.jstxtCustomer4.TabIndex = 16;
            this.jstxtCustomer4.TabStop = false;
            this.jstxtCustomer4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtCustomer3
            // 
            this.jstxtCustomer3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtCustomer3.BarcodeBox = true;
            this.jstxtCustomer3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtCustomer3.Location = new System.Drawing.Point(30, 93);
            this.jstxtCustomer3.MaxLength = 20;
            this.jstxtCustomer3.Name = "jstxtCustomer3";
            this.jstxtCustomer3.Num16 = ((short)(0));
            this.jstxtCustomer3.Num32 = 0;
            this.jstxtCustomer3.Num64 = ((long)(0));
            this.jstxtCustomer3.NumByte = ((byte)(0));
            this.jstxtCustomer3.NumDouble = 0D;
            this.jstxtCustomer3.NumericTextBox = false;
            this.jstxtCustomer3.NumFloat = 0F;
            this.jstxtCustomer3.PersianText = true;
            this.jstxtCustomer3.ReadOnly = true;
            this.jstxtCustomer3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtCustomer3.Size = new System.Drawing.Size(100, 26);
            this.jstxtCustomer3.TabIndex = 15;
            this.jstxtCustomer3.TabStop = false;
            this.jstxtCustomer3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtCustomer2
            // 
            this.jstxtCustomer2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtCustomer2.BarcodeBox = true;
            this.jstxtCustomer2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtCustomer2.Location = new System.Drawing.Point(30, 61);
            this.jstxtCustomer2.MaxLength = 20;
            this.jstxtCustomer2.Name = "jstxtCustomer2";
            this.jstxtCustomer2.Num16 = ((short)(0));
            this.jstxtCustomer2.Num32 = 0;
            this.jstxtCustomer2.Num64 = ((long)(0));
            this.jstxtCustomer2.NumByte = ((byte)(0));
            this.jstxtCustomer2.NumDouble = 0D;
            this.jstxtCustomer2.NumericTextBox = false;
            this.jstxtCustomer2.NumFloat = 0F;
            this.jstxtCustomer2.PersianText = true;
            this.jstxtCustomer2.ReadOnly = true;
            this.jstxtCustomer2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtCustomer2.Size = new System.Drawing.Size(100, 26);
            this.jstxtCustomer2.TabIndex = 14;
            this.jstxtCustomer2.TabStop = false;
            this.jstxtCustomer2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtCustomer1
            // 
            this.jstxtCustomer1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtCustomer1.BarcodeBox = true;
            this.jstxtCustomer1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtCustomer1.Location = new System.Drawing.Point(30, 29);
            this.jstxtCustomer1.MaxLength = 20;
            this.jstxtCustomer1.Name = "jstxtCustomer1";
            this.jstxtCustomer1.Num16 = ((short)(0));
            this.jstxtCustomer1.Num32 = 0;
            this.jstxtCustomer1.Num64 = ((long)(0));
            this.jstxtCustomer1.NumByte = ((byte)(0));
            this.jstxtCustomer1.NumDouble = 0D;
            this.jstxtCustomer1.NumericTextBox = false;
            this.jstxtCustomer1.NumFloat = 0F;
            this.jstxtCustomer1.PersianText = true;
            this.jstxtCustomer1.ReadOnly = true;
            this.jstxtCustomer1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtCustomer1.Size = new System.Drawing.Size(100, 26);
            this.jstxtCustomer1.TabIndex = 13;
            this.jstxtCustomer1.TabStop = false;
            this.jstxtCustomer1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel7
            // 
            this.jsLabel7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel7.AutoSize = true;
            this.jsLabel7.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel7.Location = new System.Drawing.Point(136, 129);
            this.jsLabel7.Name = "jsLabel7";
            this.jsLabel7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel7.Size = new System.Drawing.Size(196, 22);
            this.jsLabel7.TabIndex = 11;
            this.jsLabel7.Text = "تعداد مشتریانی که تاکنون خرید نداشته اند";
            this.jsLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel3
            // 
            this.jsLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel3.AutoSize = true;
            this.jsLabel3.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel3.Location = new System.Drawing.Point(136, 97);
            this.jsLabel3.Name = "jsLabel3";
            this.jsLabel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel3.Size = new System.Drawing.Size(235, 22);
            this.jsLabel3.TabIndex = 6;
            this.jsLabel3.Text = "تعداد مشتریانی که تاکنون خرید غیرنقدی داشته اند";
            this.jsLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel2
            // 
            this.jsLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel2.AutoSize = true;
            this.jsLabel2.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel2.Location = new System.Drawing.Point(136, 65);
            this.jsLabel2.Name = "jsLabel2";
            this.jsLabel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel2.Size = new System.Drawing.Size(192, 22);
            this.jsLabel2.TabIndex = 5;
            this.jsLabel2.Text = "تعداد مشتریانی که تاکنون خرید داشته اند";
            this.jsLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel1
            // 
            this.jsLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel1.AutoSize = true;
            this.jsLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel1.Location = new System.Drawing.Point(136, 33);
            this.jsLabel1.Name = "jsLabel1";
            this.jsLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel1.Size = new System.Drawing.Size(125, 22);
            this.jsLabel1.TabIndex = 4;
            this.jsLabel1.Text = "مجموع مشتریان ثبت شده";
            this.jsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabSale
            // 
            this.tabSale.Controls.Add(this.jsGbxSaleDetail);
            this.tabSale.Controls.Add(this.jsGbxSaleGeneral);
            this.tabSale.Location = new System.Drawing.Point(4, 31);
            this.tabSale.Name = "tabSale";
            this.tabSale.Padding = new System.Windows.Forms.Padding(3);
            this.tabSale.Size = new System.Drawing.Size(778, 423);
            this.tabSale.TabIndex = 5;
            this.tabSale.Text = "فروش";
            this.tabSale.UseVisualStyleBackColor = true;
            // 
            // jsGbxSaleDetail
            // 
            this.jsGbxSaleDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGbxSaleDetail.BackColor = System.Drawing.Color.Transparent;
            this.jsGbxSaleDetail.Controls.Add(this.jstxtSaleDetail4);
            this.jsGbxSaleDetail.Controls.Add(this.jsLabel36);
            this.jsGbxSaleDetail.Controls.Add(this.jstxtSaleDetail3);
            this.jsGbxSaleDetail.Controls.Add(this.jstxtSaleDetail2);
            this.jsGbxSaleDetail.Controls.Add(this.jstxtSaleDetail1);
            this.jsGbxSaleDetail.Controls.Add(this.jsLabel32);
            this.jsGbxSaleDetail.Controls.Add(this.jsLabel33);
            this.jsGbxSaleDetail.Controls.Add(this.jsLabel35);
            this.jsGbxSaleDetail.Location = new System.Drawing.Point(12, 6);
            this.jsGbxSaleDetail.Name = "jsGbxSaleDetail";
            this.jsGbxSaleDetail.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGbxSaleDetail.Size = new System.Drawing.Size(377, 270);
            this.jsGbxSaleDetail.TabIndex = 30;
            this.jsGbxSaleDetail.TabStop = false;
            this.jsGbxSaleDetail.Text = "آمار جزئیات فروش";
            // 
            // jstxtSaleDetail4
            // 
            this.jstxtSaleDetail4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtSaleDetail4.BarcodeBox = true;
            this.jstxtSaleDetail4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtSaleDetail4.Location = new System.Drawing.Point(30, 125);
            this.jstxtSaleDetail4.MaxLength = 20;
            this.jstxtSaleDetail4.Name = "jstxtSaleDetail4";
            this.jstxtSaleDetail4.Num16 = ((short)(0));
            this.jstxtSaleDetail4.Num32 = 0;
            this.jstxtSaleDetail4.Num64 = ((long)(0));
            this.jstxtSaleDetail4.NumByte = ((byte)(0));
            this.jstxtSaleDetail4.NumDouble = 0D;
            this.jstxtSaleDetail4.NumericTextBox = false;
            this.jstxtSaleDetail4.NumFloat = 0F;
            this.jstxtSaleDetail4.PersianText = true;
            this.jstxtSaleDetail4.ReadOnly = true;
            this.jstxtSaleDetail4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtSaleDetail4.Size = new System.Drawing.Size(100, 26);
            this.jstxtSaleDetail4.TabIndex = 31;
            this.jstxtSaleDetail4.TabStop = false;
            this.jstxtSaleDetail4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel36
            // 
            this.jsLabel36.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel36.AutoSize = true;
            this.jsLabel36.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel36.Location = new System.Drawing.Point(136, 129);
            this.jsLabel36.Name = "jsLabel36";
            this.jsLabel36.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel36.Size = new System.Drawing.Size(156, 22);
            this.jsLabel36.TabIndex = 30;
            this.jsLabel36.Text = "مجموع تعداد اجناس فروخته شده";
            this.jsLabel36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtSaleDetail3
            // 
            this.jstxtSaleDetail3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtSaleDetail3.BarcodeBox = true;
            this.jstxtSaleDetail3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtSaleDetail3.Location = new System.Drawing.Point(30, 93);
            this.jstxtSaleDetail3.MaxLength = 20;
            this.jstxtSaleDetail3.Name = "jstxtSaleDetail3";
            this.jstxtSaleDetail3.Num16 = ((short)(0));
            this.jstxtSaleDetail3.Num32 = 0;
            this.jstxtSaleDetail3.Num64 = ((long)(0));
            this.jstxtSaleDetail3.NumByte = ((byte)(0));
            this.jstxtSaleDetail3.NumDouble = 0D;
            this.jstxtSaleDetail3.NumericTextBox = false;
            this.jstxtSaleDetail3.NumFloat = 0F;
            this.jstxtSaleDetail3.PersianText = true;
            this.jstxtSaleDetail3.ReadOnly = true;
            this.jstxtSaleDetail3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtSaleDetail3.Size = new System.Drawing.Size(100, 26);
            this.jstxtSaleDetail3.TabIndex = 29;
            this.jstxtSaleDetail3.TabStop = false;
            this.jstxtSaleDetail3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtSaleDetail2
            // 
            this.jstxtSaleDetail2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtSaleDetail2.BarcodeBox = true;
            this.jstxtSaleDetail2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtSaleDetail2.Location = new System.Drawing.Point(30, 61);
            this.jstxtSaleDetail2.MaxLength = 20;
            this.jstxtSaleDetail2.Name = "jstxtSaleDetail2";
            this.jstxtSaleDetail2.Num16 = ((short)(0));
            this.jstxtSaleDetail2.Num32 = 0;
            this.jstxtSaleDetail2.Num64 = ((long)(0));
            this.jstxtSaleDetail2.NumByte = ((byte)(0));
            this.jstxtSaleDetail2.NumDouble = 0D;
            this.jstxtSaleDetail2.NumericTextBox = false;
            this.jstxtSaleDetail2.NumFloat = 0F;
            this.jstxtSaleDetail2.PersianText = true;
            this.jstxtSaleDetail2.ReadOnly = true;
            this.jstxtSaleDetail2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtSaleDetail2.Size = new System.Drawing.Size(100, 26);
            this.jstxtSaleDetail2.TabIndex = 28;
            this.jstxtSaleDetail2.TabStop = false;
            this.jstxtSaleDetail2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtSaleDetail1
            // 
            this.jstxtSaleDetail1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtSaleDetail1.BarcodeBox = true;
            this.jstxtSaleDetail1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtSaleDetail1.Location = new System.Drawing.Point(30, 29);
            this.jstxtSaleDetail1.MaxLength = 20;
            this.jstxtSaleDetail1.Name = "jstxtSaleDetail1";
            this.jstxtSaleDetail1.Num16 = ((short)(0));
            this.jstxtSaleDetail1.Num32 = 0;
            this.jstxtSaleDetail1.Num64 = ((long)(0));
            this.jstxtSaleDetail1.NumByte = ((byte)(0));
            this.jstxtSaleDetail1.NumDouble = 0D;
            this.jstxtSaleDetail1.NumericTextBox = false;
            this.jstxtSaleDetail1.NumFloat = 0F;
            this.jstxtSaleDetail1.PersianText = true;
            this.jstxtSaleDetail1.ReadOnly = true;
            this.jstxtSaleDetail1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtSaleDetail1.Size = new System.Drawing.Size(100, 26);
            this.jstxtSaleDetail1.TabIndex = 27;
            this.jstxtSaleDetail1.TabStop = false;
            this.jstxtSaleDetail1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel32
            // 
            this.jsLabel32.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel32.AutoSize = true;
            this.jsLabel32.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel32.Location = new System.Drawing.Point(136, 97);
            this.jsLabel32.Name = "jsLabel32";
            this.jsLabel32.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel32.Size = new System.Drawing.Size(124, 22);
            this.jsLabel32.TabIndex = 26;
            this.jsLabel32.Text = "مجموع اقلام فروخته شده";
            this.jsLabel32.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel33
            // 
            this.jsLabel33.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel33.AutoSize = true;
            this.jsLabel33.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel33.Location = new System.Drawing.Point(136, 65);
            this.jsLabel33.Name = "jsLabel33";
            this.jsLabel33.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel33.Size = new System.Drawing.Size(206, 22);
            this.jsLabel33.TabIndex = 25;
            this.jsLabel33.Text = "میانگین تعداد اجناس خریداری شده مشتریان";
            this.jsLabel33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel35
            // 
            this.jsLabel35.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel35.AutoSize = true;
            this.jsLabel35.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel35.Location = new System.Drawing.Point(136, 33);
            this.jsLabel35.Name = "jsLabel35";
            this.jsLabel35.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel35.Size = new System.Drawing.Size(199, 22);
            this.jsLabel35.TabIndex = 24;
            this.jsLabel35.Text = "میانگین تعداد اقلام خریداری شده مشتریان";
            this.jsLabel35.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsGbxSaleGeneral
            // 
            this.jsGbxSaleGeneral.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGbxSaleGeneral.BackColor = System.Drawing.Color.Transparent;
            this.jsGbxSaleGeneral.Controls.Add(this.jstxtSaleGeneral3);
            this.jsGbxSaleGeneral.Controls.Add(this.jstxtSaleGeneral2);
            this.jsGbxSaleGeneral.Controls.Add(this.jstxtSaleGeneral1);
            this.jsGbxSaleGeneral.Controls.Add(this.jsLabel27);
            this.jsGbxSaleGeneral.Controls.Add(this.jsLabel30);
            this.jsGbxSaleGeneral.Controls.Add(this.jsLabel31);
            this.jsGbxSaleGeneral.Location = new System.Drawing.Point(395, 6);
            this.jsGbxSaleGeneral.Name = "jsGbxSaleGeneral";
            this.jsGbxSaleGeneral.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGbxSaleGeneral.Size = new System.Drawing.Size(377, 150);
            this.jsGbxSaleGeneral.TabIndex = 29;
            this.jsGbxSaleGeneral.TabStop = false;
            this.jsGbxSaleGeneral.Text = "آمار کلی فروش";
            // 
            // jstxtSaleGeneral3
            // 
            this.jstxtSaleGeneral3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtSaleGeneral3.BarcodeBox = true;
            this.jstxtSaleGeneral3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtSaleGeneral3.Location = new System.Drawing.Point(30, 93);
            this.jstxtSaleGeneral3.MaxLength = 20;
            this.jstxtSaleGeneral3.Name = "jstxtSaleGeneral3";
            this.jstxtSaleGeneral3.Num16 = ((short)(0));
            this.jstxtSaleGeneral3.Num32 = 0;
            this.jstxtSaleGeneral3.Num64 = ((long)(0));
            this.jstxtSaleGeneral3.NumByte = ((byte)(0));
            this.jstxtSaleGeneral3.NumDouble = 0D;
            this.jstxtSaleGeneral3.NumericTextBox = false;
            this.jstxtSaleGeneral3.NumFloat = 0F;
            this.jstxtSaleGeneral3.PersianText = true;
            this.jstxtSaleGeneral3.ReadOnly = true;
            this.jstxtSaleGeneral3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtSaleGeneral3.Size = new System.Drawing.Size(100, 26);
            this.jstxtSaleGeneral3.TabIndex = 29;
            this.jstxtSaleGeneral3.TabStop = false;
            this.jstxtSaleGeneral3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtSaleGeneral2
            // 
            this.jstxtSaleGeneral2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtSaleGeneral2.BarcodeBox = true;
            this.jstxtSaleGeneral2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtSaleGeneral2.Location = new System.Drawing.Point(30, 61);
            this.jstxtSaleGeneral2.MaxLength = 20;
            this.jstxtSaleGeneral2.Name = "jstxtSaleGeneral2";
            this.jstxtSaleGeneral2.Num16 = ((short)(0));
            this.jstxtSaleGeneral2.Num32 = 0;
            this.jstxtSaleGeneral2.Num64 = ((long)(0));
            this.jstxtSaleGeneral2.NumByte = ((byte)(0));
            this.jstxtSaleGeneral2.NumDouble = 0D;
            this.jstxtSaleGeneral2.NumericTextBox = false;
            this.jstxtSaleGeneral2.NumFloat = 0F;
            this.jstxtSaleGeneral2.PersianText = true;
            this.jstxtSaleGeneral2.ReadOnly = true;
            this.jstxtSaleGeneral2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtSaleGeneral2.Size = new System.Drawing.Size(100, 26);
            this.jstxtSaleGeneral2.TabIndex = 28;
            this.jstxtSaleGeneral2.TabStop = false;
            this.jstxtSaleGeneral2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtSaleGeneral1
            // 
            this.jstxtSaleGeneral1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtSaleGeneral1.BarcodeBox = true;
            this.jstxtSaleGeneral1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtSaleGeneral1.Location = new System.Drawing.Point(30, 29);
            this.jstxtSaleGeneral1.MaxLength = 20;
            this.jstxtSaleGeneral1.Name = "jstxtSaleGeneral1";
            this.jstxtSaleGeneral1.Num16 = ((short)(0));
            this.jstxtSaleGeneral1.Num32 = 0;
            this.jstxtSaleGeneral1.Num64 = ((long)(0));
            this.jstxtSaleGeneral1.NumByte = ((byte)(0));
            this.jstxtSaleGeneral1.NumDouble = 0D;
            this.jstxtSaleGeneral1.NumericTextBox = false;
            this.jstxtSaleGeneral1.NumFloat = 0F;
            this.jstxtSaleGeneral1.PersianText = true;
            this.jstxtSaleGeneral1.ReadOnly = true;
            this.jstxtSaleGeneral1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtSaleGeneral1.Size = new System.Drawing.Size(100, 26);
            this.jstxtSaleGeneral1.TabIndex = 27;
            this.jstxtSaleGeneral1.TabStop = false;
            this.jstxtSaleGeneral1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel27
            // 
            this.jsLabel27.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel27.AutoSize = true;
            this.jsLabel27.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel27.Location = new System.Drawing.Point(136, 97);
            this.jsLabel27.Name = "jsLabel27";
            this.jsLabel27.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel27.Size = new System.Drawing.Size(113, 22);
            this.jsLabel27.TabIndex = 26;
            this.jsLabel27.Text = "تعداد فروش های نقدی";
            this.jsLabel27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel30
            // 
            this.jsLabel30.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel30.AutoSize = true;
            this.jsLabel30.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel30.Location = new System.Drawing.Point(136, 65);
            this.jsLabel30.Name = "jsLabel30";
            this.jsLabel30.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel30.Size = new System.Drawing.Size(122, 22);
            this.jsLabel30.TabIndex = 25;
            this.jsLabel30.Text = "تعداد فروش های اعتباری";
            this.jsLabel30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel31
            // 
            this.jsLabel31.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel31.AutoSize = true;
            this.jsLabel31.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel31.Location = new System.Drawing.Point(136, 33);
            this.jsLabel31.Name = "jsLabel31";
            this.jsLabel31.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel31.Size = new System.Drawing.Size(103, 22);
            this.jsLabel31.TabIndex = 24;
            this.jsLabel31.Text = "مجموع دفعات فروش";
            this.jsLabel31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabPurchase
            // 
            this.tabPurchase.Controls.Add(this.jsGbxPurchaseDetail);
            this.tabPurchase.Controls.Add(this.jsGbxPurchaseGeneral);
            this.tabPurchase.Location = new System.Drawing.Point(4, 31);
            this.tabPurchase.Name = "tabPurchase";
            this.tabPurchase.Padding = new System.Windows.Forms.Padding(3);
            this.tabPurchase.Size = new System.Drawing.Size(778, 423);
            this.tabPurchase.TabIndex = 4;
            this.tabPurchase.Text = "خرید";
            this.tabPurchase.UseVisualStyleBackColor = true;
            // 
            // jsGbxPurchaseDetail
            // 
            this.jsGbxPurchaseDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGbxPurchaseDetail.BackColor = System.Drawing.Color.Transparent;
            this.jsGbxPurchaseDetail.Controls.Add(this.jstxtPurchaseDetail4);
            this.jsGbxPurchaseDetail.Controls.Add(this.jsLabel42);
            this.jsGbxPurchaseDetail.Controls.Add(this.jstxtPurchaseDetail3);
            this.jsGbxPurchaseDetail.Controls.Add(this.jstxtPurchaseDetail2);
            this.jsGbxPurchaseDetail.Controls.Add(this.jstxtPurchaseDetail1);
            this.jsGbxPurchaseDetail.Controls.Add(this.jsLabel43);
            this.jsGbxPurchaseDetail.Controls.Add(this.jsLabel44);
            this.jsGbxPurchaseDetail.Controls.Add(this.jsLabel45);
            this.jsGbxPurchaseDetail.Location = new System.Drawing.Point(12, 6);
            this.jsGbxPurchaseDetail.Name = "jsGbxPurchaseDetail";
            this.jsGbxPurchaseDetail.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGbxPurchaseDetail.Size = new System.Drawing.Size(377, 270);
            this.jsGbxPurchaseDetail.TabIndex = 31;
            this.jsGbxPurchaseDetail.TabStop = false;
            this.jsGbxPurchaseDetail.Text = "آمار جزئیات خرید";
            // 
            // jstxtPurchaseDetail4
            // 
            this.jstxtPurchaseDetail4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtPurchaseDetail4.BarcodeBox = true;
            this.jstxtPurchaseDetail4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtPurchaseDetail4.Location = new System.Drawing.Point(30, 125);
            this.jstxtPurchaseDetail4.MaxLength = 20;
            this.jstxtPurchaseDetail4.Name = "jstxtPurchaseDetail4";
            this.jstxtPurchaseDetail4.Num16 = ((short)(0));
            this.jstxtPurchaseDetail4.Num32 = 0;
            this.jstxtPurchaseDetail4.Num64 = ((long)(0));
            this.jstxtPurchaseDetail4.NumByte = ((byte)(0));
            this.jstxtPurchaseDetail4.NumDouble = 0D;
            this.jstxtPurchaseDetail4.NumericTextBox = false;
            this.jstxtPurchaseDetail4.NumFloat = 0F;
            this.jstxtPurchaseDetail4.PersianText = true;
            this.jstxtPurchaseDetail4.ReadOnly = true;
            this.jstxtPurchaseDetail4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtPurchaseDetail4.Size = new System.Drawing.Size(100, 26);
            this.jstxtPurchaseDetail4.TabIndex = 31;
            this.jstxtPurchaseDetail4.TabStop = false;
            this.jstxtPurchaseDetail4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel42
            // 
            this.jsLabel42.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel42.AutoSize = true;
            this.jsLabel42.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel42.Location = new System.Drawing.Point(136, 129);
            this.jsLabel42.Name = "jsLabel42";
            this.jsLabel42.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel42.Size = new System.Drawing.Size(162, 22);
            this.jsLabel42.TabIndex = 30;
            this.jsLabel42.Text = "مجموع تعداد اجناس خریداری شده";
            this.jsLabel42.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtPurchaseDetail3
            // 
            this.jstxtPurchaseDetail3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtPurchaseDetail3.BarcodeBox = true;
            this.jstxtPurchaseDetail3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtPurchaseDetail3.Location = new System.Drawing.Point(30, 93);
            this.jstxtPurchaseDetail3.MaxLength = 20;
            this.jstxtPurchaseDetail3.Name = "jstxtPurchaseDetail3";
            this.jstxtPurchaseDetail3.Num16 = ((short)(0));
            this.jstxtPurchaseDetail3.Num32 = 0;
            this.jstxtPurchaseDetail3.Num64 = ((long)(0));
            this.jstxtPurchaseDetail3.NumByte = ((byte)(0));
            this.jstxtPurchaseDetail3.NumDouble = 0D;
            this.jstxtPurchaseDetail3.NumericTextBox = false;
            this.jstxtPurchaseDetail3.NumFloat = 0F;
            this.jstxtPurchaseDetail3.PersianText = true;
            this.jstxtPurchaseDetail3.ReadOnly = true;
            this.jstxtPurchaseDetail3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtPurchaseDetail3.Size = new System.Drawing.Size(100, 26);
            this.jstxtPurchaseDetail3.TabIndex = 29;
            this.jstxtPurchaseDetail3.TabStop = false;
            this.jstxtPurchaseDetail3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtPurchaseDetail2
            // 
            this.jstxtPurchaseDetail2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtPurchaseDetail2.BarcodeBox = true;
            this.jstxtPurchaseDetail2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtPurchaseDetail2.Location = new System.Drawing.Point(30, 61);
            this.jstxtPurchaseDetail2.MaxLength = 20;
            this.jstxtPurchaseDetail2.Name = "jstxtPurchaseDetail2";
            this.jstxtPurchaseDetail2.Num16 = ((short)(0));
            this.jstxtPurchaseDetail2.Num32 = 0;
            this.jstxtPurchaseDetail2.Num64 = ((long)(0));
            this.jstxtPurchaseDetail2.NumByte = ((byte)(0));
            this.jstxtPurchaseDetail2.NumDouble = 0D;
            this.jstxtPurchaseDetail2.NumericTextBox = false;
            this.jstxtPurchaseDetail2.NumFloat = 0F;
            this.jstxtPurchaseDetail2.PersianText = true;
            this.jstxtPurchaseDetail2.ReadOnly = true;
            this.jstxtPurchaseDetail2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtPurchaseDetail2.Size = new System.Drawing.Size(100, 26);
            this.jstxtPurchaseDetail2.TabIndex = 28;
            this.jstxtPurchaseDetail2.TabStop = false;
            this.jstxtPurchaseDetail2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtPurchaseDetail1
            // 
            this.jstxtPurchaseDetail1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtPurchaseDetail1.BarcodeBox = true;
            this.jstxtPurchaseDetail1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtPurchaseDetail1.Location = new System.Drawing.Point(30, 29);
            this.jstxtPurchaseDetail1.MaxLength = 20;
            this.jstxtPurchaseDetail1.Name = "jstxtPurchaseDetail1";
            this.jstxtPurchaseDetail1.Num16 = ((short)(0));
            this.jstxtPurchaseDetail1.Num32 = 0;
            this.jstxtPurchaseDetail1.Num64 = ((long)(0));
            this.jstxtPurchaseDetail1.NumByte = ((byte)(0));
            this.jstxtPurchaseDetail1.NumDouble = 0D;
            this.jstxtPurchaseDetail1.NumericTextBox = false;
            this.jstxtPurchaseDetail1.NumFloat = 0F;
            this.jstxtPurchaseDetail1.PersianText = true;
            this.jstxtPurchaseDetail1.ReadOnly = true;
            this.jstxtPurchaseDetail1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtPurchaseDetail1.Size = new System.Drawing.Size(100, 26);
            this.jstxtPurchaseDetail1.TabIndex = 27;
            this.jstxtPurchaseDetail1.TabStop = false;
            this.jstxtPurchaseDetail1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel43
            // 
            this.jsLabel43.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel43.AutoSize = true;
            this.jsLabel43.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel43.Location = new System.Drawing.Point(136, 97);
            this.jsLabel43.Name = "jsLabel43";
            this.jsLabel43.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel43.Size = new System.Drawing.Size(130, 22);
            this.jsLabel43.TabIndex = 26;
            this.jsLabel43.Text = "مجموع اقلام خریداری شده";
            this.jsLabel43.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel44
            // 
            this.jsLabel44.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel44.AutoSize = true;
            this.jsLabel44.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel44.Location = new System.Drawing.Point(136, 65);
            this.jsLabel44.Name = "jsLabel44";
            this.jsLabel44.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel44.Size = new System.Drawing.Size(206, 22);
            this.jsLabel44.TabIndex = 25;
            this.jsLabel44.Text = "میانگین تعداد اجناس خریداری شده فروشگاه";
            this.jsLabel44.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel45
            // 
            this.jsLabel45.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel45.AutoSize = true;
            this.jsLabel45.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel45.Location = new System.Drawing.Point(136, 33);
            this.jsLabel45.Name = "jsLabel45";
            this.jsLabel45.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel45.Size = new System.Drawing.Size(199, 22);
            this.jsLabel45.TabIndex = 24;
            this.jsLabel45.Text = "میانگین تعداد اقلام خریداری شده فروشگاه";
            this.jsLabel45.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsGbxPurchaseGeneral
            // 
            this.jsGbxPurchaseGeneral.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGbxPurchaseGeneral.BackColor = System.Drawing.Color.Transparent;
            this.jsGbxPurchaseGeneral.Controls.Add(this.jstxtPurchaseGeneral3);
            this.jsGbxPurchaseGeneral.Controls.Add(this.jstxtPurchaseGeneral2);
            this.jsGbxPurchaseGeneral.Controls.Add(this.jstxtPurchaseGeneral1);
            this.jsGbxPurchaseGeneral.Controls.Add(this.jsLabel37);
            this.jsGbxPurchaseGeneral.Controls.Add(this.jsLabel38);
            this.jsGbxPurchaseGeneral.Controls.Add(this.jsLabel39);
            this.jsGbxPurchaseGeneral.Location = new System.Drawing.Point(395, 6);
            this.jsGbxPurchaseGeneral.Name = "jsGbxPurchaseGeneral";
            this.jsGbxPurchaseGeneral.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGbxPurchaseGeneral.Size = new System.Drawing.Size(377, 150);
            this.jsGbxPurchaseGeneral.TabIndex = 30;
            this.jsGbxPurchaseGeneral.TabStop = false;
            this.jsGbxPurchaseGeneral.Text = "آمار کلی خرید";
            // 
            // jstxtPurchaseGeneral3
            // 
            this.jstxtPurchaseGeneral3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtPurchaseGeneral3.BarcodeBox = true;
            this.jstxtPurchaseGeneral3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtPurchaseGeneral3.Location = new System.Drawing.Point(30, 93);
            this.jstxtPurchaseGeneral3.MaxLength = 20;
            this.jstxtPurchaseGeneral3.Name = "jstxtPurchaseGeneral3";
            this.jstxtPurchaseGeneral3.Num16 = ((short)(0));
            this.jstxtPurchaseGeneral3.Num32 = 0;
            this.jstxtPurchaseGeneral3.Num64 = ((long)(0));
            this.jstxtPurchaseGeneral3.NumByte = ((byte)(0));
            this.jstxtPurchaseGeneral3.NumDouble = 0D;
            this.jstxtPurchaseGeneral3.NumericTextBox = false;
            this.jstxtPurchaseGeneral3.NumFloat = 0F;
            this.jstxtPurchaseGeneral3.PersianText = true;
            this.jstxtPurchaseGeneral3.ReadOnly = true;
            this.jstxtPurchaseGeneral3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtPurchaseGeneral3.Size = new System.Drawing.Size(100, 26);
            this.jstxtPurchaseGeneral3.TabIndex = 29;
            this.jstxtPurchaseGeneral3.TabStop = false;
            this.jstxtPurchaseGeneral3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtPurchaseGeneral2
            // 
            this.jstxtPurchaseGeneral2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtPurchaseGeneral2.BarcodeBox = true;
            this.jstxtPurchaseGeneral2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtPurchaseGeneral2.Location = new System.Drawing.Point(30, 61);
            this.jstxtPurchaseGeneral2.MaxLength = 20;
            this.jstxtPurchaseGeneral2.Name = "jstxtPurchaseGeneral2";
            this.jstxtPurchaseGeneral2.Num16 = ((short)(0));
            this.jstxtPurchaseGeneral2.Num32 = 0;
            this.jstxtPurchaseGeneral2.Num64 = ((long)(0));
            this.jstxtPurchaseGeneral2.NumByte = ((byte)(0));
            this.jstxtPurchaseGeneral2.NumDouble = 0D;
            this.jstxtPurchaseGeneral2.NumericTextBox = false;
            this.jstxtPurchaseGeneral2.NumFloat = 0F;
            this.jstxtPurchaseGeneral2.PersianText = true;
            this.jstxtPurchaseGeneral2.ReadOnly = true;
            this.jstxtPurchaseGeneral2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtPurchaseGeneral2.Size = new System.Drawing.Size(100, 26);
            this.jstxtPurchaseGeneral2.TabIndex = 28;
            this.jstxtPurchaseGeneral2.TabStop = false;
            this.jstxtPurchaseGeneral2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtPurchaseGeneral1
            // 
            this.jstxtPurchaseGeneral1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtPurchaseGeneral1.BarcodeBox = true;
            this.jstxtPurchaseGeneral1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtPurchaseGeneral1.Location = new System.Drawing.Point(30, 29);
            this.jstxtPurchaseGeneral1.MaxLength = 20;
            this.jstxtPurchaseGeneral1.Name = "jstxtPurchaseGeneral1";
            this.jstxtPurchaseGeneral1.Num16 = ((short)(0));
            this.jstxtPurchaseGeneral1.Num32 = 0;
            this.jstxtPurchaseGeneral1.Num64 = ((long)(0));
            this.jstxtPurchaseGeneral1.NumByte = ((byte)(0));
            this.jstxtPurchaseGeneral1.NumDouble = 0D;
            this.jstxtPurchaseGeneral1.NumericTextBox = false;
            this.jstxtPurchaseGeneral1.NumFloat = 0F;
            this.jstxtPurchaseGeneral1.PersianText = true;
            this.jstxtPurchaseGeneral1.ReadOnly = true;
            this.jstxtPurchaseGeneral1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtPurchaseGeneral1.Size = new System.Drawing.Size(100, 26);
            this.jstxtPurchaseGeneral1.TabIndex = 27;
            this.jstxtPurchaseGeneral1.TabStop = false;
            this.jstxtPurchaseGeneral1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel37
            // 
            this.jsLabel37.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel37.AutoSize = true;
            this.jsLabel37.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel37.Location = new System.Drawing.Point(136, 97);
            this.jsLabel37.Name = "jsLabel37";
            this.jsLabel37.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel37.Size = new System.Drawing.Size(103, 22);
            this.jsLabel37.TabIndex = 26;
            this.jsLabel37.Text = "تعداد خریدهای نقدی";
            this.jsLabel37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel38
            // 
            this.jsLabel38.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel38.AutoSize = true;
            this.jsLabel38.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel38.Location = new System.Drawing.Point(136, 65);
            this.jsLabel38.Name = "jsLabel38";
            this.jsLabel38.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel38.Size = new System.Drawing.Size(112, 22);
            this.jsLabel38.TabIndex = 25;
            this.jsLabel38.Text = "تعداد خریدهای اعتباری";
            this.jsLabel38.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel39
            // 
            this.jsLabel39.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel39.AutoSize = true;
            this.jsLabel39.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel39.Location = new System.Drawing.Point(136, 33);
            this.jsLabel39.Name = "jsLabel39";
            this.jsLabel39.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel39.Size = new System.Drawing.Size(97, 22);
            this.jsLabel39.TabIndex = 24;
            this.jsLabel39.Text = "مجموع دفعات خرید";
            this.jsLabel39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabProducts
            // 
            this.tabProducts.Controls.Add(this.jsGbxProductWarehouse);
            this.tabProducts.Controls.Add(this.jsGbxProductGeneral);
            this.tabProducts.Controls.Add(this.jsGbxProductBarcode);
            this.tabProducts.Location = new System.Drawing.Point(4, 31);
            this.tabProducts.Name = "tabProducts";
            this.tabProducts.Padding = new System.Windows.Forms.Padding(3);
            this.tabProducts.Size = new System.Drawing.Size(778, 423);
            this.tabProducts.TabIndex = 1;
            this.tabProducts.Text = "کالاها";
            this.tabProducts.UseVisualStyleBackColor = true;
            // 
            // jsGbxProductWarehouse
            // 
            this.jsGbxProductWarehouse.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGbxProductWarehouse.BackColor = System.Drawing.Color.Transparent;
            this.jsGbxProductWarehouse.Controls.Add(this.jstxtProductWarehouse11);
            this.jsGbxProductWarehouse.Controls.Add(this.jsLabel41);
            this.jsGbxProductWarehouse.Controls.Add(this.jstxtProductWarehouse10);
            this.jsGbxProductWarehouse.Controls.Add(this.jsLabel40);
            this.jsGbxProductWarehouse.Controls.Add(this.jstxtProductWarehouse9);
            this.jsGbxProductWarehouse.Controls.Add(this.jsLabel20);
            this.jsGbxProductWarehouse.Controls.Add(this.jstxtProductWarehouse8);
            this.jsGbxProductWarehouse.Controls.Add(this.jstxtProductWarehouse7);
            this.jsGbxProductWarehouse.Controls.Add(this.jstxtProductWarehouse6);
            this.jsGbxProductWarehouse.Controls.Add(this.jstxtProductWarehouse5);
            this.jsGbxProductWarehouse.Controls.Add(this.jstxtProductWarehouse4);
            this.jsGbxProductWarehouse.Controls.Add(this.jsLabel19);
            this.jsGbxProductWarehouse.Controls.Add(this.jsLabel18);
            this.jsGbxProductWarehouse.Controls.Add(this.jsLabel15);
            this.jsGbxProductWarehouse.Controls.Add(this.jsLabel16);
            this.jsGbxProductWarehouse.Controls.Add(this.jsLabel17);
            this.jsGbxProductWarehouse.Controls.Add(this.jstxtProductWarehouse3);
            this.jsGbxProductWarehouse.Controls.Add(this.jstxtProductWarehouse2);
            this.jsGbxProductWarehouse.Controls.Add(this.jstxtProductWarehouse1);
            this.jsGbxProductWarehouse.Controls.Add(this.jsLabel12);
            this.jsGbxProductWarehouse.Controls.Add(this.jsLabel13);
            this.jsGbxProductWarehouse.Controls.Add(this.jsLabel14);
            this.jsGbxProductWarehouse.Location = new System.Drawing.Point(12, 6);
            this.jsGbxProductWarehouse.Name = "jsGbxProductWarehouse";
            this.jsGbxProductWarehouse.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGbxProductWarehouse.Size = new System.Drawing.Size(377, 409);
            this.jsGbxProductWarehouse.TabIndex = 30;
            this.jsGbxProductWarehouse.TabStop = false;
            this.jsGbxProductWarehouse.Text = "انبار";
            // 
            // jstxtProductWarehouse11
            // 
            this.jstxtProductWarehouse11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductWarehouse11.BarcodeBox = true;
            this.jstxtProductWarehouse11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductWarehouse11.Location = new System.Drawing.Point(30, 348);
            this.jstxtProductWarehouse11.MaxLength = 20;
            this.jstxtProductWarehouse11.Name = "jstxtProductWarehouse11";
            this.jstxtProductWarehouse11.Num16 = ((short)(0));
            this.jstxtProductWarehouse11.Num32 = 0;
            this.jstxtProductWarehouse11.Num64 = ((long)(0));
            this.jstxtProductWarehouse11.NumByte = ((byte)(0));
            this.jstxtProductWarehouse11.NumDouble = 0D;
            this.jstxtProductWarehouse11.NumericTextBox = false;
            this.jstxtProductWarehouse11.NumFloat = 0F;
            this.jstxtProductWarehouse11.PersianText = true;
            this.jstxtProductWarehouse11.ReadOnly = true;
            this.jstxtProductWarehouse11.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductWarehouse11.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductWarehouse11.TabIndex = 45;
            this.jstxtProductWarehouse11.TabStop = false;
            this.jstxtProductWarehouse11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel41
            // 
            this.jsLabel41.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel41.AutoSize = true;
            this.jsLabel41.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel41.Location = new System.Drawing.Point(136, 349);
            this.jsLabel41.Name = "jsLabel41";
            this.jsLabel41.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel41.Size = new System.Drawing.Size(159, 22);
            this.jsLabel41.TabIndex = 44;
            this.jsLabel41.Text = "میانگین درصد سود بر روی کالاها";
            this.jsLabel41.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtProductWarehouse10
            // 
            this.jstxtProductWarehouse10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductWarehouse10.BarcodeBox = true;
            this.jstxtProductWarehouse10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductWarehouse10.Location = new System.Drawing.Point(30, 316);
            this.jstxtProductWarehouse10.MaxLength = 20;
            this.jstxtProductWarehouse10.Name = "jstxtProductWarehouse10";
            this.jstxtProductWarehouse10.Num16 = ((short)(0));
            this.jstxtProductWarehouse10.Num32 = 0;
            this.jstxtProductWarehouse10.Num64 = ((long)(0));
            this.jstxtProductWarehouse10.NumByte = ((byte)(0));
            this.jstxtProductWarehouse10.NumDouble = 0D;
            this.jstxtProductWarehouse10.NumericTextBox = false;
            this.jstxtProductWarehouse10.NumFloat = 0F;
            this.jstxtProductWarehouse10.PersianText = true;
            this.jstxtProductWarehouse10.ReadOnly = true;
            this.jstxtProductWarehouse10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductWarehouse10.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductWarehouse10.TabIndex = 43;
            this.jstxtProductWarehouse10.TabStop = false;
            this.jstxtProductWarehouse10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel40
            // 
            this.jsLabel40.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel40.AutoSize = true;
            this.jsLabel40.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel40.Location = new System.Drawing.Point(136, 317);
            this.jsLabel40.Name = "jsLabel40";
            this.jsLabel40.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel40.Size = new System.Drawing.Size(171, 22);
            this.jsLabel40.TabIndex = 42;
            this.jsLabel40.Text = "میانگین سود فروشگاه بر روی کالاها";
            this.jsLabel40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtProductWarehouse9
            // 
            this.jstxtProductWarehouse9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductWarehouse9.BarcodeBox = true;
            this.jstxtProductWarehouse9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductWarehouse9.Location = new System.Drawing.Point(30, 284);
            this.jstxtProductWarehouse9.MaxLength = 20;
            this.jstxtProductWarehouse9.Name = "jstxtProductWarehouse9";
            this.jstxtProductWarehouse9.Num16 = ((short)(0));
            this.jstxtProductWarehouse9.Num32 = 0;
            this.jstxtProductWarehouse9.Num64 = ((long)(0));
            this.jstxtProductWarehouse9.NumByte = ((byte)(0));
            this.jstxtProductWarehouse9.NumDouble = 0D;
            this.jstxtProductWarehouse9.NumericTextBox = false;
            this.jstxtProductWarehouse9.NumFloat = 0F;
            this.jstxtProductWarehouse9.PersianText = true;
            this.jstxtProductWarehouse9.ReadOnly = true;
            this.jstxtProductWarehouse9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductWarehouse9.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductWarehouse9.TabIndex = 41;
            this.jstxtProductWarehouse9.TabStop = false;
            this.jstxtProductWarehouse9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel20
            // 
            this.jsLabel20.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel20.AutoSize = true;
            this.jsLabel20.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel20.Location = new System.Drawing.Point(136, 285);
            this.jsLabel20.Name = "jsLabel20";
            this.jsLabel20.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel20.Size = new System.Drawing.Size(75, 22);
            this.jsLabel20.TabIndex = 40;
            this.jsLabel20.Text = "حداکثر تخفیف";
            this.jsLabel20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtProductWarehouse8
            // 
            this.jstxtProductWarehouse8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductWarehouse8.BarcodeBox = true;
            this.jstxtProductWarehouse8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductWarehouse8.Location = new System.Drawing.Point(30, 252);
            this.jstxtProductWarehouse8.MaxLength = 20;
            this.jstxtProductWarehouse8.Name = "jstxtProductWarehouse8";
            this.jstxtProductWarehouse8.Num16 = ((short)(0));
            this.jstxtProductWarehouse8.Num32 = 0;
            this.jstxtProductWarehouse8.Num64 = ((long)(0));
            this.jstxtProductWarehouse8.NumByte = ((byte)(0));
            this.jstxtProductWarehouse8.NumDouble = 0D;
            this.jstxtProductWarehouse8.NumericTextBox = false;
            this.jstxtProductWarehouse8.NumFloat = 0F;
            this.jstxtProductWarehouse8.PersianText = true;
            this.jstxtProductWarehouse8.ReadOnly = true;
            this.jstxtProductWarehouse8.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductWarehouse8.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductWarehouse8.TabIndex = 39;
            this.jstxtProductWarehouse8.TabStop = false;
            this.jstxtProductWarehouse8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtProductWarehouse7
            // 
            this.jstxtProductWarehouse7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductWarehouse7.BarcodeBox = true;
            this.jstxtProductWarehouse7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductWarehouse7.Location = new System.Drawing.Point(30, 220);
            this.jstxtProductWarehouse7.MaxLength = 20;
            this.jstxtProductWarehouse7.Name = "jstxtProductWarehouse7";
            this.jstxtProductWarehouse7.Num16 = ((short)(0));
            this.jstxtProductWarehouse7.Num32 = 0;
            this.jstxtProductWarehouse7.Num64 = ((long)(0));
            this.jstxtProductWarehouse7.NumByte = ((byte)(0));
            this.jstxtProductWarehouse7.NumDouble = 0D;
            this.jstxtProductWarehouse7.NumericTextBox = false;
            this.jstxtProductWarehouse7.NumFloat = 0F;
            this.jstxtProductWarehouse7.PersianText = true;
            this.jstxtProductWarehouse7.ReadOnly = true;
            this.jstxtProductWarehouse7.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductWarehouse7.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductWarehouse7.TabIndex = 38;
            this.jstxtProductWarehouse7.TabStop = false;
            this.jstxtProductWarehouse7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtProductWarehouse6
            // 
            this.jstxtProductWarehouse6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductWarehouse6.BarcodeBox = true;
            this.jstxtProductWarehouse6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductWarehouse6.Location = new System.Drawing.Point(30, 189);
            this.jstxtProductWarehouse6.MaxLength = 20;
            this.jstxtProductWarehouse6.Name = "jstxtProductWarehouse6";
            this.jstxtProductWarehouse6.Num16 = ((short)(0));
            this.jstxtProductWarehouse6.Num32 = 0;
            this.jstxtProductWarehouse6.Num64 = ((long)(0));
            this.jstxtProductWarehouse6.NumByte = ((byte)(0));
            this.jstxtProductWarehouse6.NumDouble = 0D;
            this.jstxtProductWarehouse6.NumericTextBox = false;
            this.jstxtProductWarehouse6.NumFloat = 0F;
            this.jstxtProductWarehouse6.PersianText = true;
            this.jstxtProductWarehouse6.ReadOnly = true;
            this.jstxtProductWarehouse6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductWarehouse6.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductWarehouse6.TabIndex = 37;
            this.jstxtProductWarehouse6.TabStop = false;
            this.jstxtProductWarehouse6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtProductWarehouse5
            // 
            this.jstxtProductWarehouse5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductWarehouse5.BarcodeBox = true;
            this.jstxtProductWarehouse5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductWarehouse5.Location = new System.Drawing.Point(30, 157);
            this.jstxtProductWarehouse5.MaxLength = 20;
            this.jstxtProductWarehouse5.Name = "jstxtProductWarehouse5";
            this.jstxtProductWarehouse5.Num16 = ((short)(0));
            this.jstxtProductWarehouse5.Num32 = 0;
            this.jstxtProductWarehouse5.Num64 = ((long)(0));
            this.jstxtProductWarehouse5.NumByte = ((byte)(0));
            this.jstxtProductWarehouse5.NumDouble = 0D;
            this.jstxtProductWarehouse5.NumericTextBox = false;
            this.jstxtProductWarehouse5.NumFloat = 0F;
            this.jstxtProductWarehouse5.PersianText = true;
            this.jstxtProductWarehouse5.ReadOnly = true;
            this.jstxtProductWarehouse5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductWarehouse5.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductWarehouse5.TabIndex = 36;
            this.jstxtProductWarehouse5.TabStop = false;
            this.jstxtProductWarehouse5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtProductWarehouse4
            // 
            this.jstxtProductWarehouse4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductWarehouse4.BarcodeBox = true;
            this.jstxtProductWarehouse4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductWarehouse4.Location = new System.Drawing.Point(30, 125);
            this.jstxtProductWarehouse4.MaxLength = 20;
            this.jstxtProductWarehouse4.Name = "jstxtProductWarehouse4";
            this.jstxtProductWarehouse4.Num16 = ((short)(0));
            this.jstxtProductWarehouse4.Num32 = 0;
            this.jstxtProductWarehouse4.Num64 = ((long)(0));
            this.jstxtProductWarehouse4.NumByte = ((byte)(0));
            this.jstxtProductWarehouse4.NumDouble = 0D;
            this.jstxtProductWarehouse4.NumericTextBox = false;
            this.jstxtProductWarehouse4.NumFloat = 0F;
            this.jstxtProductWarehouse4.PersianText = true;
            this.jstxtProductWarehouse4.ReadOnly = true;
            this.jstxtProductWarehouse4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductWarehouse4.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductWarehouse4.TabIndex = 35;
            this.jstxtProductWarehouse4.TabStop = false;
            this.jstxtProductWarehouse4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel19
            // 
            this.jsLabel19.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel19.AutoSize = true;
            this.jsLabel19.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel19.Location = new System.Drawing.Point(136, 256);
            this.jsLabel19.Name = "jsLabel19";
            this.jsLabel19.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel19.Size = new System.Drawing.Size(80, 22);
            this.jsLabel19.TabIndex = 34;
            this.jsLabel19.Text = "میانگین تخفیف";
            this.jsLabel19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel18
            // 
            this.jsLabel18.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel18.AutoSize = true;
            this.jsLabel18.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel18.Location = new System.Drawing.Point(136, 224);
            this.jsLabel18.Name = "jsLabel18";
            this.jsLabel18.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel18.Size = new System.Drawing.Size(105, 22);
            this.jsLabel18.TabIndex = 33;
            this.jsLabel18.Text = "میانگین قیمت فروش";
            this.jsLabel18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel15
            // 
            this.jsLabel15.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel15.AutoSize = true;
            this.jsLabel15.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel15.Location = new System.Drawing.Point(136, 193);
            this.jsLabel15.Name = "jsLabel15";
            this.jsLabel15.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel15.Size = new System.Drawing.Size(99, 22);
            this.jsLabel15.TabIndex = 32;
            this.jsLabel15.Text = "میانگین قیمت خرید";
            this.jsLabel15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel16
            // 
            this.jsLabel16.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel16.AutoSize = true;
            this.jsLabel16.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel16.Location = new System.Drawing.Point(136, 33);
            this.jsLabel16.Name = "jsLabel16";
            this.jsLabel16.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel16.Size = new System.Drawing.Size(142, 22);
            this.jsLabel16.TabIndex = 31;
            this.jsLabel16.Text = "میانگین تعداد کالاها در کارتن";
            this.jsLabel16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel17
            // 
            this.jsLabel17.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel17.AutoSize = true;
            this.jsLabel17.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel17.Location = new System.Drawing.Point(136, 161);
            this.jsLabel17.Name = "jsLabel17";
            this.jsLabel17.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel17.Size = new System.Drawing.Size(127, 22);
            this.jsLabel17.TabIndex = 30;
            this.jsLabel17.Text = "جمع کالاهای فروخته شده";
            this.jsLabel17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtProductWarehouse3
            // 
            this.jstxtProductWarehouse3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductWarehouse3.BarcodeBox = true;
            this.jstxtProductWarehouse3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductWarehouse3.Location = new System.Drawing.Point(30, 93);
            this.jstxtProductWarehouse3.MaxLength = 20;
            this.jstxtProductWarehouse3.Name = "jstxtProductWarehouse3";
            this.jstxtProductWarehouse3.Num16 = ((short)(0));
            this.jstxtProductWarehouse3.Num32 = 0;
            this.jstxtProductWarehouse3.Num64 = ((long)(0));
            this.jstxtProductWarehouse3.NumByte = ((byte)(0));
            this.jstxtProductWarehouse3.NumDouble = 0D;
            this.jstxtProductWarehouse3.NumericTextBox = false;
            this.jstxtProductWarehouse3.NumFloat = 0F;
            this.jstxtProductWarehouse3.PersianText = true;
            this.jstxtProductWarehouse3.ReadOnly = true;
            this.jstxtProductWarehouse3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductWarehouse3.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductWarehouse3.TabIndex = 29;
            this.jstxtProductWarehouse3.TabStop = false;
            this.jstxtProductWarehouse3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtProductWarehouse2
            // 
            this.jstxtProductWarehouse2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductWarehouse2.BarcodeBox = true;
            this.jstxtProductWarehouse2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductWarehouse2.Location = new System.Drawing.Point(30, 61);
            this.jstxtProductWarehouse2.MaxLength = 20;
            this.jstxtProductWarehouse2.Name = "jstxtProductWarehouse2";
            this.jstxtProductWarehouse2.Num16 = ((short)(0));
            this.jstxtProductWarehouse2.Num32 = 0;
            this.jstxtProductWarehouse2.Num64 = ((long)(0));
            this.jstxtProductWarehouse2.NumByte = ((byte)(0));
            this.jstxtProductWarehouse2.NumDouble = 0D;
            this.jstxtProductWarehouse2.NumericTextBox = false;
            this.jstxtProductWarehouse2.NumFloat = 0F;
            this.jstxtProductWarehouse2.PersianText = true;
            this.jstxtProductWarehouse2.ReadOnly = true;
            this.jstxtProductWarehouse2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductWarehouse2.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductWarehouse2.TabIndex = 28;
            this.jstxtProductWarehouse2.TabStop = false;
            this.jstxtProductWarehouse2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtProductWarehouse1
            // 
            this.jstxtProductWarehouse1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductWarehouse1.BarcodeBox = true;
            this.jstxtProductWarehouse1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductWarehouse1.Location = new System.Drawing.Point(30, 29);
            this.jstxtProductWarehouse1.MaxLength = 20;
            this.jstxtProductWarehouse1.Name = "jstxtProductWarehouse1";
            this.jstxtProductWarehouse1.Num16 = ((short)(0));
            this.jstxtProductWarehouse1.Num32 = 0;
            this.jstxtProductWarehouse1.Num64 = ((long)(0));
            this.jstxtProductWarehouse1.NumByte = ((byte)(0));
            this.jstxtProductWarehouse1.NumDouble = 0D;
            this.jstxtProductWarehouse1.NumericTextBox = false;
            this.jstxtProductWarehouse1.NumFloat = 0F;
            this.jstxtProductWarehouse1.PersianText = true;
            this.jstxtProductWarehouse1.ReadOnly = true;
            this.jstxtProductWarehouse1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductWarehouse1.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductWarehouse1.TabIndex = 27;
            this.jstxtProductWarehouse1.TabStop = false;
            this.jstxtProductWarehouse1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel12
            // 
            this.jsLabel12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel12.AutoSize = true;
            this.jsLabel12.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel12.Location = new System.Drawing.Point(136, 129);
            this.jsLabel12.Name = "jsLabel12";
            this.jsLabel12.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel12.Size = new System.Drawing.Size(91, 22);
            this.jsLabel12.TabIndex = 26;
            this.jsLabel12.Text = "جمع موجودی انبار";
            this.jsLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel13
            // 
            this.jsLabel13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel13.AutoSize = true;
            this.jsLabel13.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel13.Location = new System.Drawing.Point(135, 97);
            this.jsLabel13.Name = "jsLabel13";
            this.jsLabel13.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel13.Size = new System.Drawing.Size(106, 22);
            this.jsLabel13.TabIndex = 25;
            this.jsLabel13.Text = "میانگین موجودی انبار";
            this.jsLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel14
            // 
            this.jsLabel14.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel14.AutoSize = true;
            this.jsLabel14.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel14.Location = new System.Drawing.Point(136, 65);
            this.jsLabel14.Name = "jsLabel14";
            this.jsLabel14.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel14.Size = new System.Drawing.Size(118, 22);
            this.jsLabel14.TabIndex = 24;
            this.jsLabel14.Text = "میانگین حداقل موجودی";
            this.jsLabel14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsGbxProductGeneral
            // 
            this.jsGbxProductGeneral.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGbxProductGeneral.BackColor = System.Drawing.Color.Transparent;
            this.jsGbxProductGeneral.Controls.Add(this.jstxtProduct3);
            this.jsGbxProductGeneral.Controls.Add(this.jstxtProduct2);
            this.jsGbxProductGeneral.Controls.Add(this.jstxtProduct1);
            this.jsGbxProductGeneral.Controls.Add(this.jsLabel5);
            this.jsGbxProductGeneral.Controls.Add(this.jsLabel6);
            this.jsGbxProductGeneral.Controls.Add(this.jsLabel8);
            this.jsGbxProductGeneral.Location = new System.Drawing.Point(395, 6);
            this.jsGbxProductGeneral.Name = "jsGbxProductGeneral";
            this.jsGbxProductGeneral.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGbxProductGeneral.Size = new System.Drawing.Size(377, 150);
            this.jsGbxProductGeneral.TabIndex = 28;
            this.jsGbxProductGeneral.TabStop = false;
            this.jsGbxProductGeneral.Text = "آمار کلی کالاها";
            // 
            // jstxtProduct3
            // 
            this.jstxtProduct3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProduct3.BarcodeBox = true;
            this.jstxtProduct3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProduct3.Location = new System.Drawing.Point(30, 93);
            this.jstxtProduct3.MaxLength = 20;
            this.jstxtProduct3.Name = "jstxtProduct3";
            this.jstxtProduct3.Num16 = ((short)(0));
            this.jstxtProduct3.Num32 = 0;
            this.jstxtProduct3.Num64 = ((long)(0));
            this.jstxtProduct3.NumByte = ((byte)(0));
            this.jstxtProduct3.NumDouble = 0D;
            this.jstxtProduct3.NumericTextBox = false;
            this.jstxtProduct3.NumFloat = 0F;
            this.jstxtProduct3.PersianText = true;
            this.jstxtProduct3.ReadOnly = true;
            this.jstxtProduct3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProduct3.Size = new System.Drawing.Size(100, 26);
            this.jstxtProduct3.TabIndex = 29;
            this.jstxtProduct3.TabStop = false;
            this.jstxtProduct3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtProduct2
            // 
            this.jstxtProduct2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProduct2.BarcodeBox = true;
            this.jstxtProduct2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProduct2.Location = new System.Drawing.Point(30, 61);
            this.jstxtProduct2.MaxLength = 20;
            this.jstxtProduct2.Name = "jstxtProduct2";
            this.jstxtProduct2.Num16 = ((short)(0));
            this.jstxtProduct2.Num32 = 0;
            this.jstxtProduct2.Num64 = ((long)(0));
            this.jstxtProduct2.NumByte = ((byte)(0));
            this.jstxtProduct2.NumDouble = 0D;
            this.jstxtProduct2.NumericTextBox = false;
            this.jstxtProduct2.NumFloat = 0F;
            this.jstxtProduct2.PersianText = true;
            this.jstxtProduct2.ReadOnly = true;
            this.jstxtProduct2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProduct2.Size = new System.Drawing.Size(100, 26);
            this.jstxtProduct2.TabIndex = 28;
            this.jstxtProduct2.TabStop = false;
            this.jstxtProduct2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtProduct1
            // 
            this.jstxtProduct1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProduct1.BarcodeBox = true;
            this.jstxtProduct1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProduct1.Location = new System.Drawing.Point(30, 29);
            this.jstxtProduct1.MaxLength = 20;
            this.jstxtProduct1.Name = "jstxtProduct1";
            this.jstxtProduct1.Num16 = ((short)(0));
            this.jstxtProduct1.Num32 = 0;
            this.jstxtProduct1.Num64 = ((long)(0));
            this.jstxtProduct1.NumByte = ((byte)(0));
            this.jstxtProduct1.NumDouble = 0D;
            this.jstxtProduct1.NumericTextBox = false;
            this.jstxtProduct1.NumFloat = 0F;
            this.jstxtProduct1.PersianText = true;
            this.jstxtProduct1.ReadOnly = true;
            this.jstxtProduct1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProduct1.Size = new System.Drawing.Size(100, 26);
            this.jstxtProduct1.TabIndex = 27;
            this.jstxtProduct1.TabStop = false;
            this.jstxtProduct1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel5
            // 
            this.jsLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel5.AutoSize = true;
            this.jsLabel5.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel5.Location = new System.Drawing.Point(136, 97);
            this.jsLabel5.Name = "jsLabel5";
            this.jsLabel5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel5.Size = new System.Drawing.Size(167, 22);
            this.jsLabel5.TabIndex = 26;
            this.jsLabel5.Text = "تعداد کالاهایی که هنوز نفروخته ایم";
            this.jsLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel6
            // 
            this.jsLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel6.AutoSize = true;
            this.jsLabel6.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel6.Location = new System.Drawing.Point(136, 65);
            this.jsLabel6.Name = "jsLabel6";
            this.jsLabel6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel6.Size = new System.Drawing.Size(190, 22);
            this.jsLabel6.TabIndex = 25;
            this.jsLabel6.Text = "تعداد کالاهایی که تاکنون فروش رفته اند";
            this.jsLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel8
            // 
            this.jsLabel8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel8.AutoSize = true;
            this.jsLabel8.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel8.Location = new System.Drawing.Point(136, 33);
            this.jsLabel8.Name = "jsLabel8";
            this.jsLabel8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel8.Size = new System.Drawing.Size(125, 22);
            this.jsLabel8.TabIndex = 24;
            this.jsLabel8.Text = "مجموع کالاهای ثبت شده";
            this.jsLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsGbxProductBarcode
            // 
            this.jsGbxProductBarcode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGbxProductBarcode.BackColor = System.Drawing.Color.Transparent;
            this.jsGbxProductBarcode.Controls.Add(this.jstxtProductBarcode4);
            this.jsGbxProductBarcode.Controls.Add(this.jsLabel11);
            this.jsGbxProductBarcode.Controls.Add(this.jstxtProductBarcode2);
            this.jsGbxProductBarcode.Controls.Add(this.jstxtProductBarcode3);
            this.jsGbxProductBarcode.Controls.Add(this.jstxtProductBarcode1);
            this.jsGbxProductBarcode.Controls.Add(this.jsLabel10);
            this.jsGbxProductBarcode.Controls.Add(this.jsLabel4);
            this.jsGbxProductBarcode.Controls.Add(this.jsLabel9);
            this.jsGbxProductBarcode.Location = new System.Drawing.Point(395, 162);
            this.jsGbxProductBarcode.Name = "jsGbxProductBarcode";
            this.jsGbxProductBarcode.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGbxProductBarcode.Size = new System.Drawing.Size(377, 179);
            this.jsGbxProductBarcode.TabIndex = 27;
            this.jsGbxProductBarcode.TabStop = false;
            this.jsGbxProductBarcode.Text = "بارکد";
            // 
            // jstxtProductBarcode4
            // 
            this.jstxtProductBarcode4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductBarcode4.BarcodeBox = true;
            this.jstxtProductBarcode4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductBarcode4.Location = new System.Drawing.Point(30, 125);
            this.jstxtProductBarcode4.MaxLength = 20;
            this.jstxtProductBarcode4.Name = "jstxtProductBarcode4";
            this.jstxtProductBarcode4.Num16 = ((short)(0));
            this.jstxtProductBarcode4.Num32 = 0;
            this.jstxtProductBarcode4.Num64 = ((long)(0));
            this.jstxtProductBarcode4.NumByte = ((byte)(0));
            this.jstxtProductBarcode4.NumDouble = 0D;
            this.jstxtProductBarcode4.NumericTextBox = false;
            this.jstxtProductBarcode4.NumFloat = 0F;
            this.jstxtProductBarcode4.PersianText = true;
            this.jstxtProductBarcode4.ReadOnly = true;
            this.jstxtProductBarcode4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductBarcode4.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductBarcode4.TabIndex = 30;
            this.jstxtProductBarcode4.TabStop = false;
            this.jstxtProductBarcode4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel11
            // 
            this.jsLabel11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel11.AutoSize = true;
            this.jsLabel11.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel11.Location = new System.Drawing.Point(136, 129);
            this.jsLabel11.Name = "jsLabel11";
            this.jsLabel11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel11.Size = new System.Drawing.Size(147, 22);
            this.jsLabel11.TabIndex = 29;
            this.jsLabel11.Text = "تعداد کالاهای بدون ایران بارکد";
            this.jsLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtProductBarcode2
            // 
            this.jstxtProductBarcode2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductBarcode2.BarcodeBox = true;
            this.jstxtProductBarcode2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductBarcode2.Location = new System.Drawing.Point(30, 61);
            this.jstxtProductBarcode2.MaxLength = 20;
            this.jstxtProductBarcode2.Name = "jstxtProductBarcode2";
            this.jstxtProductBarcode2.Num16 = ((short)(0));
            this.jstxtProductBarcode2.Num32 = 0;
            this.jstxtProductBarcode2.Num64 = ((long)(0));
            this.jstxtProductBarcode2.NumByte = ((byte)(0));
            this.jstxtProductBarcode2.NumDouble = 0D;
            this.jstxtProductBarcode2.NumericTextBox = false;
            this.jstxtProductBarcode2.NumFloat = 0F;
            this.jstxtProductBarcode2.PersianText = true;
            this.jstxtProductBarcode2.ReadOnly = true;
            this.jstxtProductBarcode2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductBarcode2.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductBarcode2.TabIndex = 28;
            this.jstxtProductBarcode2.TabStop = false;
            this.jstxtProductBarcode2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtProductBarcode3
            // 
            this.jstxtProductBarcode3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductBarcode3.BarcodeBox = true;
            this.jstxtProductBarcode3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductBarcode3.Location = new System.Drawing.Point(30, 93);
            this.jstxtProductBarcode3.MaxLength = 20;
            this.jstxtProductBarcode3.Name = "jstxtProductBarcode3";
            this.jstxtProductBarcode3.Num16 = ((short)(0));
            this.jstxtProductBarcode3.Num32 = 0;
            this.jstxtProductBarcode3.Num64 = ((long)(0));
            this.jstxtProductBarcode3.NumByte = ((byte)(0));
            this.jstxtProductBarcode3.NumDouble = 0D;
            this.jstxtProductBarcode3.NumericTextBox = false;
            this.jstxtProductBarcode3.NumFloat = 0F;
            this.jstxtProductBarcode3.PersianText = true;
            this.jstxtProductBarcode3.ReadOnly = true;
            this.jstxtProductBarcode3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductBarcode3.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductBarcode3.TabIndex = 27;
            this.jstxtProductBarcode3.TabStop = false;
            this.jstxtProductBarcode3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtProductBarcode1
            // 
            this.jstxtProductBarcode1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtProductBarcode1.BarcodeBox = true;
            this.jstxtProductBarcode1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtProductBarcode1.Location = new System.Drawing.Point(30, 29);
            this.jstxtProductBarcode1.MaxLength = 20;
            this.jstxtProductBarcode1.Name = "jstxtProductBarcode1";
            this.jstxtProductBarcode1.Num16 = ((short)(0));
            this.jstxtProductBarcode1.Num32 = 0;
            this.jstxtProductBarcode1.Num64 = ((long)(0));
            this.jstxtProductBarcode1.NumByte = ((byte)(0));
            this.jstxtProductBarcode1.NumDouble = 0D;
            this.jstxtProductBarcode1.NumericTextBox = false;
            this.jstxtProductBarcode1.NumFloat = 0F;
            this.jstxtProductBarcode1.PersianText = true;
            this.jstxtProductBarcode1.ReadOnly = true;
            this.jstxtProductBarcode1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtProductBarcode1.Size = new System.Drawing.Size(100, 26);
            this.jstxtProductBarcode1.TabIndex = 24;
            this.jstxtProductBarcode1.TabStop = false;
            this.jstxtProductBarcode1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel10
            // 
            this.jsLabel10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel10.AutoSize = true;
            this.jsLabel10.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel10.Location = new System.Drawing.Point(136, 65);
            this.jsLabel10.Name = "jsLabel10";
            this.jsLabel10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel10.Size = new System.Drawing.Size(123, 22);
            this.jsLabel10.TabIndex = 26;
            this.jsLabel10.Text = "تعداد کالاهای بدون بارکد";
            this.jsLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel4
            // 
            this.jsLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel4.AutoSize = true;
            this.jsLabel4.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel4.Location = new System.Drawing.Point(136, 33);
            this.jsLabel4.Name = "jsLabel4";
            this.jsLabel4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel4.Size = new System.Drawing.Size(124, 22);
            this.jsLabel4.TabIndex = 20;
            this.jsLabel4.Text = "تعداد کالاهای دارای بارکد";
            this.jsLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel9
            // 
            this.jsLabel9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel9.AutoSize = true;
            this.jsLabel9.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel9.Location = new System.Drawing.Point(136, 97);
            this.jsLabel9.Name = "jsLabel9";
            this.jsLabel9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel9.Size = new System.Drawing.Size(146, 22);
            this.jsLabel9.TabIndex = 25;
            this.jsLabel9.Text = "تعداد کالاهای داری ایران بارکد";
            this.jsLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabUser
            // 
            this.tabUser.Controls.Add(this.jsGbxUserGeneral);
            this.tabUser.Location = new System.Drawing.Point(4, 31);
            this.tabUser.Name = "tabUser";
            this.tabUser.Padding = new System.Windows.Forms.Padding(3);
            this.tabUser.Size = new System.Drawing.Size(778, 423);
            this.tabUser.TabIndex = 7;
            this.tabUser.Text = "کاربران";
            this.tabUser.UseVisualStyleBackColor = true;
            // 
            // jsGbxUserGeneral
            // 
            this.jsGbxUserGeneral.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGbxUserGeneral.BackColor = System.Drawing.Color.Transparent;
            this.jsGbxUserGeneral.Controls.Add(this.jstxtUser6);
            this.jsGbxUserGeneral.Controls.Add(this.jstxtUser5);
            this.jsGbxUserGeneral.Controls.Add(this.jsLabel28);
            this.jsGbxUserGeneral.Controls.Add(this.jsLabel29);
            this.jsGbxUserGeneral.Controls.Add(this.jstxtUser4);
            this.jsGbxUserGeneral.Controls.Add(this.jstxtUser3);
            this.jsGbxUserGeneral.Controls.Add(this.jstxtUser2);
            this.jsGbxUserGeneral.Controls.Add(this.jstxtUser1);
            this.jsGbxUserGeneral.Controls.Add(this.jsLabel22);
            this.jsGbxUserGeneral.Controls.Add(this.jsLabel23);
            this.jsGbxUserGeneral.Controls.Add(this.jsLabel25);
            this.jsGbxUserGeneral.Controls.Add(this.jsLabel26);
            this.jsGbxUserGeneral.Location = new System.Drawing.Point(395, 6);
            this.jsGbxUserGeneral.Name = "jsGbxUserGeneral";
            this.jsGbxUserGeneral.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGbxUserGeneral.Size = new System.Drawing.Size(377, 237);
            this.jsGbxUserGeneral.TabIndex = 30;
            this.jsGbxUserGeneral.TabStop = false;
            this.jsGbxUserGeneral.Text = "آمار کلی کاربران";
            // 
            // jstxtUser6
            // 
            this.jstxtUser6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtUser6.BarcodeBox = true;
            this.jstxtUser6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtUser6.Location = new System.Drawing.Point(30, 189);
            this.jstxtUser6.MaxLength = 20;
            this.jstxtUser6.Name = "jstxtUser6";
            this.jstxtUser6.Num16 = ((short)(0));
            this.jstxtUser6.Num32 = 0;
            this.jstxtUser6.Num64 = ((long)(0));
            this.jstxtUser6.NumByte = ((byte)(0));
            this.jstxtUser6.NumDouble = 0D;
            this.jstxtUser6.NumericTextBox = false;
            this.jstxtUser6.NumFloat = 0F;
            this.jstxtUser6.PersianText = true;
            this.jstxtUser6.ReadOnly = true;
            this.jstxtUser6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtUser6.Size = new System.Drawing.Size(100, 26);
            this.jstxtUser6.TabIndex = 21;
            this.jstxtUser6.TabStop = false;
            this.jstxtUser6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtUser5
            // 
            this.jstxtUser5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtUser5.BarcodeBox = true;
            this.jstxtUser5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtUser5.Location = new System.Drawing.Point(30, 157);
            this.jstxtUser5.MaxLength = 20;
            this.jstxtUser5.Name = "jstxtUser5";
            this.jstxtUser5.Num16 = ((short)(0));
            this.jstxtUser5.Num32 = 0;
            this.jstxtUser5.Num64 = ((long)(0));
            this.jstxtUser5.NumByte = ((byte)(0));
            this.jstxtUser5.NumDouble = 0D;
            this.jstxtUser5.NumericTextBox = false;
            this.jstxtUser5.NumFloat = 0F;
            this.jstxtUser5.PersianText = true;
            this.jstxtUser5.ReadOnly = true;
            this.jstxtUser5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtUser5.Size = new System.Drawing.Size(100, 26);
            this.jstxtUser5.TabIndex = 20;
            this.jstxtUser5.TabStop = false;
            this.jstxtUser5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel28
            // 
            this.jsLabel28.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel28.AutoSize = true;
            this.jsLabel28.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel28.Location = new System.Drawing.Point(136, 193);
            this.jsLabel28.Name = "jsLabel28";
            this.jsLabel28.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel28.Size = new System.Drawing.Size(193, 22);
            this.jsLabel28.TabIndex = 18;
            this.jsLabel28.Text = "تعداد کاربرانی که تاکنون فروش داشته اند";
            this.jsLabel28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel29
            // 
            this.jsLabel29.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel29.AutoSize = true;
            this.jsLabel29.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel29.Location = new System.Drawing.Point(136, 161);
            this.jsLabel29.Name = "jsLabel29";
            this.jsLabel29.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel29.Size = new System.Drawing.Size(105, 22);
            this.jsLabel29.TabIndex = 17;
            this.jsLabel29.Text = "بیشترین میزان فروش";
            this.jsLabel29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtUser4
            // 
            this.jstxtUser4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtUser4.BarcodeBox = true;
            this.jstxtUser4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtUser4.Location = new System.Drawing.Point(30, 125);
            this.jstxtUser4.MaxLength = 20;
            this.jstxtUser4.Name = "jstxtUser4";
            this.jstxtUser4.Num16 = ((short)(0));
            this.jstxtUser4.Num32 = 0;
            this.jstxtUser4.Num64 = ((long)(0));
            this.jstxtUser4.NumByte = ((byte)(0));
            this.jstxtUser4.NumDouble = 0D;
            this.jstxtUser4.NumericTextBox = false;
            this.jstxtUser4.NumFloat = 0F;
            this.jstxtUser4.PersianText = true;
            this.jstxtUser4.ReadOnly = true;
            this.jstxtUser4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtUser4.Size = new System.Drawing.Size(100, 26);
            this.jstxtUser4.TabIndex = 16;
            this.jstxtUser4.TabStop = false;
            this.jstxtUser4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtUser3
            // 
            this.jstxtUser3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtUser3.BarcodeBox = true;
            this.jstxtUser3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtUser3.Location = new System.Drawing.Point(30, 93);
            this.jstxtUser3.MaxLength = 20;
            this.jstxtUser3.Name = "jstxtUser3";
            this.jstxtUser3.Num16 = ((short)(0));
            this.jstxtUser3.Num32 = 0;
            this.jstxtUser3.Num64 = ((long)(0));
            this.jstxtUser3.NumByte = ((byte)(0));
            this.jstxtUser3.NumDouble = 0D;
            this.jstxtUser3.NumericTextBox = false;
            this.jstxtUser3.NumFloat = 0F;
            this.jstxtUser3.PersianText = true;
            this.jstxtUser3.ReadOnly = true;
            this.jstxtUser3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtUser3.Size = new System.Drawing.Size(100, 26);
            this.jstxtUser3.TabIndex = 15;
            this.jstxtUser3.TabStop = false;
            this.jstxtUser3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtUser2
            // 
            this.jstxtUser2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtUser2.BarcodeBox = true;
            this.jstxtUser2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtUser2.Location = new System.Drawing.Point(30, 61);
            this.jstxtUser2.MaxLength = 20;
            this.jstxtUser2.Name = "jstxtUser2";
            this.jstxtUser2.Num16 = ((short)(0));
            this.jstxtUser2.Num32 = 0;
            this.jstxtUser2.Num64 = ((long)(0));
            this.jstxtUser2.NumByte = ((byte)(0));
            this.jstxtUser2.NumDouble = 0D;
            this.jstxtUser2.NumericTextBox = false;
            this.jstxtUser2.NumFloat = 0F;
            this.jstxtUser2.PersianText = true;
            this.jstxtUser2.ReadOnly = true;
            this.jstxtUser2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtUser2.Size = new System.Drawing.Size(100, 26);
            this.jstxtUser2.TabIndex = 14;
            this.jstxtUser2.TabStop = false;
            this.jstxtUser2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtUser1
            // 
            this.jstxtUser1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtUser1.BarcodeBox = true;
            this.jstxtUser1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtUser1.Location = new System.Drawing.Point(30, 29);
            this.jstxtUser1.MaxLength = 20;
            this.jstxtUser1.Name = "jstxtUser1";
            this.jstxtUser1.Num16 = ((short)(0));
            this.jstxtUser1.Num32 = 0;
            this.jstxtUser1.Num64 = ((long)(0));
            this.jstxtUser1.NumByte = ((byte)(0));
            this.jstxtUser1.NumDouble = 0D;
            this.jstxtUser1.NumericTextBox = false;
            this.jstxtUser1.NumFloat = 0F;
            this.jstxtUser1.PersianText = true;
            this.jstxtUser1.ReadOnly = true;
            this.jstxtUser1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtUser1.Size = new System.Drawing.Size(100, 26);
            this.jstxtUser1.TabIndex = 13;
            this.jstxtUser1.TabStop = false;
            this.jstxtUser1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel22
            // 
            this.jsLabel22.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel22.AutoSize = true;
            this.jsLabel22.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel22.Location = new System.Drawing.Point(136, 129);
            this.jsLabel22.Name = "jsLabel22";
            this.jsLabel22.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel22.Size = new System.Drawing.Size(111, 22);
            this.jsLabel22.TabIndex = 11;
            this.jsLabel22.Text = "میانگین فروش کاربران";
            this.jsLabel22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel23
            // 
            this.jsLabel23.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel23.AutoSize = true;
            this.jsLabel23.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel23.Location = new System.Drawing.Point(136, 97);
            this.jsLabel23.Name = "jsLabel23";
            this.jsLabel23.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel23.Size = new System.Drawing.Size(54, 22);
            this.jsLabel23.TabIndex = 6;
            this.jsLabel23.Text = "تعداد مدیر";
            this.jsLabel23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel25
            // 
            this.jsLabel25.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel25.AutoSize = true;
            this.jsLabel25.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel25.Location = new System.Drawing.Point(136, 65);
            this.jsLabel25.Name = "jsLabel25";
            this.jsLabel25.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel25.Size = new System.Drawing.Size(90, 22);
            this.jsLabel25.TabIndex = 5;
            this.jsLabel25.Text = "تعداد کاربران فعال";
            this.jsLabel25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel26
            // 
            this.jsLabel26.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel26.AutoSize = true;
            this.jsLabel26.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel26.Location = new System.Drawing.Point(136, 33);
            this.jsLabel26.Name = "jsLabel26";
            this.jsLabel26.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel26.Size = new System.Drawing.Size(135, 22);
            this.jsLabel26.TabIndex = 4;
            this.jsLabel26.Text = "مجموع تعداد کاربران سیستم";
            this.jsLabel26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // FrmStatistics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(861, 458);
            this.Controls.Add(this.StatisticsTab);
            this.FormTitle = "خلاصه آمار";
            this.Name = "FrmStatistics";
            this.Text = "سامانه مدیریت فروشگاه | خلاصه آمار";
            this.Load += new System.EventHandler(this.FrmStatisticsLoad);
            this.Controls.SetChildIndex(this.StatisticsTab, 0);
            this.StatisticsTab.ResumeLayout(false);
            this.tabCustomers.ResumeLayout(false);
            this.jsGbxSupplierGeneral.ResumeLayout(false);
            this.jsGbxSupplierGeneral.PerformLayout();
            this.jsGbxUnitGeneral.ResumeLayout(false);
            this.jsGbxUnitGeneral.PerformLayout();
            this.jsGbxCategoryGeneral.ResumeLayout(false);
            this.jsGbxCategoryGeneral.PerformLayout();
            this.jsGbxCustomerGeneral.ResumeLayout(false);
            this.jsGbxCustomerGeneral.PerformLayout();
            this.tabSale.ResumeLayout(false);
            this.jsGbxSaleDetail.ResumeLayout(false);
            this.jsGbxSaleDetail.PerformLayout();
            this.jsGbxSaleGeneral.ResumeLayout(false);
            this.jsGbxSaleGeneral.PerformLayout();
            this.tabPurchase.ResumeLayout(false);
            this.jsGbxPurchaseDetail.ResumeLayout(false);
            this.jsGbxPurchaseDetail.PerformLayout();
            this.jsGbxPurchaseGeneral.ResumeLayout(false);
            this.jsGbxPurchaseGeneral.PerformLayout();
            this.tabProducts.ResumeLayout(false);
            this.jsGbxProductWarehouse.ResumeLayout(false);
            this.jsGbxProductWarehouse.PerformLayout();
            this.jsGbxProductGeneral.ResumeLayout(false);
            this.jsGbxProductGeneral.PerformLayout();
            this.jsGbxProductBarcode.ResumeLayout(false);
            this.jsGbxProductBarcode.PerformLayout();
            this.tabUser.ResumeLayout(false);
            this.jsGbxUserGeneral.ResumeLayout(false);
            this.jsGbxUserGeneral.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl StatisticsTab;
        private System.Windows.Forms.TabPage tabCustomers;
        private System.Windows.Forms.TabPage tabProducts;
        private JSRequirement.Controls.JSLabel jsLabel2;
        private JSRequirement.Controls.JSLabel jsLabel1;
        private JSRequirement.Controls.JSLabel jsLabel3;
        private JSRequirement.Controls.JSLabel jsLabel7;
        private JSRequirement.Controls.JSTextBox jstxtCustomer4;
        private JSRequirement.Controls.JSTextBox jstxtCustomer3;
        private JSRequirement.Controls.JSTextBox jstxtCustomer2;
        private JSRequirement.Controls.JSTextBox jstxtCustomer1;
        private JSRequirement.Controls.JSTextBox jstxtProductBarcode1;
        private JSRequirement.Controls.JSLabel jsLabel4;
        private JSRequirement.Controls.JSLabel jsLabel9;
        private JSRequirement.Controls.JSLabel jsLabel10;
        private JSRequirement.Controls.JSGroupBox jsGbxProductBarcode;
        private JSRequirement.Controls.JSTextBox jstxtProductBarcode4;
        private JSRequirement.Controls.JSLabel jsLabel11;
        private JSRequirement.Controls.JSTextBox jstxtProductBarcode3;
        private JSRequirement.Controls.JSGroupBox jsGbxProductGeneral;
        private JSRequirement.Controls.JSTextBox jstxtProduct3;
        private JSRequirement.Controls.JSTextBox jstxtProduct2;
        private JSRequirement.Controls.JSTextBox jstxtProduct1;
        private JSRequirement.Controls.JSLabel jsLabel5;
        private JSRequirement.Controls.JSLabel jsLabel6;
        private JSRequirement.Controls.JSLabel jsLabel8;
        private JSRequirement.Controls.JSGroupBox jsGbxCustomerGeneral;
        private JSRequirement.Controls.JSGroupBox jsGbxProductWarehouse;
        private JSRequirement.Controls.JSTextBox jstxtProductWarehouse3;
        private JSRequirement.Controls.JSTextBox jstxtProductWarehouse2;
        private JSRequirement.Controls.JSTextBox jstxtProductWarehouse1;
        private JSRequirement.Controls.JSLabel jsLabel12;
        private JSRequirement.Controls.JSLabel jsLabel13;
        private JSRequirement.Controls.JSLabel jsLabel14;
        private JSRequirement.Controls.JSTextBox jstxtProductBarcode2;
        private JSRequirement.Controls.JSLabel jsLabel15;
        private JSRequirement.Controls.JSLabel jsLabel16;
        private JSRequirement.Controls.JSLabel jsLabel17;
        private JSRequirement.Controls.JSLabel jsLabel18;
        private JSRequirement.Controls.JSLabel jsLabel19;
        private JSRequirement.Controls.JSTextBox jstxtProductWarehouse8;
        private JSRequirement.Controls.JSTextBox jstxtProductWarehouse7;
        private JSRequirement.Controls.JSTextBox jstxtProductWarehouse6;
        private JSRequirement.Controls.JSTextBox jstxtProductWarehouse5;
        private JSRequirement.Controls.JSTextBox jstxtProductWarehouse4;
        private JSRequirement.Controls.JSLabel jsLabel20;
        private JSRequirement.Controls.JSTextBox jstxtProductWarehouse9;
        private System.Windows.Forms.TabPage tabPurchase;
        private System.Windows.Forms.TabPage tabSale;
        private System.Windows.Forms.TabPage tabUser;
        private JSRequirement.Controls.JSGroupBox jsGbxCategoryGeneral;
        private JSRequirement.Controls.JSLabel jsLabel24;
        private JSRequirement.Controls.JSTextBox jstxtCategory1;
        private JSRequirement.Controls.JSGroupBox jsGbxUnitGeneral;
        private JSRequirement.Controls.JSTextBox jstxtUnit1;
        private JSRequirement.Controls.JSLabel jsLabel21;
        private JSRequirement.Controls.JSGroupBox jsGbxUserGeneral;
        private JSRequirement.Controls.JSTextBox jstxtUser4;
        private JSRequirement.Controls.JSTextBox jstxtUser3;
        private JSRequirement.Controls.JSTextBox jstxtUser2;
        private JSRequirement.Controls.JSTextBox jstxtUser1;
        private JSRequirement.Controls.JSLabel jsLabel22;
        private JSRequirement.Controls.JSLabel jsLabel23;
        private JSRequirement.Controls.JSLabel jsLabel25;
        private JSRequirement.Controls.JSLabel jsLabel26;
        private JSRequirement.Controls.JSTextBox jstxtUser6;
        private JSRequirement.Controls.JSTextBox jstxtUser5;
        private JSRequirement.Controls.JSLabel jsLabel28;
        private JSRequirement.Controls.JSLabel jsLabel29;
        private JSRequirement.Controls.JSGroupBox jsGbxSupplierGeneral;
        private JSRequirement.Controls.JSTextBox jstxtSupplier1;
        private JSRequirement.Controls.JSLabel jsLabel34;
        private JSRequirement.Controls.JSGroupBox jsGbxSaleGeneral;
        private JSRequirement.Controls.JSTextBox jstxtSaleGeneral3;
        private JSRequirement.Controls.JSTextBox jstxtSaleGeneral2;
        private JSRequirement.Controls.JSTextBox jstxtSaleGeneral1;
        private JSRequirement.Controls.JSLabel jsLabel27;
        private JSRequirement.Controls.JSLabel jsLabel30;
        private JSRequirement.Controls.JSLabel jsLabel31;
        private JSRequirement.Controls.JSGroupBox jsGbxSaleDetail;
        private JSRequirement.Controls.JSTextBox jstxtSaleDetail3;
        private JSRequirement.Controls.JSTextBox jstxtSaleDetail2;
        private JSRequirement.Controls.JSTextBox jstxtSaleDetail1;
        private JSRequirement.Controls.JSLabel jsLabel32;
        private JSRequirement.Controls.JSLabel jsLabel33;
        private JSRequirement.Controls.JSLabel jsLabel35;
        private JSRequirement.Controls.JSTextBox jstxtSaleDetail4;
        private JSRequirement.Controls.JSLabel jsLabel36;
        private JSRequirement.Controls.JSGroupBox jsGbxPurchaseGeneral;
        private JSRequirement.Controls.JSTextBox jstxtPurchaseGeneral3;
        private JSRequirement.Controls.JSTextBox jstxtPurchaseGeneral2;
        private JSRequirement.Controls.JSTextBox jstxtPurchaseGeneral1;
        private JSRequirement.Controls.JSLabel jsLabel37;
        private JSRequirement.Controls.JSLabel jsLabel38;
        private JSRequirement.Controls.JSLabel jsLabel39;
        private JSRequirement.Controls.JSTextBox jstxtProductWarehouse10;
        private JSRequirement.Controls.JSLabel jsLabel40;
        private JSRequirement.Controls.JSTextBox jstxtProductWarehouse11;
        private JSRequirement.Controls.JSLabel jsLabel41;
        private JSRequirement.Controls.JSGroupBox jsGbxPurchaseDetail;
        private JSRequirement.Controls.JSTextBox jstxtPurchaseDetail4;
        private JSRequirement.Controls.JSLabel jsLabel42;
        private JSRequirement.Controls.JSTextBox jstxtPurchaseDetail3;
        private JSRequirement.Controls.JSTextBox jstxtPurchaseDetail2;
        private JSRequirement.Controls.JSTextBox jstxtPurchaseDetail1;
        private JSRequirement.Controls.JSLabel jsLabel43;
        private JSRequirement.Controls.JSLabel jsLabel44;
        private JSRequirement.Controls.JSLabel jsLabel45;
    }
}
