﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace StoreManagement.Forms.frm_Product
{
    public partial class FrmProductAdd : Requirement.FrmPopup
    {
        public FrmProductAdd()
        {
            InitializeComponent();

            jsCmbCategory.DataSource = new Requirement.SMLinqDataContext().tbl_SM_ProductsCategories;
            jsCmbCategory.DisplayMember = "ProductCategory";
            jsCmbCategory.ValueMember = "ProductCategoryID";

            jsCmbUnit.DataSource = new Requirement.SMLinqDataContext().tbl_SM_ProductsUnits;
            jsCmbUnit.DisplayMember = "ProductsUnit";
            jsCmbUnit.ValueMember = "ProductsUnitID";

            jsCmbBarcodeType.SelectedIndex = 0;
        }

        private void JS7Btn2Click(object sender, EventArgs e)
        {
            Close();
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {

            if (jstxtName.Text == "" || jstxtBuyPrice.Text == "" || jstxtPrice.Text == "") 
            {
                jstxtName.BackColor = Color.Red;
                jstxtBuyPrice.BackColor = Color.Red;
                jstxtPrice.BackColor = Color.Red;
                return;
            }

            new Requirement.SMLinqDataContext().JSP_SM_Products_Add(jstxtName.Text,
                                                                    jsCmbCategory.SValue,
                                                                    jsCmbUnit.SValueByte,
                                                                    jstxtBarCode1.Text, jstxtBarCode1.Text,
                                                                    jstxtsize.Num32,
                                                                    jstxtStock.NumDouble, 0, jstxtMinInventory.NumDouble,
                                                                    jstxtBuyPrice.Num32,
                                                                    jstxtPrice.Num32, jstxtDiscount.Num32, DateTime.Now);
            
            Close();
        }

        private void FrmProductAddBarcodeTaken(object sender, EventArgs e)
        {
            if (jsCmbBarcodeType.SelectedIndex == 0)
                jstxtBarCode1.Text = JSBarcode;
            else
                jstxtBarCode2.Text = JSBarcode;
        }

        private void JSCmbBarcodeTypeSelectedIndexChanged(object sender, EventArgs e)
        {
            if (jsCmbBarcodeType.SelectedIndex == 1)
                if (string.IsNullOrWhiteSpace(jstxtBarCode1.Text))
                {
                    if (MessageBox.Show(@"بارکد اصلی وارد نشده، آیا از ورود ایران بارکد اطمینان دارید؟",
                                    @"عدم رعایت ترتیب در ورود بارکد",
                                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                    {
                        jsCmbBarcodeType.SelectedIndex = 0;
                    }

                }
        }

        private void JslblBarcodeClick(object sender, EventArgs e)
        {
            jstxtBarCode1.Text = string.Empty;
        }

        private void JslblBarcode2Click(object sender, EventArgs e)
        {
            jstxtBarCode2.Text = string.Empty;
        }

        private void FrmProductAddKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F4) JS7Btn1Click(null, null);
            if (e.KeyCode == Keys.Escape) JS7Btn2Click(null, null);
        }
    }
}
