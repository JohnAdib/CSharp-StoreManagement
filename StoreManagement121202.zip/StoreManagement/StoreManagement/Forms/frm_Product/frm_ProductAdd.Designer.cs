﻿namespace StoreManagement.Forms.frm_Product
{
    partial class FrmProductAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmProductAdd));
            this.jsGroupBox2 = new JSRequirement.Controls.JSGroupBox();
            this.jstxtBarCode2 = new JSRequirement.Controls.JSTextBox();
            this.jstxtBarCode1 = new JSRequirement.Controls.JSTextBox();
            this.jsLabel7 = new JSRequirement.Controls.JSLabel();
            this.jslblBtype = new JSRequirement.Controls.JSLabel();
            this.jsCmbBarcodeType = new JSRequirement.Controls.JSComboBox();
            this.jslblBarcode2 = new JSRequirement.Controls.JSLabel();
            this.jS7Btn2 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn1 = new JSRequirement.Controls.JS7Btn();
            this.jsLabel10 = new JSRequirement.Controls.JSLabel();
            this.jsLabel9 = new JSRequirement.Controls.JSLabel();
            this.jsLabel8 = new JSRequirement.Controls.JSLabel();
            this.jslblBarcode = new JSRequirement.Controls.JSLabel();
            this.jstxtMinInventory = new JSRequirement.Controls.JSTextBox();
            this.jstxtStock = new JSRequirement.Controls.JSTextBox();
            this.jstxtsize = new JSRequirement.Controls.JSTextBox();
            this.jsGroupBox1 = new JSRequirement.Controls.JSGroupBox();
            this.jsLabel13 = new JSRequirement.Controls.JSLabel();
            this.jsLabel12 = new JSRequirement.Controls.JSLabel();
            this.jsLabel11 = new JSRequirement.Controls.JSLabel();
            this.jsLabel6 = new JSRequirement.Controls.JSLabel();
            this.jsLabel5 = new JSRequirement.Controls.JSLabel();
            this.jsLabel4 = new JSRequirement.Controls.JSLabel();
            this.jsLabel3 = new JSRequirement.Controls.JSLabel();
            this.jsLabel2 = new JSRequirement.Controls.JSLabel();
            this.jsLabel1 = new JSRequirement.Controls.JSLabel();
            this.jstxtPrice = new JSRequirement.Controls.JSTextBox();
            this.jstxtDiscount = new JSRequirement.Controls.JSTextBox();
            this.jstxtBuyPrice = new JSRequirement.Controls.JSTextBox();
            this.jsCmbUnit = new JSRequirement.Controls.JSComboBox();
            this.jsCmbCategory = new JSRequirement.Controls.JSComboBox();
            this.jstxtName = new JSRequirement.Controls.JSTextBox();
            this.jsGroupBox2.SuspendLayout();
            this.jsGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsGroupBox2
            // 
            this.jsGroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox2.Controls.Add(this.jstxtBarCode2);
            this.jsGroupBox2.Controls.Add(this.jstxtBarCode1);
            this.jsGroupBox2.Controls.Add(this.jsLabel7);
            this.jsGroupBox2.Controls.Add(this.jslblBtype);
            this.jsGroupBox2.Controls.Add(this.jsCmbBarcodeType);
            this.jsGroupBox2.Controls.Add(this.jslblBarcode2);
            this.jsGroupBox2.Controls.Add(this.jS7Btn2);
            this.jsGroupBox2.Controls.Add(this.jS7Btn1);
            this.jsGroupBox2.Controls.Add(this.jsLabel10);
            this.jsGroupBox2.Controls.Add(this.jsLabel9);
            this.jsGroupBox2.Controls.Add(this.jsLabel8);
            this.jsGroupBox2.Controls.Add(this.jslblBarcode);
            this.jsGroupBox2.Controls.Add(this.jstxtMinInventory);
            this.jsGroupBox2.Controls.Add(this.jstxtStock);
            this.jsGroupBox2.Controls.Add(this.jstxtsize);
            this.jsGroupBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsGroupBox2.Location = new System.Drawing.Point(0, 168);
            this.jsGroupBox2.Name = "jsGroupBox2";
            this.jsGroupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox2.Size = new System.Drawing.Size(584, 219);
            this.jsGroupBox2.TabIndex = 1;
            this.jsGroupBox2.TabStop = false;
            this.jsGroupBox2.Text = "سایر مشخصات ";
            // 
            // jstxtBarCode2
            // 
            this.jstxtBarCode2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtBarCode2.BarcodeBox = true;
            this.jstxtBarCode2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtBarCode2.Location = new System.Drawing.Point(309, 59);
            this.jstxtBarCode2.MaxLength = 20;
            this.jstxtBarCode2.Name = "jstxtBarCode2";
            this.jstxtBarCode2.Num16 = ((short)(0));
            this.jstxtBarCode2.Num32 = 0;
            this.jstxtBarCode2.Num64 = ((long)(0));
            this.jstxtBarCode2.NumByte = ((byte)(0));
            this.jstxtBarCode2.NumDouble = 0D;
            this.jstxtBarCode2.NumericTextBox = false;
            this.jstxtBarCode2.NumFloat = 0F;
            this.jstxtBarCode2.PersianText = true;
            this.jstxtBarCode2.ReadOnly = true;
            this.jstxtBarCode2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtBarCode2.Size = new System.Drawing.Size(191, 26);
            this.jstxtBarCode2.TabIndex = 18;
            this.jstxtBarCode2.TabStop = false;
            this.jstxtBarCode2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtBarCode1
            // 
            this.jstxtBarCode1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtBarCode1.BarcodeBox = true;
            this.jstxtBarCode1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtBarCode1.Location = new System.Drawing.Point(309, 27);
            this.jstxtBarCode1.MaxLength = 20;
            this.jstxtBarCode1.Name = "jstxtBarCode1";
            this.jstxtBarCode1.Num16 = ((short)(0));
            this.jstxtBarCode1.Num32 = 0;
            this.jstxtBarCode1.Num64 = ((long)(0));
            this.jstxtBarCode1.NumByte = ((byte)(0));
            this.jstxtBarCode1.NumDouble = 0D;
            this.jstxtBarCode1.NumericTextBox = false;
            this.jstxtBarCode1.NumFloat = 0F;
            this.jstxtBarCode1.PersianText = true;
            this.jstxtBarCode1.ReadOnly = true;
            this.jstxtBarCode1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtBarCode1.Size = new System.Drawing.Size(192, 26);
            this.jstxtBarCode1.TabIndex = 17;
            this.jstxtBarCode1.TabStop = false;
            this.jstxtBarCode1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel7
            // 
            this.jsLabel7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel7.AutoSize = true;
            this.jsLabel7.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel7.Location = new System.Drawing.Point(507, 95);
            this.jsLabel7.Name = "jsLabel7";
            this.jsLabel7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel7.Size = new System.Drawing.Size(66, 22);
            this.jsLabel7.TabIndex = 16;
            this.jsLabel7.Text = "دریافت بارکد";
            this.jsLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jslblBtype
            // 
            this.jslblBtype.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jslblBtype.AutoSize = true;
            this.jslblBtype.BackColor = System.Drawing.Color.Transparent;
            this.jslblBtype.Location = new System.Drawing.Point(507, 99);
            this.jslblBtype.Name = "jslblBtype";
            this.jslblBtype.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jslblBtype.Size = new System.Drawing.Size(66, 22);
            this.jslblBtype.TabIndex = 16;
            this.jslblBtype.Text = "دریافت بارکد";
            this.jslblBtype.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsCmbBarcodeType
            // 
            this.jsCmbBarcodeType.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsCmbBarcodeType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.jsCmbBarcodeType.FormattingEnabled = true;
            this.jsCmbBarcodeType.Items.AddRange(new object[] {
            "بارکد اصلی",
            "ایران بارکد"});
            this.jsCmbBarcodeType.Location = new System.Drawing.Point(310, 92);
            this.jsCmbBarcodeType.Name = "jsCmbBarcodeType";
            this.jsCmbBarcodeType.PersianText = true;
            this.jsCmbBarcodeType.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsCmbBarcodeType.Size = new System.Drawing.Size(191, 30);
            this.jsCmbBarcodeType.TabIndex = 15;
            this.jsCmbBarcodeType.SelectedIndexChanged += new System.EventHandler(this.JSCmbBarcodeTypeSelectedIndexChanged);
            // 
            // jslblBarcode2
            // 
            this.jslblBarcode2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jslblBarcode2.AutoSize = true;
            this.jslblBarcode2.BackColor = System.Drawing.Color.Transparent;
            this.jslblBarcode2.Location = new System.Drawing.Point(506, 63);
            this.jslblBarcode2.Name = "jslblBarcode2";
            this.jslblBarcode2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jslblBarcode2.Size = new System.Drawing.Size(56, 22);
            this.jslblBarcode2.TabIndex = 14;
            this.jslblBarcode2.Text = "ایران بارکد";
            this.jslblBarcode2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.jslblBarcode2.Click += new System.EventHandler(this.JslblBarcode2Click);
            // 
            // jS7Btn2
            // 
            this.jS7Btn2.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Close;
            this.jS7Btn2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn2.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn2.ButtonText = "بستن";
            this.jS7Btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn2.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn2.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn2.Image")));
            this.jS7Btn2.Location = new System.Drawing.Point(41, 161);
            this.jS7Btn2.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn2.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn2.Name = "jS7Btn2";
            this.jS7Btn2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn2.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn2.TabIndex = 12;
            this.jS7Btn2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn2.UseVisualStyleBackColor = false;
            this.jS7Btn2.Click += new System.EventHandler(this.JS7Btn2Click);
            // 
            // jS7Btn1
            // 
            this.jS7Btn1.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Add;
            this.jS7Btn1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn1.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn1.ButtonText = "اضافه کردن";
            this.jS7Btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn1.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn1.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn1.Image")));
            this.jS7Btn1.Location = new System.Drawing.Point(175, 161);
            this.jS7Btn1.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn1.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn1.Name = "jS7Btn1";
            this.jS7Btn1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn1.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn1.TabIndex = 11;
            this.jS7Btn1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn1.UseVisualStyleBackColor = false;
            this.jS7Btn1.Click += new System.EventHandler(this.JS7Btn1Click);
            // 
            // jsLabel10
            // 
            this.jsLabel10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel10.AutoSize = true;
            this.jsLabel10.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel10.Location = new System.Drawing.Point(202, 26);
            this.jsLabel10.Name = "jsLabel10";
            this.jsLabel10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel10.Size = new System.Drawing.Size(101, 22);
            this.jsLabel10.TabIndex = 10;
            this.jsLabel10.Text = "حداقل موجودی لازم";
            this.jsLabel10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel9
            // 
            this.jsLabel9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel9.AutoSize = true;
            this.jsLabel9.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel9.Location = new System.Drawing.Point(202, 62);
            this.jsLabel9.Name = "jsLabel9";
            this.jsLabel9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel9.Size = new System.Drawing.Size(67, 22);
            this.jsLabel9.TabIndex = 9;
            this.jsLabel9.Text = "موجودی انبار";
            this.jsLabel9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel8
            // 
            this.jsLabel8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel8.AutoSize = true;
            this.jsLabel8.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel8.Location = new System.Drawing.Point(202, 99);
            this.jsLabel8.Name = "jsLabel8";
            this.jsLabel8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel8.Size = new System.Drawing.Size(86, 22);
            this.jsLabel8.TabIndex = 8;
            this.jsLabel8.Text = "هر کارتن محتوی";
            this.jsLabel8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jslblBarcode
            // 
            this.jslblBarcode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jslblBarcode.AutoSize = true;
            this.jslblBarcode.BackColor = System.Drawing.Color.Transparent;
            this.jslblBarcode.Location = new System.Drawing.Point(507, 31);
            this.jslblBarcode.Name = "jslblBarcode";
            this.jslblBarcode.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jslblBarcode.Size = new System.Drawing.Size(59, 22);
            this.jslblBarcode.TabIndex = 7;
            this.jslblBarcode.Text = "بارکد اصلی";
            this.jslblBarcode.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.jslblBarcode.Click += new System.EventHandler(this.JslblBarcodeClick);
            // 
            // jstxtMinInventory
            // 
            this.jstxtMinInventory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtMinInventory.BarcodeBox = false;
            this.jstxtMinInventory.Location = new System.Drawing.Point(41, 23);
            this.jstxtMinInventory.MaxLength = 200;
            this.jstxtMinInventory.Name = "jstxtMinInventory";
            this.jstxtMinInventory.Num16 = ((short)(0));
            this.jstxtMinInventory.Num32 = 0;
            this.jstxtMinInventory.Num64 = ((long)(0));
            this.jstxtMinInventory.NumByte = ((byte)(0));
            this.jstxtMinInventory.NumDouble = 0D;
            this.jstxtMinInventory.NumericTextBox = false;
            this.jstxtMinInventory.NumFloat = 0F;
            this.jstxtMinInventory.PersianText = true;
            this.jstxtMinInventory.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtMinInventory.Size = new System.Drawing.Size(155, 30);
            this.jstxtMinInventory.TabIndex = 3;
            // 
            // jstxtStock
            // 
            this.jstxtStock.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtStock.BarcodeBox = false;
            this.jstxtStock.Location = new System.Drawing.Point(41, 59);
            this.jstxtStock.MaxLength = 200;
            this.jstxtStock.Name = "jstxtStock";
            this.jstxtStock.Num16 = ((short)(0));
            this.jstxtStock.Num32 = 0;
            this.jstxtStock.Num64 = ((long)(0));
            this.jstxtStock.NumByte = ((byte)(0));
            this.jstxtStock.NumDouble = 0D;
            this.jstxtStock.NumericTextBox = false;
            this.jstxtStock.NumFloat = 0F;
            this.jstxtStock.PersianText = true;
            this.jstxtStock.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtStock.Size = new System.Drawing.Size(155, 30);
            this.jstxtStock.TabIndex = 2;
            // 
            // jstxtsize
            // 
            this.jstxtsize.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtsize.BarcodeBox = false;
            this.jstxtsize.Location = new System.Drawing.Point(41, 96);
            this.jstxtsize.MaxLength = 200;
            this.jstxtsize.Name = "jstxtsize";
            this.jstxtsize.Num16 = ((short)(0));
            this.jstxtsize.Num32 = 0;
            this.jstxtsize.Num64 = ((long)(0));
            this.jstxtsize.NumByte = ((byte)(0));
            this.jstxtsize.NumDouble = 0D;
            this.jstxtsize.NumericTextBox = false;
            this.jstxtsize.NumFloat = 0F;
            this.jstxtsize.PersianText = true;
            this.jstxtsize.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtsize.Size = new System.Drawing.Size(155, 30);
            this.jstxtsize.TabIndex = 1;
            // 
            // jsGroupBox1
            // 
            this.jsGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox1.Controls.Add(this.jsLabel13);
            this.jsGroupBox1.Controls.Add(this.jsLabel12);
            this.jsGroupBox1.Controls.Add(this.jsLabel11);
            this.jsGroupBox1.Controls.Add(this.jsLabel6);
            this.jsGroupBox1.Controls.Add(this.jsLabel5);
            this.jsGroupBox1.Controls.Add(this.jsLabel4);
            this.jsGroupBox1.Controls.Add(this.jsLabel3);
            this.jsGroupBox1.Controls.Add(this.jsLabel2);
            this.jsGroupBox1.Controls.Add(this.jsLabel1);
            this.jsGroupBox1.Controls.Add(this.jstxtPrice);
            this.jsGroupBox1.Controls.Add(this.jstxtDiscount);
            this.jsGroupBox1.Controls.Add(this.jstxtBuyPrice);
            this.jsGroupBox1.Controls.Add(this.jsCmbUnit);
            this.jsGroupBox1.Controls.Add(this.jsCmbCategory);
            this.jsGroupBox1.Controls.Add(this.jstxtName);
            this.jsGroupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.jsGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.jsGroupBox1.Name = "jsGroupBox1";
            this.jsGroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox1.Size = new System.Drawing.Size(584, 168);
            this.jsGroupBox1.TabIndex = 0;
            this.jsGroupBox1.TabStop = false;
            this.jsGroupBox1.Text = "مشخصات اصلی کالا";
            // 
            // jsLabel13
            // 
            this.jsLabel13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel13.AutoSize = true;
            this.jsLabel13.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel13.Font = new System.Drawing.Font("B Mitra", 10F);
            this.jsLabel13.Location = new System.Drawing.Point(8, 106);
            this.jsLabel13.Name = "jsLabel13";
            this.jsLabel13.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel13.Size = new System.Drawing.Size(31, 20);
            this.jsLabel13.TabIndex = 15;
            this.jsLabel13.Text = "تومان";
            this.jsLabel13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel12
            // 
            this.jsLabel12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel12.AutoSize = true;
            this.jsLabel12.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel12.Font = new System.Drawing.Font("B Mitra", 10F);
            this.jsLabel12.Location = new System.Drawing.Point(8, 70);
            this.jsLabel12.Name = "jsLabel12";
            this.jsLabel12.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel12.Size = new System.Drawing.Size(31, 20);
            this.jsLabel12.TabIndex = 14;
            this.jsLabel12.Text = "تومان";
            this.jsLabel12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel11
            // 
            this.jsLabel11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel11.AutoSize = true;
            this.jsLabel11.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel11.Font = new System.Drawing.Font("B Mitra", 10F);
            this.jsLabel11.Location = new System.Drawing.Point(8, 34);
            this.jsLabel11.Name = "jsLabel11";
            this.jsLabel11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel11.Size = new System.Drawing.Size(31, 20);
            this.jsLabel11.TabIndex = 13;
            this.jsLabel11.Text = "تومان";
            this.jsLabel11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel6
            // 
            this.jsLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel6.AutoSize = true;
            this.jsLabel6.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel6.ForeColor = System.Drawing.Color.Red;
            this.jsLabel6.Location = new System.Drawing.Point(202, 104);
            this.jsLabel6.Name = "jsLabel6";
            this.jsLabel6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel6.Size = new System.Drawing.Size(66, 22);
            this.jsLabel6.TabIndex = 12;
            this.jsLabel6.Text = "قیمت فروش";
            this.jsLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel5
            // 
            this.jsLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel5.AutoSize = true;
            this.jsLabel5.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel5.Location = new System.Drawing.Point(202, 68);
            this.jsLabel5.Name = "jsLabel5";
            this.jsLabel5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel5.Size = new System.Drawing.Size(41, 22);
            this.jsLabel5.TabIndex = 11;
            this.jsLabel5.Text = "تخفیف";
            this.jsLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel4
            // 
            this.jsLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel4.AutoSize = true;
            this.jsLabel4.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel4.ForeColor = System.Drawing.Color.Red;
            this.jsLabel4.Location = new System.Drawing.Point(202, 32);
            this.jsLabel4.Name = "jsLabel4";
            this.jsLabel4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel4.Size = new System.Drawing.Size(60, 22);
            this.jsLabel4.TabIndex = 10;
            this.jsLabel4.Text = "قیمت خرید";
            this.jsLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel3
            // 
            this.jsLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel3.AutoSize = true;
            this.jsLabel3.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel3.Location = new System.Drawing.Point(506, 104);
            this.jsLabel3.Name = "jsLabel3";
            this.jsLabel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel3.Size = new System.Drawing.Size(67, 22);
            this.jsLabel3.TabIndex = 9;
            this.jsLabel3.Text = "واحد شمارش";
            this.jsLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel2
            // 
            this.jsLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel2.AutoSize = true;
            this.jsLabel2.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel2.Location = new System.Drawing.Point(506, 68);
            this.jsLabel2.Name = "jsLabel2";
            this.jsLabel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel2.Size = new System.Drawing.Size(59, 22);
            this.jsLabel2.TabIndex = 8;
            this.jsLabel2.Text = "دسته بندی";
            this.jsLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel1
            // 
            this.jsLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel1.AutoSize = true;
            this.jsLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel1.ForeColor = System.Drawing.Color.Red;
            this.jsLabel1.Location = new System.Drawing.Point(506, 32);
            this.jsLabel1.Name = "jsLabel1";
            this.jsLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel1.Size = new System.Drawing.Size(43, 22);
            this.jsLabel1.TabIndex = 7;
            this.jsLabel1.Text = "نام کالا";
            this.jsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtPrice
            // 
            this.jstxtPrice.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtPrice.BarcodeBox = false;
            this.jstxtPrice.Location = new System.Drawing.Point(41, 101);
            this.jstxtPrice.MaxLength = 200;
            this.jstxtPrice.Name = "jstxtPrice";
            this.jstxtPrice.Num16 = ((short)(0));
            this.jstxtPrice.Num32 = 0;
            this.jstxtPrice.Num64 = ((long)(0));
            this.jstxtPrice.NumByte = ((byte)(0));
            this.jstxtPrice.NumDouble = 0D;
            this.jstxtPrice.NumericTextBox = false;
            this.jstxtPrice.NumFloat = 0F;
            this.jstxtPrice.PersianText = true;
            this.jstxtPrice.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtPrice.Size = new System.Drawing.Size(155, 30);
            this.jstxtPrice.TabIndex = 6;
            // 
            // jstxtDiscount
            // 
            this.jstxtDiscount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtDiscount.BarcodeBox = false;
            this.jstxtDiscount.Location = new System.Drawing.Point(41, 65);
            this.jstxtDiscount.MaxLength = 200;
            this.jstxtDiscount.Name = "jstxtDiscount";
            this.jstxtDiscount.Num16 = ((short)(0));
            this.jstxtDiscount.Num32 = 0;
            this.jstxtDiscount.Num64 = ((long)(0));
            this.jstxtDiscount.NumByte = ((byte)(0));
            this.jstxtDiscount.NumDouble = 0D;
            this.jstxtDiscount.NumericTextBox = false;
            this.jstxtDiscount.NumFloat = 0F;
            this.jstxtDiscount.PersianText = true;
            this.jstxtDiscount.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtDiscount.Size = new System.Drawing.Size(155, 30);
            this.jstxtDiscount.TabIndex = 5;
            // 
            // jstxtBuyPrice
            // 
            this.jstxtBuyPrice.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtBuyPrice.BarcodeBox = false;
            this.jstxtBuyPrice.Location = new System.Drawing.Point(41, 29);
            this.jstxtBuyPrice.MaxLength = 200;
            this.jstxtBuyPrice.Name = "jstxtBuyPrice";
            this.jstxtBuyPrice.Num16 = ((short)(0));
            this.jstxtBuyPrice.Num32 = 0;
            this.jstxtBuyPrice.Num64 = ((long)(0));
            this.jstxtBuyPrice.NumByte = ((byte)(0));
            this.jstxtBuyPrice.NumDouble = 0D;
            this.jstxtBuyPrice.NumericTextBox = false;
            this.jstxtBuyPrice.NumFloat = 0F;
            this.jstxtBuyPrice.PersianText = true;
            this.jstxtBuyPrice.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtBuyPrice.Size = new System.Drawing.Size(155, 30);
            this.jstxtBuyPrice.TabIndex = 4;
            // 
            // jsCmbUnit
            // 
            this.jsCmbUnit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsCmbUnit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.jsCmbUnit.FormattingEnabled = true;
            this.jsCmbUnit.Location = new System.Drawing.Point(310, 101);
            this.jsCmbUnit.Name = "jsCmbUnit";
            this.jsCmbUnit.PersianText = true;
            this.jsCmbUnit.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsCmbUnit.Size = new System.Drawing.Size(191, 30);
            this.jsCmbUnit.TabIndex = 3;
            // 
            // jsCmbCategory
            // 
            this.jsCmbCategory.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsCmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.jsCmbCategory.FormattingEnabled = true;
            this.jsCmbCategory.Location = new System.Drawing.Point(310, 65);
            this.jsCmbCategory.Name = "jsCmbCategory";
            this.jsCmbCategory.PersianText = true;
            this.jsCmbCategory.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsCmbCategory.Size = new System.Drawing.Size(191, 30);
            this.jsCmbCategory.TabIndex = 1;
            // 
            // jstxtName
            // 
            this.jstxtName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtName.BarcodeBox = false;
            this.jstxtName.Location = new System.Drawing.Point(310, 29);
            this.jstxtName.MaxLength = 200;
            this.jstxtName.Name = "jstxtName";
            this.jstxtName.Num16 = ((short)(0));
            this.jstxtName.Num32 = 0;
            this.jstxtName.Num64 = ((long)(0));
            this.jstxtName.NumByte = ((byte)(0));
            this.jstxtName.NumDouble = 0D;
            this.jstxtName.NumericTextBox = false;
            this.jstxtName.NumFloat = 0F;
            this.jstxtName.PersianText = true;
            this.jstxtName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtName.Size = new System.Drawing.Size(191, 30);
            this.jstxtName.TabIndex = 0;
            // 
            // FrmProductAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(584, 387);
            this.Controls.Add(this.jsGroupBox2);
            this.Controls.Add(this.jsGroupBox1);
            this.Name = "FrmProductAdd";
            this.Text = "افزودن کالای جدید";
            this.BarcodeTaken += new System.EventHandler(this.FrmProductAddBarcodeTaken);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmProductAddKeyDown);
            this.jsGroupBox2.ResumeLayout(false);
            this.jsGroupBox2.PerformLayout();
            this.jsGroupBox1.ResumeLayout(false);
            this.jsGroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSGroupBox jsGroupBox1;
        private JSRequirement.Controls.JSTextBox jstxtName;
        private JSRequirement.Controls.JSComboBox jsCmbCategory;
        private JSRequirement.Controls.JSComboBox jsCmbUnit;
        private JSRequirement.Controls.JSTextBox jstxtPrice;
        private JSRequirement.Controls.JSTextBox jstxtDiscount;
        private JSRequirement.Controls.JSTextBox jstxtBuyPrice;
        private JSRequirement.Controls.JSLabel jsLabel6;
        private JSRequirement.Controls.JSLabel jsLabel5;
        private JSRequirement.Controls.JSLabel jsLabel4;
        private JSRequirement.Controls.JSLabel jsLabel3;
        private JSRequirement.Controls.JSLabel jsLabel2;
        private JSRequirement.Controls.JSLabel jsLabel1;
        private JSRequirement.Controls.JSTextBox jstxtsize;
        private JSRequirement.Controls.JSTextBox jstxtStock;
        private JSRequirement.Controls.JSTextBox jstxtMinInventory;
        private JSRequirement.Controls.JSLabel jslblBarcode;
        private JSRequirement.Controls.JSLabel jsLabel8;
        private JSRequirement.Controls.JSLabel jsLabel9;
        private JSRequirement.Controls.JSLabel jsLabel10;
        private JSRequirement.Controls.JSGroupBox jsGroupBox2;
        private JSRequirement.Controls.JSLabel jsLabel13;
        private JSRequirement.Controls.JSLabel jsLabel12;
        private JSRequirement.Controls.JSLabel jsLabel11;
        private JSRequirement.Controls.JS7Btn jS7Btn2;
        private JSRequirement.Controls.JS7Btn jS7Btn1;
        private JSRequirement.Controls.JSLabel jslblBarcode2;
        private JSRequirement.Controls.JSComboBox jsCmbBarcodeType;
        private JSRequirement.Controls.JSLabel jslblBtype;
        private JSRequirement.Controls.JSLabel jsLabel7;
        public JSRequirement.Controls.JSTextBox jstxtBarCode1;
        public JSRequirement.Controls.JSTextBox jstxtBarCode2;
    }
}
