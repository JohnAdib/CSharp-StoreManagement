﻿using System;
using System.ComponentModel;
using System.Windows.Forms;

namespace StoreManagement.Requirement
{
    public partial class FrmPopup : JSRequirement.Forms.JSBaseForm
    {
        public FrmPopup()
        {
            InitializeComponent();
        }

        [Category("JSCustomizer"), Description("Raise Event when user input barcode.")]
        public event EventHandler BarcodeTaken;
        protected virtual void OnBarcodeTaken(EventArgs e)
        {
            if (BarcodeTaken != null)
                BarcodeTaken(this, e);
        }

        /// <summary>
        /// Give barcode from user and save it.
        /// </summary>
        [Category("JSCustomizer"), Description("Give barcode from user and save it.")]
        public string JSBarcode { get; private set; }

        private bool _isBarCode;
        private string _barcode = string.Empty;
        private void FrmPopupKeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '$')
            {
                try
                {
                    InputLanguage.CurrentInputLanguage =
                        InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-us"));
                }
                catch { return; }

                _isBarCode = !_isBarCode;
                e.Handled = true;                           // dont show any char to user
                if (_isBarCode) return;                     // if start reading barcode, don't continue

                if (_barcode.Length > 3)                    // if barcode len > 3
                {
                    JSBarcode = _barcode;
                    BarcodeTaken(this, e);
                    _barcode = string.Empty;
                }
            }
            else if (_isBarCode)
            {
                _barcode += e.KeyChar;                      // give barcode char by char
                e.Handled = true;                           // dont show any char to user
            }
        }

    }
}
