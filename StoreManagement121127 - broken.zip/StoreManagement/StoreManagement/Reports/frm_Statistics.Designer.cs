﻿namespace StoreManagement.Reports
{
    partial class FrmStatistics
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StatisticsTab = new System.Windows.Forms.TabControl();
            this.tabCustomers = new System.Windows.Forms.TabPage();
            this.jsLabel7 = new JSRequirement.Controls.JSLabel();
            this.jsLabel3 = new JSRequirement.Controls.JSLabel();
            this.jsLabel2 = new JSRequirement.Controls.JSLabel();
            this.jsLabel1 = new JSRequirement.Controls.JSLabel();
            this.tabProducts = new System.Windows.Forms.TabPage();
            this.jsBarCodeBox1 = new JSRequirement.Controls.JSBarCodeBox();
            this.jsBarCodeBox2 = new JSRequirement.Controls.JSBarCodeBox();
            this.jsBarCodeBox3 = new JSRequirement.Controls.JSBarCodeBox();
            this.jsLabel4 = new JSRequirement.Controls.JSLabel();
            this.jsLabel5 = new JSRequirement.Controls.JSLabel();
            this.jsLabel6 = new JSRequirement.Controls.JSLabel();
            this.jstxtCustomer1 = new JSRequirement.Controls.JSTextBox();
            this.jstxtCustomer2 = new JSRequirement.Controls.JSTextBox();
            this.jstxtCustomer3 = new JSRequirement.Controls.JSTextBox();
            this.jstxtCustomer4 = new JSRequirement.Controls.JSTextBox();
            this.StatisticsTab.SuspendLayout();
            this.tabCustomers.SuspendLayout();
            this.tabProducts.SuspendLayout();
            this.SuspendLayout();
            // 
            // StatisticsTab
            // 
            this.StatisticsTab.Controls.Add(this.tabCustomers);
            this.StatisticsTab.Controls.Add(this.tabProducts);
            this.StatisticsTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.StatisticsTab.Location = new System.Drawing.Point(0, 0);
            this.StatisticsTab.Name = "StatisticsTab";
            this.StatisticsTab.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.StatisticsTab.RightToLeftLayout = true;
            this.StatisticsTab.SelectedIndex = 0;
            this.StatisticsTab.Size = new System.Drawing.Size(509, 266);
            this.StatisticsTab.TabIndex = 4;
            // 
            // tabCustomers
            // 
            this.tabCustomers.Controls.Add(this.jstxtCustomer4);
            this.tabCustomers.Controls.Add(this.jstxtCustomer3);
            this.tabCustomers.Controls.Add(this.jstxtCustomer2);
            this.tabCustomers.Controls.Add(this.jstxtCustomer1);
            this.tabCustomers.Controls.Add(this.jsLabel7);
            this.tabCustomers.Controls.Add(this.jsLabel3);
            this.tabCustomers.Controls.Add(this.jsLabel2);
            this.tabCustomers.Controls.Add(this.jsLabel1);
            this.tabCustomers.Location = new System.Drawing.Point(4, 31);
            this.tabCustomers.Name = "tabCustomers";
            this.tabCustomers.Padding = new System.Windows.Forms.Padding(3);
            this.tabCustomers.Size = new System.Drawing.Size(501, 231);
            this.tabCustomers.TabIndex = 0;
            this.tabCustomers.Text = "مشتریان";
            this.tabCustomers.UseVisualStyleBackColor = true;
            // 
            // jsLabel7
            // 
            this.jsLabel7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel7.AutoSize = true;
            this.jsLabel7.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel7.Location = new System.Drawing.Point(260, 120);
            this.jsLabel7.Name = "jsLabel7";
            this.jsLabel7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel7.Size = new System.Drawing.Size(196, 22);
            this.jsLabel7.TabIndex = 11;
            this.jsLabel7.Text = "تعداد مشتریانی که تاکنون خرید نداشته اند";
            this.jsLabel7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel3
            // 
            this.jsLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel3.AutoSize = true;
            this.jsLabel3.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel3.Location = new System.Drawing.Point(260, 88);
            this.jsLabel3.Name = "jsLabel3";
            this.jsLabel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel3.Size = new System.Drawing.Size(235, 22);
            this.jsLabel3.TabIndex = 6;
            this.jsLabel3.Text = "تعداد مشتریانی که تاکنون خرید غیرنقدی داشته اند";
            this.jsLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel2
            // 
            this.jsLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel2.AutoSize = true;
            this.jsLabel2.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel2.Location = new System.Drawing.Point(260, 56);
            this.jsLabel2.Name = "jsLabel2";
            this.jsLabel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel2.Size = new System.Drawing.Size(192, 22);
            this.jsLabel2.TabIndex = 5;
            this.jsLabel2.Text = "تعداد مشتریانی که تاکنون خرید داشته اند";
            this.jsLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel1
            // 
            this.jsLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel1.AutoSize = true;
            this.jsLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel1.Location = new System.Drawing.Point(260, 24);
            this.jsLabel1.Name = "jsLabel1";
            this.jsLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel1.Size = new System.Drawing.Size(125, 22);
            this.jsLabel1.TabIndex = 4;
            this.jsLabel1.Text = "مجموع مشتریان ثبت شده";
            this.jsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabProducts
            // 
            this.tabProducts.Controls.Add(this.jsBarCodeBox1);
            this.tabProducts.Controls.Add(this.jsBarCodeBox2);
            this.tabProducts.Controls.Add(this.jsBarCodeBox3);
            this.tabProducts.Controls.Add(this.jsLabel4);
            this.tabProducts.Controls.Add(this.jsLabel5);
            this.tabProducts.Controls.Add(this.jsLabel6);
            this.tabProducts.Location = new System.Drawing.Point(4, 31);
            this.tabProducts.Name = "tabProducts";
            this.tabProducts.Padding = new System.Windows.Forms.Padding(3);
            this.tabProducts.Size = new System.Drawing.Size(501, 231);
            this.tabProducts.TabIndex = 1;
            this.tabProducts.Text = "کالاها";
            this.tabProducts.UseVisualStyleBackColor = true;
            // 
            // jsBarCodeBox1
            // 
            this.jsBarCodeBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsBarCodeBox1.Enabled = false;
            this.jsBarCodeBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jsBarCodeBox1.Location = new System.Drawing.Point(143, 70);
            this.jsBarCodeBox1.MaxLength = 20;
            this.jsBarCodeBox1.Name = "jsBarCodeBox1";
            this.jsBarCodeBox1.PersianText = true;
            this.jsBarCodeBox1.ReadOnly = true;
            this.jsBarCodeBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jsBarCodeBox1.Size = new System.Drawing.Size(100, 26);
            this.jsBarCodeBox1.TabIndex = 16;
            this.jsBarCodeBox1.TabStop = false;
            this.jsBarCodeBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsBarCodeBox2
            // 
            this.jsBarCodeBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsBarCodeBox2.Enabled = false;
            this.jsBarCodeBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jsBarCodeBox2.Location = new System.Drawing.Point(143, 38);
            this.jsBarCodeBox2.MaxLength = 20;
            this.jsBarCodeBox2.Name = "jsBarCodeBox2";
            this.jsBarCodeBox2.PersianText = true;
            this.jsBarCodeBox2.ReadOnly = true;
            this.jsBarCodeBox2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jsBarCodeBox2.Size = new System.Drawing.Size(100, 26);
            this.jsBarCodeBox2.TabIndex = 15;
            this.jsBarCodeBox2.TabStop = false;
            this.jsBarCodeBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsBarCodeBox3
            // 
            this.jsBarCodeBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsBarCodeBox3.Enabled = false;
            this.jsBarCodeBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jsBarCodeBox3.Location = new System.Drawing.Point(143, 6);
            this.jsBarCodeBox3.MaxLength = 20;
            this.jsBarCodeBox3.Name = "jsBarCodeBox3";
            this.jsBarCodeBox3.PersianText = true;
            this.jsBarCodeBox3.ReadOnly = true;
            this.jsBarCodeBox3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jsBarCodeBox3.Size = new System.Drawing.Size(100, 26);
            this.jsBarCodeBox3.TabIndex = 14;
            this.jsBarCodeBox3.TabStop = false;
            this.jsBarCodeBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jsLabel4
            // 
            this.jsLabel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel4.AutoSize = true;
            this.jsLabel4.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel4.Location = new System.Drawing.Point(249, 74);
            this.jsLabel4.Name = "jsLabel4";
            this.jsLabel4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel4.Size = new System.Drawing.Size(235, 22);
            this.jsLabel4.TabIndex = 13;
            this.jsLabel4.Text = "تعداد مشتریانی که تاکنون خرید غیرنقدی داشته اند";
            this.jsLabel4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel5
            // 
            this.jsLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel5.AutoSize = true;
            this.jsLabel5.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel5.Location = new System.Drawing.Point(249, 42);
            this.jsLabel5.Name = "jsLabel5";
            this.jsLabel5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel5.Size = new System.Drawing.Size(192, 22);
            this.jsLabel5.TabIndex = 12;
            this.jsLabel5.Text = "تعداد مشتریانی که تاکنون خرید داشته اند";
            this.jsLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel6
            // 
            this.jsLabel6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel6.AutoSize = true;
            this.jsLabel6.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel6.Location = new System.Drawing.Point(249, 10);
            this.jsLabel6.Name = "jsLabel6";
            this.jsLabel6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel6.Size = new System.Drawing.Size(125, 22);
            this.jsLabel6.TabIndex = 11;
            this.jsLabel6.Text = "مجموع مشتریان ثبت شده";
            this.jsLabel6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtCustomer1
            // 
            this.jstxtCustomer1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtCustomer1.BarcodeBox = true;
            this.jstxtCustomer1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtCustomer1.Location = new System.Drawing.Point(154, 20);
            this.jstxtCustomer1.MaxLength = 20;
            this.jstxtCustomer1.Name = "jstxtCustomer1";
            this.jstxtCustomer1.Num16 = ((short)(0));
            this.jstxtCustomer1.Num32 = 0;
            this.jstxtCustomer1.Num64 = ((long)(0));
            this.jstxtCustomer1.NumByte = ((byte)(0));
            this.jstxtCustomer1.NumDouble = 0D;
            this.jstxtCustomer1.NumericTextBox = false;
            this.jstxtCustomer1.NumFloat = 0F;
            this.jstxtCustomer1.PersianText = true;
            this.jstxtCustomer1.ReadOnly = true;
            this.jstxtCustomer1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtCustomer1.Size = new System.Drawing.Size(100, 26);
            this.jstxtCustomer1.TabIndex = 12;
            this.jstxtCustomer1.TabStop = false;
            this.jstxtCustomer1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtCustomer2
            // 
            this.jstxtCustomer2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtCustomer2.BarcodeBox = true;
            this.jstxtCustomer2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtCustomer2.Location = new System.Drawing.Point(154, 52);
            this.jstxtCustomer2.MaxLength = 20;
            this.jstxtCustomer2.Name = "jstxtCustomer2";
            this.jstxtCustomer2.Num16 = ((short)(0));
            this.jstxtCustomer2.Num32 = 0;
            this.jstxtCustomer2.Num64 = ((long)(0));
            this.jstxtCustomer2.NumByte = ((byte)(0));
            this.jstxtCustomer2.NumDouble = 0D;
            this.jstxtCustomer2.NumericTextBox = false;
            this.jstxtCustomer2.NumFloat = 0F;
            this.jstxtCustomer2.PersianText = true;
            this.jstxtCustomer2.ReadOnly = true;
            this.jstxtCustomer2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtCustomer2.Size = new System.Drawing.Size(100, 26);
            this.jstxtCustomer2.TabIndex = 13;
            this.jstxtCustomer2.TabStop = false;
            this.jstxtCustomer2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtCustomer3
            // 
            this.jstxtCustomer3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtCustomer3.BarcodeBox = true;
            this.jstxtCustomer3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtCustomer3.Location = new System.Drawing.Point(154, 84);
            this.jstxtCustomer3.MaxLength = 20;
            this.jstxtCustomer3.Name = "jstxtCustomer3";
            this.jstxtCustomer3.Num16 = ((short)(0));
            this.jstxtCustomer3.Num32 = 0;
            this.jstxtCustomer3.Num64 = ((long)(0));
            this.jstxtCustomer3.NumByte = ((byte)(0));
            this.jstxtCustomer3.NumDouble = 0D;
            this.jstxtCustomer3.NumericTextBox = false;
            this.jstxtCustomer3.NumFloat = 0F;
            this.jstxtCustomer3.PersianText = true;
            this.jstxtCustomer3.ReadOnly = true;
            this.jstxtCustomer3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtCustomer3.Size = new System.Drawing.Size(100, 26);
            this.jstxtCustomer3.TabIndex = 14;
            this.jstxtCustomer3.TabStop = false;
            this.jstxtCustomer3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // jstxtCustomer4
            // 
            this.jstxtCustomer4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtCustomer4.BarcodeBox = true;
            this.jstxtCustomer4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.jstxtCustomer4.Location = new System.Drawing.Point(154, 116);
            this.jstxtCustomer4.MaxLength = 20;
            this.jstxtCustomer4.Name = "jstxtCustomer4";
            this.jstxtCustomer4.Num16 = ((short)(0));
            this.jstxtCustomer4.Num32 = 0;
            this.jstxtCustomer4.Num64 = ((long)(0));
            this.jstxtCustomer4.NumByte = ((byte)(0));
            this.jstxtCustomer4.NumDouble = 0D;
            this.jstxtCustomer4.NumericTextBox = false;
            this.jstxtCustomer4.NumFloat = 0F;
            this.jstxtCustomer4.PersianText = true;
            this.jstxtCustomer4.ReadOnly = true;
            this.jstxtCustomer4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.jstxtCustomer4.Size = new System.Drawing.Size(100, 26);
            this.jstxtCustomer4.TabIndex = 15;
            this.jstxtCustomer4.TabStop = false;
            this.jstxtCustomer4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // FrmStatistics
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(584, 266);
            this.Controls.Add(this.StatisticsTab);
            this.FormTitle = "خلاصه آمار";
            this.Name = "FrmStatistics";
            this.Text = "سامانه مدیریت فروشگاه | خلاصه آمار";
            this.Load += new System.EventHandler(this.FrmStatisticsLoad);
            this.Controls.SetChildIndex(this.StatisticsTab, 0);
            this.StatisticsTab.ResumeLayout(false);
            this.tabCustomers.ResumeLayout(false);
            this.tabCustomers.PerformLayout();
            this.tabProducts.ResumeLayout(false);
            this.tabProducts.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl StatisticsTab;
        private System.Windows.Forms.TabPage tabCustomers;
        private System.Windows.Forms.TabPage tabProducts;
        private JSRequirement.Controls.JSLabel jsLabel2;
        private JSRequirement.Controls.JSLabel jsLabel1;
        private JSRequirement.Controls.JSLabel jsLabel3;
        private JSRequirement.Controls.JSBarCodeBox jsBarCodeBox1;
        private JSRequirement.Controls.JSBarCodeBox jsBarCodeBox2;
        private JSRequirement.Controls.JSBarCodeBox jsBarCodeBox3;
        private JSRequirement.Controls.JSLabel jsLabel4;
        private JSRequirement.Controls.JSLabel jsLabel5;
        private JSRequirement.Controls.JSLabel jsLabel6;
        private JSRequirement.Controls.JSLabel jsLabel7;
        private JSRequirement.Controls.JSTextBox jstxtCustomer1;
        private JSRequirement.Controls.JSTextBox jstxtCustomer4;
        private JSRequirement.Controls.JSTextBox jstxtCustomer3;
        private JSRequirement.Controls.JSTextBox jstxtCustomer2;
    }
}
