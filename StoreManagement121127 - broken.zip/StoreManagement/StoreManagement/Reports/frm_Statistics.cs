﻿using System;
using System.Linq;

namespace StoreManagement.Reports
{
    public partial class FrmStatistics : Requirement.JSfrmBase
    {
        public FrmStatistics()
        {
            InitializeComponent();
        }

        private void FrmStatisticsLoad(object sender, EventArgs e)
        {
            CalcStatistics();
        }

        private void CalcStatistics()
        {
            jstxtCustomer1.Text = new Requirement.SMLinqDataContext().tbl_SM_Customers.Count().ToString();
            jstxtCustomer2.Text = new Requirement.SMLinqDataContext().tbl_SM_Sales.Select(c => c.CustomerID).Distinct().Count().ToString();
            jstxtCustomer3.Text =
                new Requirement.SMLinqDataContext().tbl_SM_Sales.Select(c => new {c.CustomerID, c.Credit}).Where(
                    c => c.Credit).Distinct().Count().ToString();
            jstxtCustomer4.Num32 = jstxtCustomer1.Num32 - jstxtCustomer2.Num32;
        }

    }
}
