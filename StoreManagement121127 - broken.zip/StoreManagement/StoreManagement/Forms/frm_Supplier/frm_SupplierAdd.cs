﻿using System;

namespace StoreManagement.Forms.frm_Supplier
{
    public partial class FrmSupplierAdd : Requirement.FrmPopup
    {
        public FrmSupplierAdd()
        {
            InitializeComponent();
        }

        private void JS7Btn2Click(object sender, EventArgs e)
        {
            Close();
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {
            new Requirement.SMLinqDataContext().JSP_SM_Suppliers_Add(jsTxtName.Text, jstxtAddress.Text,
                                                                     jstxtTel.Text, jstxtDesc.Text,
                                                                     jstxtVisitor.Text, jsTxtMobile.Text, DateTime.Now);
            Close();
        }

        private void JSTxtNameTextChanged(object sender, EventArgs e)
        {
            jS7BtnAdd.Enabled = !string.IsNullOrWhiteSpace(jsTxtName.Text);
        }
    }
}
