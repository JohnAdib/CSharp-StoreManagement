﻿namespace StoreManagement.Forms.frm_User
{
    partial class FrmUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmUser));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.jsPanel1 = new JSRequirement.Controls.JSPanel();
            this.btnReturn = new JSRequirement.Controls.JS7Btn();
            this.btnDelete = new JSRequirement.Controls.JS7Btn();
            this.btnUpdate = new JSRequirement.Controls.JS7Btn();
            this.btnAdd = new JSRequirement.Controls.JS7Btn();
            this.jsPanel2 = new JSRequirement.Controls.JSPanel();
            this.jsDataGrid1 = new JSRequirement.Controls.JSDataGrid();
            this.UserID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.UserCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NikName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.jsPanel1.SuspendLayout();
            this.jsPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // jsPanel1
            // 
            this.jsPanel1.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel1.Controls.Add(this.btnReturn);
            this.jsPanel1.Controls.Add(this.btnDelete);
            this.jsPanel1.Controls.Add(this.btnUpdate);
            this.jsPanel1.Controls.Add(this.btnAdd);
            this.jsPanel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.jsPanel1.Location = new System.Drawing.Point(0, 0);
            this.jsPanel1.Name = "jsPanel1";
            this.jsPanel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel1.Size = new System.Drawing.Size(140, 332);
            this.jsPanel1.TabIndex = 3;
            // 
            // btnReturn
            // 
            this.btnReturn.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Home;
            this.btnReturn.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnReturn.BackColor = System.Drawing.Color.Transparent;
            this.btnReturn.ButtonText = "بازگشت";
            this.btnReturn.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReturn.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.btnReturn.Image = ((System.Drawing.Image)(resources.GetObject("btnReturn.Image")));
            this.btnReturn.Location = new System.Drawing.Point(10, 276);
            this.btnReturn.Margin = new System.Windows.Forms.Padding(7);
            this.btnReturn.MinimumSize = new System.Drawing.Size(120, 40);
            this.btnReturn.Name = "btnReturn";
            this.btnReturn.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnReturn.Size = new System.Drawing.Size(120, 40);
            this.btnReturn.TabIndex = 3;
            this.btnReturn.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReturn.UseVisualStyleBackColor = false;
            this.btnReturn.Click += new System.EventHandler(this.JS7Btn4Click);
            // 
            // btnDelete
            // 
            this.btnDelete.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Delete;
            this.btnDelete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDelete.BackColor = System.Drawing.Color.Transparent;
            this.btnDelete.ButtonText = "حذف";
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.Location = new System.Drawing.Point(10, 222);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(7);
            this.btnDelete.MinimumSize = new System.Drawing.Size(120, 40);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnDelete.Size = new System.Drawing.Size(120, 40);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.JS7Btn3Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Update;
            this.btnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnUpdate.BackColor = System.Drawing.Color.Transparent;
            this.btnUpdate.ButtonText = "به روز رسانی";
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.btnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("btnUpdate.Image")));
            this.btnUpdate.Location = new System.Drawing.Point(10, 168);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(7);
            this.btnUpdate.MinimumSize = new System.Drawing.Size(120, 40);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnUpdate.Size = new System.Drawing.Size(120, 40);
            this.btnUpdate.TabIndex = 1;
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdate.UseVisualStyleBackColor = false;
            this.btnUpdate.Click += new System.EventHandler(this.BtnUpdateClick);
            // 
            // btnAdd
            // 
            this.btnAdd.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Add;
            this.btnAdd.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnAdd.BackColor = System.Drawing.Color.Transparent;
            this.btnAdd.ButtonText = "اضافه کردن";
            this.btnAdd.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.btnAdd.Image = ((System.Drawing.Image)(resources.GetObject("btnAdd.Image")));
            this.btnAdd.Location = new System.Drawing.Point(10, 114);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(7);
            this.btnAdd.MinimumSize = new System.Drawing.Size(120, 40);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.btnAdd.Size = new System.Drawing.Size(120, 40);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.BtnAddClick);
            // 
            // jsPanel2
            // 
            this.jsPanel2.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel2.Controls.Add(this.jsDataGrid1);
            this.jsPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsPanel2.Location = new System.Drawing.Point(140, 0);
            this.jsPanel2.Name = "jsPanel2";
            this.jsPanel2.Padding = new System.Windows.Forms.Padding(3);
            this.jsPanel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel2.Size = new System.Drawing.Size(309, 332);
            this.jsPanel2.TabIndex = 4;
            // 
            // jsDataGrid1
            // 
            this.jsDataGrid1.AllowUserToAddRows = false;
            this.jsDataGrid1.AllowUserToDeleteRows = false;
            this.jsDataGrid1.AllowUserToOrderColumns = true;
            this.jsDataGrid1.AllowUserToResizeRows = false;
            this.jsDataGrid1.BackgroundColor = System.Drawing.Color.White;
            this.jsDataGrid1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("B Mitra", 12F);
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.jsDataGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.jsDataGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.jsDataGrid1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.UserID,
            this.UserCode,
            this.NikName});
            this.jsDataGrid1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsDataGrid1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.jsDataGrid1.GridColor = System.Drawing.Color.LightGray;
            this.jsDataGrid1.JSCustomSetting = true;
            this.jsDataGrid1.Location = new System.Drawing.Point(3, 3);
            this.jsDataGrid1.MultiSelect = false;
            this.jsDataGrid1.Name = "jsDataGrid1";
            this.jsDataGrid1.RowHeadersVisible = false;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            this.jsDataGrid1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.jsDataGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.jsDataGrid1.Size = new System.Drawing.Size(303, 326);
            this.jsDataGrid1.TabIndex = 0;
            // 
            // UserID
            // 
            this.UserID.DataPropertyName = "UserID";
            this.UserID.HeaderText = "کد کاربر";
            this.UserID.Name = "UserID";
            this.UserID.Visible = false;
            // 
            // UserCode
            // 
            this.UserCode.DataPropertyName = "UserCode";
            this.UserCode.HeaderText = "نام کاربری";
            this.UserCode.MinimumWidth = 120;
            this.UserCode.Name = "UserCode";
            this.UserCode.Width = 120;
            // 
            // NikName
            // 
            this.NikName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.NikName.DataPropertyName = "NikName";
            this.NikName.HeaderText = "لقب";
            this.NikName.MinimumWidth = 100;
            this.NikName.Name = "NikName";
            // 
            // FrmUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(524, 332);
            this.Controls.Add(this.jsPanel2);
            this.Controls.Add(this.jsPanel1);
            this.FormTitle = "کاربران";
            this.Name = "FrmUser";
            this.Text = "سامانه مدیریت فروشگاه | کاربران";
            this.Controls.SetChildIndex(this.jsPanel1, 0);
            this.Controls.SetChildIndex(this.jsPanel2, 0);
            this.jsPanel1.ResumeLayout(false);
            this.jsPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.jsDataGrid1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSPanel jsPanel1;
        private JSRequirement.Controls.JS7Btn btnReturn;
        private JSRequirement.Controls.JS7Btn btnDelete;
        private JSRequirement.Controls.JS7Btn btnUpdate;
        private JSRequirement.Controls.JS7Btn btnAdd;
        private JSRequirement.Controls.JSPanel jsPanel2;
        private JSRequirement.Controls.JSDataGrid jsDataGrid1;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserID;
        private System.Windows.Forms.DataGridViewTextBoxColumn UserCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn NikName;
    }
}
