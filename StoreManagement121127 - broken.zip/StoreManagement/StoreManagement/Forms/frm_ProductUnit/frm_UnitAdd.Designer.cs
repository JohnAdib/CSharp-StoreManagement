﻿namespace StoreManagement.Forms.frm_ProductUnit
{
    partial class FrmUnitAdd
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmUnitAdd));
            this.jsGroupBox1 = new JSRequirement.Controls.JSGroupBox();
            this.jS7Btn2 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn1 = new JSRequirement.Controls.JS7Btn();
            this.jsTextBox1 = new JSRequirement.Controls.JSTextBox();
            this.jsGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsGroupBox1
            // 
            this.jsGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox1.Controls.Add(this.jS7Btn2);
            this.jsGroupBox1.Controls.Add(this.jS7Btn1);
            this.jsGroupBox1.Controls.Add(this.jsTextBox1);
            this.jsGroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.jsGroupBox1.Name = "jsGroupBox1";
            this.jsGroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox1.Size = new System.Drawing.Size(294, 157);
            this.jsGroupBox1.TabIndex = 0;
            this.jsGroupBox1.TabStop = false;
            this.jsGroupBox1.Text = "واحد شمارش جدید را وارد نمایید";
            // 
            // jS7Btn2
            // 
            this.jS7Btn2.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Close;
            this.jS7Btn2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn2.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn2.ButtonText = "بستن";
            this.jS7Btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn2.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn2.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn2.Image")));
            this.jS7Btn2.Location = new System.Drawing.Point(16, 101);
            this.jS7Btn2.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn2.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn2.Name = "jS7Btn2";
            this.jS7Btn2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn2.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn2.TabIndex = 2;
            this.jS7Btn2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn2.UseVisualStyleBackColor = false;
            this.jS7Btn2.Click += new System.EventHandler(this.JS7Btn2Click);
            // 
            // jS7Btn1
            // 
            this.jS7Btn1.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Add;
            this.jS7Btn1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn1.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn1.ButtonText = "اضافه کردن";
            this.jS7Btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn1.Enabled = false;
            this.jS7Btn1.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn1.Image = ((System.Drawing.Image)(resources.GetObject("jS7Btn1.Image")));
            this.jS7Btn1.Location = new System.Drawing.Point(150, 101);
            this.jS7Btn1.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn1.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn1.Name = "jS7Btn1";
            this.jS7Btn1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn1.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn1.TabIndex = 1;
            this.jS7Btn1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7Btn1.UseVisualStyleBackColor = false;
            this.jS7Btn1.Click += new System.EventHandler(this.JS7Btn1Click);
            // 
            // jsTextBox1
            // 
            this.jsTextBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsTextBox1.NumDouble = 0D;
            this.jsTextBox1.Location = new System.Drawing.Point(16, 45);
            this.jsTextBox1.MaxLength = 200;
            this.jsTextBox1.Name = "jsTextBox1";
            this.jsTextBox1.PersianText = true;
            this.jsTextBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsTextBox1.Size = new System.Drawing.Size(254, 30);
            this.jsTextBox1.TabIndex = 0;
            this.jsTextBox1.TextChanged += new System.EventHandler(this.JSTextBox1TextChanged);
            // 
            // FrmUnitAdd
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(294, 157);
            this.Controls.Add(this.jsGroupBox1);
            this.Name = "FrmUnitAdd";
            this.Text = "افزودن واحد شمارش";
            this.jsGroupBox1.ResumeLayout(false);
            this.jsGroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSGroupBox jsGroupBox1;
        private JSRequirement.Controls.JS7Btn jS7Btn2;
        private JSRequirement.Controls.JS7Btn jS7Btn1;
        private JSRequirement.Controls.JSTextBox jsTextBox1;
    }
}
