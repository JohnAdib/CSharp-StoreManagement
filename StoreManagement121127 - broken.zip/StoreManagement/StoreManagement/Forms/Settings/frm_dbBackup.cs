﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Threading;
using Microsoft.Win32;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Management.Common;

namespace StoreManagement.Forms.Settings
{
    public partial class FrmDBBackup : Requirement.JSfrmBase
    {
        Server _srv;
        ServerConnection _conn;

        public FrmDBBackup()
        {
            InitializeComponent();
        }

        private void FrmMainLoad(object sender, EventArgs e)
        {
            var rk = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Microsoft SQL Server");
            if (rk != null)
            {
                var instances = (String[])rk.GetValue("InstalledInstances");
                if (instances.Length > 0)
                {
                    foreach (var element in instances)
                    {
                        if (element == "MSSQLSERVER")
                            lstLocalInstances.Items.Add(Environment.MachineName);
                        else
                            lstLocalInstances.Items.Add(Environment.MachineName + @"\" + element);
                    }
                }
            }

            var threadGetNetworkInstances = new Thread(GetNetworkInstances);
            threadGetNetworkInstances.Start();

        }

        private void BtnConnectClick(object sender, EventArgs e)
        {
            try
            {
                ddlDatabase.Items.Clear();

                string sqlSErverInstance = tabServers.SelectedIndex == 0 ? lstLocalInstances.SelectedItem.ToString() : lstNetworkInstances.SelectedItem.ToString();

                _conn = chkWindowsAuthentication.Checked ? new ServerConnection {ServerInstance = sqlSErverInstance} : new ServerConnection(sqlSErverInstance, txtLogin.Text, txtPassword.Text);
                _srv = new Server(_conn);

                foreach (Database db in _srv.Databases)
                {
                    ddlDatabase.Items.Add(db.Name);
                }
            }
            catch (Exception err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void BtnBrowseClick(object sender, EventArgs e)
        {
            var openFileDialog1 = new OpenFileDialog
                                      {
                                          InitialDirectory = "c:\\",
                                          Filter = @"bak files (*.bak)|*.txt|All files (*.*)|*.*",
                                          FilterIndex = 2,
                                          RestoreDirectory = true
                                      };


            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                txtFileName.Text = openFileDialog1.FileName;

            }
        }

        private void TxtFileNameTextChanged(object sender, EventArgs e)
        {

        }

        private void BtnBackupDBClick(object sender, EventArgs e)
        {
            var bkp = new Backup();

            Cursor = Cursors.WaitCursor;
            dataGridView1.DataSource = string.Empty;
            try
            {
                string fileName = txtFileName.Text;
                string databaseName = ddlDatabase.SelectedItem.ToString();

                bkp.Action = BackupActionType.Database;
                bkp.Database = databaseName;
                bkp.Devices.AddDevice(fileName, DeviceType.File);
                bkp.Incremental = chkIncremental.Checked;
                progressBar1.Value = 0;
                progressBar1.Maximum = 100;
                progressBar1.Value = 10;

                bkp.PercentCompleteNotification = 10;
                bkp.PercentComplete += ProgressEventHandler;

                bkp.SqlBackup(_srv);
                MessageBox.Show(@"Database Backed Up To: " + fileName, @"SMO Demos");
            }
            
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                Cursor = Cursors.Default;
                progressBar1.Value = 0;
            }
        }

        public void ProgressEventHandler(object sender, PercentCompleteEventArgs e)
        {
            progressBar1.Value = e.Percent;
        }

        private void BtnRestoreClick(object sender, EventArgs e)
        {
            var res = new Restore();

            Cursor = Cursors.WaitCursor;
            dataGridView1.DataSource = string.Empty;

            try
            {
                string fileName = txtFileName.Text;
                string databaseName = ddlDatabase.SelectedItem.ToString();

                res.Database = databaseName;
                res.Action = RestoreActionType.Database;
                res.Devices.AddDevice(fileName, DeviceType.File);

                progressBar1.Value = 0;
                progressBar1.Maximum = 100;
                progressBar1.Value = 10;

                res.PercentCompleteNotification = 10;
                res.ReplaceDatabase = true;
                res.PercentComplete += ProgressEventHandler;
                res.SqlRestore(_srv);

                MessageBox.Show(@"Restore of " + databaseName + @" Complete!", @"Restore",MessageBoxButtons.OK,MessageBoxIcon.Information);
            }
            catch (SmoException exSmo)
            {
                MessageBox.Show(exSmo.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                Cursor = Cursors.Default;
                progressBar1.Value = 0;
            }
        }

        private void BtnBackupLogClick(object sender, EventArgs e)
        {
            var bkp = new Backup();

            Cursor = Cursors.WaitCursor;
            dataGridView1.DataSource = "";

            try
            {
                string strFileName = txtFileName.Text;
                string strDatabaseName = ddlDatabase.SelectedItem.ToString();

                bkp.Action = BackupActionType.Log;
                bkp.Database = strDatabaseName;

                bkp.Devices.AddDevice(strFileName, DeviceType.File);
                progressBar1.Value = 0;
                progressBar1.Maximum = 100;
                progressBar1.Value = 10;

                bkp.PercentCompleteNotification = 10;
                bkp.PercentComplete += ProgressEventHandler;

                bkp.SqlBackup(_srv);
                MessageBox.Show(@"Log Backed Up To: " + strFileName, @"SMO Demos");
            }
            catch (SmoException exSmo)
            {
                MessageBox.Show(exSmo.ToString());

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            finally
            {
                Cursor = Cursors.Default;
                progressBar1.Value = 0;
            }
        }

        private void BtnVerifyClick(object sender, EventArgs e)
        {
            var rest = new Restore();
            string fileName = txtFileName.Text;

            Cursor = Cursors.WaitCursor;
            dataGridView1.DataSource = string.Empty;

            try
            {
                rest.Devices.AddDevice(fileName, DeviceType.File);
                bool verifySuccessful = rest.SqlVerify(_srv);

                if (verifySuccessful)
                {
                    MessageBox.Show(@"Backup Verified!", @"SMO Demos");
                    DataTable dt = rest.ReadFileList(_srv);
                    dataGridView1.DataSource = dt;
                }
                else
                {
                    MessageBox.Show(@"Backup NOT Verified!", @"SMO Demos");
                }
            }
            catch (SmoException exSmo)
            {
                MessageBox.Show(exSmo.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                Cursor = Cursors.Default;
            }
        }

        delegate void SetMessageCallback(string text);

        private void AddNetworkInstance(string text)
        {
            if (lstNetworkInstances.InvokeRequired)
            {
                var d = new SetMessageCallback(AddNetworkInstance);
                BeginInvoke(d, new object[] { text });
            }
            else
            {
                lstNetworkInstances.Items.Add(text);
            }
        }

        private void GetNetworkInstances()
        {
            DataTable dt = SmoApplication.EnumAvailableSqlServers(false);

            if (dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    AddNetworkInstance(dr["Name"].ToString());
                }
            }
        }

        private void ChkWindowsAuthenticationCheckedChanged(object sender, EventArgs e)
        {
            txtLogin.Enabled = !chkWindowsAuthentication.Checked;
            txtPassword.Enabled = !chkWindowsAuthentication.Checked;
        }


    }
}

