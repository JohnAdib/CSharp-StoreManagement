﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace StoreManagement.Forms.frm_Product
{
    public partial class FrmProduct : Requirement.JSfrmBase
    {
        public FrmProduct()
        {
            InitializeComponent();
            jsCmbCategory.DataSource = new Requirement.SMLinqDataContext().View_SM_UsedCategories;
            jsCmbCategory.DisplayMember = "ProductCategory";
            jsCmbCategory.ValueMember = "ProductCategoryID";
            jsCmbCategory.SelectedValue = 0;
            UpdateDateGrid();
        }

        bool _initializement = true;
        string _totalRowsCount = "";
        public void UpdateDateGrid(bool filterByCategory = false)
        {
            if (_initializement)
            {
                jsDataGrid1.DataSource = new Requirement.SMLinqDataContext().View_SM_Products;

                _totalRowsCount = jsDataGrid1.Rows.Count.ToString();
                jscDataDesc.Text = @".در مجموع " + _totalRowsCount + @" قلم کالا ثبت شده است";

                _initializement = false;
            }
            else
            {
                int userSelectedRow = jsDataGrid1.CurrentCellAddress.Y;
                int categoryID = jsCmbCategory.SValue;
                if (filterByCategory && categoryID != 0)
                {
                    var db =
                        new Requirement.SMLinqDataContext().View_SM_Products.Where(
                            c => c.ProductCategoryID == categoryID);

                    if (db.Count() > 0)
                    {
                        jsDataGrid1.DataSource =
                            new Requirement.SMLinqDataContext().View_SM_Products.Where(
                                c => c.ProductCategoryID == categoryID);

                        jscDataDesc.Text = @".در مجموع " + _totalRowsCount + @" قلم کالا ثبت شده است؛ که "
                            + jsDataGrid1.Rows.Count + @" مورد آن در دسته ی " + jsCmbCategory.Text + @" قرار دارد";
                    }
                    else
                        MessageBox.Show(@"کالایی در این دسته وجود ندارد", @"خطا");
                }
                else
                {
                    jsDataGrid1.DataSource = new Requirement.SMLinqDataContext().View_SM_Products;
                    jscDataDesc.Text = @".در مجموع " + _totalRowsCount + @" قلم کالا ثبت شده است";
                }

                if (userSelectedRow > 0)
                {
                    if (userSelectedRow < jsDataGrid1.Rows.Count) jsDataGrid1.CurrentCell = jsDataGrid1["PName", userSelectedRow];
                    //jscDataGrid1.Rows[userSelectedRow].Selected = true;
                    else jsDataGrid1.Rows[jsDataGrid1.Rows.Count - 1].Selected = true;

                }
            }

            
        }

        private void JS7BtnAddClick(object sender, EventArgs e)
        {
            if (JSBarcode != null && JSBarcode.Length > 3) new FrmProductAdd {jsBarCodeBox1 = {Text = JSBarcode}}.ShowDialog();
            else new FrmProductAdd().ShowDialog();
            UpdateDateGrid();
        }

        private void JS7BtnUpdateClick(object sender, EventArgs e)
        {
            if (jsDataGrid1.CurrentRow != null) new FrmProductEdit(jsDataGrid1.CurrentRow).ShowDialog();
            UpdateDateGrid();
        }

        private void JS7BtnDelClick(object sender, EventArgs e)
        {
            try
            {
                if (jsDataGrid1.CurrentRow == null)
                    return;

                var pid = Convert.ToInt16(jsDataGrid1.CurrentRow.Cells["ProductID"].Value);
                if (new Requirement.SMLinqDataContext().tbl_SM_SalesDetails.Where(c => c.ProductID == pid).Count() > 0)
                {
                    MessageBox.Show(@"از این کالا فروخته ایم!" + Environment.NewLine
                                    + @"برای حذف واحد ابتدا فروش های مربوط به این کالا را پاک نمایید",
                                    @"توجه"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }

                if (
                    MessageBox.Show(Properties.Settings.Default.AppMsgDelete, @"حذف", MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Question) ==DialogResult.No)
                    return;

                new Requirement.SMLinqDataContext().JSP_SM_Products_Delete(pid);
                UpdateDateGrid();
            }
            catch
            {
                MessageBox.Show(@"خطایی در حذف رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void JS7BtnHomeClick(object sender, EventArgs e)
        {
            Close();
        }

        private void JSLabel1Click(object sender, EventArgs e)
        {
            jsCmbCategory.SelectedValue = 0;
        }

        private void JSCmbCategorySelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateDateGrid(true);
        }

        private void FrmProductBarcodeTaken(object sender, EventArgs e)
        {
            var barcodeExist = false;
            foreach (DataGridViewRow r in jsDataGrid1.Rows)
            {
                if (r.Cells["PBarCode"].Value == null) continue;
                if (r.Cells["PBarCode"].Value.ToString() == JSBarcode)
                {
                    //jsCmbCategory.SelectedValue = r.Cells["ProductCategoryID"].Value;
                    jsDataGrid1.CurrentCell = jsDataGrid1["PName", r.Index];
                    jscDataDesc.Text = @". این بارکد برای کالایی با نام " + r.Cells["PName"].Value + @" ثبت گردیده است";
                    barcodeExist = true;
                }

                if (r.Cells["PBarCode2"].Value == null) continue;
                if (r.Cells["PBarCode2"].Value.ToString() == JSBarcode)
                {
                    //jsCmbCategory.SelectedValue = r.Cells["ProductCategoryID"].Value;
                    jsDataGrid1.CurrentCell = jsDataGrid1["PName", r.Index];
                    jscDataDesc.Text = @". این بارکد برای کالایی با نام " + r.Cells["PName"].Value + @" ثبت گردیده است";
                    barcodeExist = true;
                }
            }

            if (barcodeExist)
            {
                JS7BtnUpdateClick(null, null);
            }
            else
            {
                JS7BtnAddClick(null, null);
                jscDataDesc.Text = @". کالایی با این بارکد ثبت نشده است";
            }

        }

        private void FrmProductKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete) JS7BtnDelClick(null, null);
            if (e.KeyCode == Keys.F2) JS7BtnUpdateClick(null, null);
            if (e.KeyCode == Keys.F4 && e.Alt == false) JS7BtnAddClick(null, null);
            if (e.KeyCode == Keys.Escape) JS7BtnHomeClick(null, null);
        }
    }
}
