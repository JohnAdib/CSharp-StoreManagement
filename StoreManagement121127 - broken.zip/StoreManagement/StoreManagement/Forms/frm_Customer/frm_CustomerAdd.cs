﻿using System;

namespace StoreManagement.Forms.frm_Customer
{
    public partial class FrmCustomerAdd : Requirement.FrmPopup
    {
        public FrmCustomerAdd()
        {
            InitializeComponent();
        }

        private void JS7Btn2Click(object sender, EventArgs e)
        {
            Close();
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {
            new Requirement.SMLinqDataContext().JSP_SM_Customers_Add(jstxtCName.Text, jstxtAddress.Text,
                                                                     jstxtTel.Text, jstxtMobile.Text,
                                                                     jsChkCredit.Checked, 0, DateTime.Now);
            Close();
        }

        private void JstxtCNameTextChanged(object sender, EventArgs e)
        {
            jS7BtnAdd.Enabled = !string.IsNullOrWhiteSpace(jstxtCName.Text);
        }
    }
}
