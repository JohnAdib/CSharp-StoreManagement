﻿using System;
using System.Drawing;
using JSRequirement.Codes;

namespace StoreManagement.Forms.frm_User
{
    public partial class FrmUserAdd : Requirement.FrmPopup
    {
        public FrmUserAdd()
        {
            InitializeComponent();
            cmbQuestion.DataSource = new Requirement.SMLinqDataContext().tbl_DB_UsersQuestions;
            cmbQuestion.DisplayMember = "Question";
            cmbQuestion.ValueMember = "QuestionID";
        }

        private void  BtnCloseClick(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnAddClick(object sender, EventArgs e)
        {
            if (txtUserCode.TxtEmpty || txtpasscode.TxtEmpty || txtpasscodeconfirm.TxtEmpty || txtNicName.TxtEmpty)
            {
                txtUserCode.BackColor = Color.Red;
                txtpasscode.BackColor = Color.Red;
                txtpasscodeconfirm.BackColor = Color.Red;
                txtNicName.BackColor = Color.Red;
                return;
            }
            if (txtpasscode.Text != txtpasscodeconfirm.Text)
            {
                txtpasscode.BackColor = Color.Red;
                txtpasscodeconfirm.BackColor = Color.Red;
                return;
            }

            new Requirement.SMLinqDataContext().JSP_DB_Users_Add(txtUserCode.Text,
                                                                 JSSaltHashing.ComputeHash(txtpasscode.Text,
                                                                                           txtUserCode.Text),
                                                                 txtNicName.Text,
                                                                 false, cmbQuestion.SValueByte, txtAnswer.Text,
                                                                 txtFName.Text, txtLName.Text, txtBirthDate.Value,
                                                                 txtEmail.Text, txtDesc.Text, 0, true, DateTime.Now);

            Close();
        }

        private void TxtpasscodeKeyDown(object sender, System.Windows.Forms.KeyEventArgs e)
        {
            txtpasscodeconfirm.Visible = true;
            lblPassCodeConfirm.Visible = true;
        }
    }
}
