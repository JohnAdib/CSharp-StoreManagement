﻿using System;
using System.Windows.Forms;
using Microsoft.Win32;

namespace StoreManagement.Forms.Settings
{
    public partial class FrmAppSettings : Requirement.JSfrmBase
    {
        public FrmAppSettings()
        {
            InitializeComponent();
            try
            {
                jsCmbDefaultUserCode.DataSource = new Requirement.SMLinqDataContext().tbl_DB_Users;
                jsCmbDefaultUserCode.DisplayMember = "NikName";
                jsCmbDefaultUserCode.ValueMember = "UserCode";

                jsCmbDefaultProduct.DataSource = new Requirement.SMLinqDataContext().tbl_SM_Products;
                jsCmbDefaultProduct.DisplayMember = "PName";
                jsCmbDefaultProduct.ValueMember = "ProductID";

                jsCmbDefaultCustomer.DataSource = new Requirement.SMLinqDataContext().tbl_SM_Customers;
                jsCmbDefaultCustomer.DisplayMember = "CName";
                jsCmbDefaultCustomer.ValueMember = "CustomerID";


                // read setting from system properties
                jsTxtAppname.Text = Properties.Settings.Default.AppName;
                jstxtMaxReview.Text = Properties.Settings.Default.Sales_MaxReview.ToString();
                jsTxtAppLoginTryCount.Text = Properties.Settings.Default.AppLoginTryCount.ToString();


                if (Properties.Settings.Default.AppLoginDefaultUser != null)
                    jsCmbDefaultUserCode.SelectedValue = Properties.Settings.Default.AppLoginDefaultUser;

                if (Properties.Settings.Default.Sales_DefaultProduct != null)
                    jsCmbDefaultProduct.SelectedValue = Convert.ToInt16(Properties.Settings.Default.Sales_DefaultProduct);

                if (Properties.Settings.Default.Sales_DefaultCustomer != null)
                    jsCmbDefaultCustomer.SelectedValue = Convert.ToInt16(Properties.Settings.Default.Sales_DefaultCustomer);


                var rk = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\\",false);
                if (rk != null)
                    jsChkStartupRun.Checked = rk.GetValue(Application.ProductName, "Not Exist").ToString() !=
                                              "Not Exist";
            }
            catch (Exception)
            {
                MessageBox.Show(@"خطایی در بارگزاری تنظیمات رخ داده است",@"خطا");
                return;
            }
        }


        private void JSChkStartupRunCheckedChanged(object sender, EventArgs e)
        {
            try
            {
                var rk = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run", true);
                //Registry.LocalMachine.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true);
                if (rk != null)
                {
                    if (jsChkStartupRun.Checked)
                        rk.SetValue(Application.ProductName, Application.ExecutablePath);
                    else
                        rk.DeleteValue(Application.ProductName, false);
                }
            }
            catch(Exception ex )
            {
                MessageBox.Show(ex.Source, @"خطا در تغییر وضعیت اجرای خودکار نرم افزار");
            }
        }

        private void BtnCloseClick(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnUpdateClick(object sender, EventArgs e)
        {
            try
            {
                Properties.Settings.Default.AppName = jsTxtAppname.Text;
                Properties.Settings.Default.AppLoginTryCount = jsTxtAppLoginTryCount.NumByte;
                Properties.Settings.Default.AppLoginDefaultUser = jsCmbDefaultUserCode.SelectedValue.ToString();
                Properties.Settings.Default.Sales_DefaultProduct = jsCmbDefaultProduct.SValue.ToString();
                Properties.Settings.Default.Sales_DefaultCustomer = jsCmbDefaultCustomer.SValue.ToString();
                Properties.Settings.Default.Sales_MaxReview = jstxtMaxReview.Num16;
                
                Properties.Settings.Default.Save();

                Program.AppTitle = Properties.Settings.Default.AppNamePre + @" " + Properties.Settings.Default.AppName;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, @"خطا");
                return;
            }
            Close();
        }
    }
}
