﻿using System;
using System.Windows.Forms;
using System.Linq;

namespace StoreManagement.Forms.frm_ProductCategory
{
    public partial class FrmCategory : Requirement.JSfrmBase
    {
        public FrmCategory()
        {
            InitializeComponent();
            UpdateDateGrid();
        }

        public void UpdateDateGrid()
        {
            jsDataGrid1.DataSource = new Requirement.SMLinqDataContext().tbl_SM_ProductsCategories;
        }

        private void JS7BtnAddClick(object sender, EventArgs e)
        {
            new FrmCategoryAdd().ShowDialog();
            UpdateDateGrid();
        }

        private void JS7BtnDelClick(object sender, EventArgs e)
        {
            try
            {
                if (jsDataGrid1.CurrentRow == null)
                    return;

                var cid = Convert.ToInt16(jsDataGrid1.CurrentRow.Cells["ProductCategoryID"].Value);
                if (new Requirement.SMLinqDataContext().tbl_SM_Products.Where(c => c.ProductCategoryID == cid).Count() > 0)
                {
                    MessageBox.Show(@"از این دسته بندی در محصولات استفاده شده است" + Environment.NewLine
                                    + @"برای حذف واحد ابتدا محصولاتی که از دسته بندی استفاده نموده اند را تصحیح فرمایید",
                                    @"توجه"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }

                if (
                    MessageBox.Show(Properties.Settings.Default.AppMsgDelete, @"حذف", MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Question) == DialogResult.No)
                    return;

                new Requirement.SMLinqDataContext().JSP_SM_ProductsCategory_Delete(cid);
                UpdateDateGrid();
            }
            catch (Exception)
            {
                MessageBox.Show(@"خطایی در حذف رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void JS7BtnHomeClick(object sender, EventArgs e)
        {
            Close();
        }

        private void JS7BtnUpdateClick(object sender, EventArgs e)
        {
            try
            {
                if (jsDataGrid1.CurrentRow == null)
                    return;
                new FrmCategoryEdit(
                    Convert.ToInt16(jsDataGrid1.CurrentRow.Cells["ProductCategoryID"].Value),
                    jsDataGrid1.CurrentRow.Cells["ProductCategory"].Value.ToString()
                    ).ShowDialog();
                UpdateDateGrid();
            }
            catch
            {
                MessageBox.Show(@"خطایی در ویرایش رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
    }
}
