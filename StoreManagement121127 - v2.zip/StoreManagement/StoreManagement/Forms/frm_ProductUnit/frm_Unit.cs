﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace StoreManagement.Forms.frm_ProductUnit
{
    public partial class FrmUnit : Requirement.JSfrmBase
    {
        public FrmUnit()
        {
            InitializeComponent();
            UpdateDateGrid();
        }

        public void UpdateDateGrid()
        {
            jsDataGrid1.DataSource = new Requirement.SMLinqDataContext().tbl_SM_ProductsUnits;
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {
            new FrmUnitAdd().ShowDialog();
            UpdateDateGrid();
        }
        private void JS7Btn2Click(object sender, EventArgs e)
        {
            try
            {
                if (jsDataGrid1.CurrentRow == null)
                    return;
                new FrmUnitEdit(
                    Convert.ToByte(jsDataGrid1.CurrentRow.Cells["ProductsUnitID"].Value),
                    jsDataGrid1.CurrentRow.Cells["ProductsUnit"].Value.ToString()
                    ).ShowDialog();
                UpdateDateGrid();
            }
            catch
            {
                MessageBox.Show(@"خطایی در ویرایش رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void JS7Btn3Click(object sender, EventArgs e)
        {
            try
            {
                if (jsDataGrid1.CurrentRow == null)
                    return;

                var uid = Convert.ToByte(jsDataGrid1.CurrentRow.Cells["ProductsUnitID"].Value);
                if (new Requirement.SMLinqDataContext().tbl_SM_Products.Where(c => c.ProductsUnitID == uid).Count() > 0)
                {
                    MessageBox.Show(@"از این واحد در کالاها استفاده شده است" + Environment.NewLine
                                    + @"برای حذف واحد ابتدا کالاهایی که از این واحد استفاده نموده اند را تصحیح فرمایید",
                                    @"توجه"
                                    , MessageBoxButtons.OK, MessageBoxIcon.Hand);
                    return;
                }

                if (
                    MessageBox.Show(Properties.Settings.Default.AppMsgDelete, @"حذف", MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Question) == DialogResult.No)
                    return;

                new Requirement.SMLinqDataContext().JSP_SM_ProductsUnits_Delete(uid);
                UpdateDateGrid();
            }
            catch (Exception)
            {
                MessageBox.Show(@"خطایی در حذف رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void JS7Btn4Click(object sender, EventArgs e)
        {
            Close();
        }


    }
}
