﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

namespace StoreManagement.Requirement
{
    public partial class JSfrmBase : JSRequirement.Forms.JSBaseForm
    {
        public JSfrmBase()
        {
            InitializeComponent();
            jsMenuStripStoreManagement1.ParentForm = this;
            BringToFront();
        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            try
            {
                if (Owner != null) Owner.Hide();
                if (!DesignMode) CenterForm();

                Activate();
                BringToFront();
                Focus();
            }
            catch{return;}
        }
        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            try
            {
                if (Forms.FrmHome.Instance != null && !Forms.FrmHome.Instance.Visible)
                {
                    if (Forms.FrmHome.LoadedForm == 0)
                    {
                        Forms.FrmHome.Instance.Visible = false;
                        Forms.FrmHome.Instance.Show();
                    }
                }
            }
            catch{return;}
        }
        private void CenterForm()
        {
            var center = new Point
            {
                X = (Screen.PrimaryScreen.WorkingArea.Width - Width) / 2,
                Y = (Screen.PrimaryScreen.WorkingArea.Height - Height) / 2
            };

            Location = center;
        }

        private string _frmTitle;
        /// <summary>
        /// current form title for showing on title bar.
        /// </summary>
        [Category("JSCustomizer"),
         Description("The text that is displayed on form title bar.")]
        public string FormTitle
        {
            get { return _frmTitle; }
            set
            {
                try
                {
                    _frmTitle = value;
                    Invalidate();
                    var appPreName = Properties.Settings.Default.AppNamePre + @" " + Properties.Settings.Default.AppName;
                    
                    if(_frmTitle.Length < 3)
                    {
                        base.Text = appPreName;
                    }
                    else
                    {
                        base.Text = appPreName + @" | " + _frmTitle;
                    }
                }
                catch
                {
                    return;
                }
            }
        }


        [Category("JSCustomizer"), Description("Raise Event when user input barcode.")]
        public event EventHandler BarcodeTaken;
        protected virtual void OnBarcodeTaken(EventArgs e)
        {
            if (BarcodeTaken != null)
                BarcodeTaken(this, e);
        }

        /// <summary>
        /// Give barcode from user and save it.
        /// </summary>
        [Category("JSCustomizer"), Description("Give barcode from user and save it.")]
        public string JSBarcode { get; protected set; }



        [Category("JSCustomizer"), Description("Raise Event when user input number.")]
        public event EventHandler NumberTaken;
        protected virtual void OnNumberTaken(EventArgs e)
        {
            if (NumberTaken != null)
                NumberTaken(this, e);
        }

        [Category("JSCustomizer"), Description("Raise Event when user input number.")]
        public event EventHandler OneNumTaken;
        protected virtual void OnOneNumTaken(EventArgs e)
        {
            if (OneNumTaken != null)
                OneNumTaken(this, e);
        }

        /// <summary>
        /// Give Number from user and save it.
        /// </summary>
        [Category("JSCustomizer"), Description("Give Number from user and save it.")]
        public int JSNumber { get; set; }


        private bool _isBarCode;
        private bool _isAddStatus;
        private string _barcode = string.Empty;

        private void JSfrmBaseKeyPress(object sender, KeyPressEventArgs e)
        {
            try
            {
                if (e.KeyChar == '$')
                {
                    try
                    {
                        InputLanguage.CurrentInputLanguage =
                            InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-us"));
                    }
                    catch
                    {
                        return;
                    }

                    _isBarCode = !_isBarCode;
                    e.Handled = true; // dont show any char to user
                    if (_isBarCode) return; // if start reading barcode, don't continue

                    if (_barcode.Length > 3) // if barcode len > 3
                    {
                        JSBarcode = _barcode;
                        BarcodeTaken(this, e);
                        _barcode = string.Empty;
                    }
                    try
                    {
                        InputLanguage.CurrentInputLanguage =
                            InputLanguage.FromCulture(new System.Globalization.CultureInfo("fa-ir"));
                    }
                    catch
                    {
                        return;
                    }
                }
                else if (_isBarCode)
                {
                    _barcode += e.KeyChar; // give barcode char by char
                    e.Handled = true; // dont show any char to user
                }
                //for add number to datagridview
                else if (e.KeyChar == '+')
                {
                    e.Handled = true;
                    if (_isAddStatus)
                    {
                        // raise event NumberTaken
                        NumberTaken(this, e);

                    }
                    else
                    {
                        // event when in starting to add
                        _isAddStatus = true;
                    }
                }
                else if (e.KeyChar == '=' && _isAddStatus)
                {
                    e.Handled = true;
                    _isAddStatus = false;
                    NumberTaken(this, e);
                }
                else if (_isAddStatus && !(e.KeyChar < 48 || e.KeyChar > 57))
                {
                    e.Handled = true;
                    if (JSNumber.ToString().Length >= 9) return;
                    JSNumber *= 10;
                    JSNumber += Convert.ToInt32(e.KeyChar.ToString());
                    OneNumTaken(this, e);
                }
                else if (_isAddStatus && e.KeyChar == 8)
                {
                    // minus
                    JSNumber /= 10;
                    OneNumTaken(this, e);
                }
            }
            catch(Exception ex)
            {
                if( !DesignMode) MessageBox.Show(ex.Message);
                else MessageBox.Show(@"خطا در خواندن اطلاعات از ورودی", @"سامانه مدیریت سوپر مارکت");
                return;
            }
        }

        private void JSfrmBaseLoad(object sender, EventArgs e)
        {
                //Text = Properties.Settings.Default.AppNamePre + @" " + Properties.Settings.Default.AppName;
        }
    }
}