﻿using System;
using System.Windows.Forms;
using StoreManagement.Forms;
using StoreManagement.Forms.Security;

namespace StoreManagement
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Reports.FrmRptTest());

            try
            {
                var frmLogin = new FrmLogin();
                if (frmLogin.ShowDialog() == DialogResult.OK)
                {
                    Application.Run(new FrmHome(frmLogin.UserName));
                }
                
            }
            catch(Exception ex )
            {
                MessageBox.Show(ex.Message, @"خطا");
                return;
            }

        }
    }
}
