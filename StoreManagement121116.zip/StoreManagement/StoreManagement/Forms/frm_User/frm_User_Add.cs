﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace StoreManagement.Forms.frm_User
{
    public partial class frm_User_Add : StoreManagement.Requirement.FrmPopup
    {
        public frm_User_Add()
        {
            InitializeComponent();
        }
    }
}
