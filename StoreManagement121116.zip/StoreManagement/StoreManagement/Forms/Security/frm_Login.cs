﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using JSRequirement.Codes;
using System.Runtime.InteropServices;

namespace StoreManagement.Forms.Security
{

    public partial class FrmLogin : Form
    {
        public string UserName;
        public string UserFullName;
        private readonly bool _connectFailed;
        int _appLoginTryCount = Properties.Settings.Default.AppLoginTryCount;

        public FrmLogin()
        {
            InitializeComponent();
            btnSubmit.Enabled = false;
            try
            {
                cmbUserCode.DataSource = new Requirement.SMLinqDataContext().tbl_DB_Users;
                cmbUserCode.DisplayMember = "NikName";
                cmbUserCode.ValueMember = "UserCode";
                cmbUserCode.SelectedValue = Properties.Settings.Default.AppLoginDefaultUser;
                jslblAppLoginTryCount.Text =@"(شما " + _appLoginTryCount.ToString() + @" شانس دیگر دارید!)";
                AcceptButton = btnSubmit;
                var pc = new System.Globalization.PersianCalendar();
                jslblToday.Text = pc.GetYear(DateTime.Now) + @" /" + pc.GetMonth(DateTime.Now)
                                    + @" /" + pc.GetDayOfMonth(DateTime.Now);
            }
            catch (Exception)
            {
                _connectFailed = true;
                MessageBox.Show(@"خطا در ارتباط با دیتابیس - لطفا با مدیر تماس بگیرید"
                    + Environment.NewLine + @"تلفن تماس: 09357269759", @"خطا");
                cmbUserCode.Enabled = false;
                txtPassCode.Enabled = false;
                return;
            }
        }

        private void BtnQuitClick(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void CmbUserCodeSelectionChangeCommitted(object sender, EventArgs e)
        {
            txtPassCode.Text = "";
        }

        private void TxtPassCodeTextChanged(object sender, EventArgs e)
        {
            btnSubmit.Enabled = txtPassCode.Text != "";
        }

        private void CmbUserCodeKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
                txtPassCode.Focus();
        }

        static int _index;
        string _animtext = @"به سامانه مدیریت فروشگاه خوش آمدید..";
        private void JSTimer1Tick(object sender, EventArgs e)
        {
            if (_index >= _animtext.Length + 1)
            {
                _index = 0;
                jsTimer1.Enabled = false;
                return;
            }
            jscMessage.Text = _animtext.Substring(0, _index) + @".";
            _index++;

        }

        private void BtnSubmitClick(object sender, EventArgs e)
        {
            if (_connectFailed) return;
            _appLoginTryCount -= 1;
            string userMsg = null;
            try
            {
                var user = (from u in new Requirement.SMLinqDataContext().tbl_DB_Users
                            where u.UserCode.Equals(cmbUserCode.SelectedValue.ToString())
                            select u).FirstOrDefault();

                if (user == null)
                {
                    // Invalid user name
                    userMsg = @"خطا: نام کاربری انتخاب شده وجود ندارد";

                }
                else if (JSSaltHashing.VerifyHash(user.PassCode,
                            JSSaltHashing.ComputeHash(txtPassCode.Text, cmbUserCode.SelectedValue.ToString())))
                {
                    // Invalid password
                    userMsg = @"خطا: کلمه عبور را اشتباه وارد نمودید";
                }
                else if (user.Status != true)
                {
                    // User inactive
                    userMsg =@"متاسفیم، کاربر انتخاب شده اجازه ی ورود به سامانه را ندارد";
                }
                else
                {
                    Close();
                    UserName = cmbUserCode.SelectedValue.ToString();
                    //Properties.Settings.Default.AppLoginedUser = UserName;
                    Properties.Settings.Default.Save();
                    
                    _appLoginTryCount = Properties.Settings.Default.AppLoginTryCount; // reset try count on successful login
                    userMsg = @"ورود با موفقیت به انجام رسید";
                    jsTimer1.Enabled = false;
                    // Success
                    DialogResult = DialogResult.OK;
                }
            }
            catch (Exception)
            {
                MessageBox.Show(@"خطا در ورود به سامانه - لطفا با مدیر تماس بگیرید", @"تلفن تماس: 09357269759");
                return;
            }
            finally
            {
                //MessageBox.Show(userMsg, @"خطا در ورود به سامانه");
                _animtext = userMsg;
                jscMessage.ForeColor = Color.OrangeRed; 
                jsTimer1.Enabled = true;
                jslblAppLoginTryCount.Text = @"(شما " + _appLoginTryCount.ToString() + @" شانس دیگر دارید!)";

                txtPassCode.Text = "";
            }

            if (_appLoginTryCount < 1)
            {
                cmbUserCode.Enabled = false;
                txtPassCode.Enabled = false;
                btnSubmit.Enabled = false;
                jslblAppLoginTryCount.Text = @"(شما شانس دیگری ندارید!)";
                _animtext = @"متاسفانه شما اجازه  تلاش دیگری را ندارید!";
                jsTimer1.Enabled = true;
            }

        }


        // move windows form with mouse left click and drag to new point
        public const int WmNclbuttondown = 0xA1;
        public const int HtCaption = 0x2;
        [DllImportAttribute("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int msg, int wParam, int lParam);
        [DllImportAttribute("user32.dll")]
        public static extern bool ReleaseCapture();
        private void FrmLoginMouseDown(object sender, MouseEventArgs e)
        {
            try
            {
                if (e.Button == MouseButtons.Left)
                {
                    ReleaseCapture();
                    SendMessage(Handle, WmNclbuttondown, HtCaption, 0);
                }
            }
            catch { return; }
        }
    }
}
