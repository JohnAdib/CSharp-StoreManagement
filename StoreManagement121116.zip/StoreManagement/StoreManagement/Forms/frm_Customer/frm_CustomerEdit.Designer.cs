﻿namespace StoreManagement.Forms.frm_Customer
{
    partial class FrmCustomerEdit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmCustomerEdit));
            this.jsGroupBox1 = new JSRequirement.Controls.JSGroupBox();
            this.jsChkCredit = new JSRequirement.Controls.JSCheckBox();
            this.jS7BtnClose = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnEdit = new JSRequirement.Controls.JS7Btn();
            this.jsLabel5 = new JSRequirement.Controls.JSLabel();
            this.jsLabel3 = new JSRequirement.Controls.JSLabel();
            this.jsLabel2 = new JSRequirement.Controls.JSLabel();
            this.jsLabel1 = new JSRequirement.Controls.JSLabel();
            this.jstxtMobile = new JSRequirement.Controls.JSTextBox();
            this.jstxtTel = new JSRequirement.Controls.JSTextBox();
            this.jstxtAddress = new JSRequirement.Controls.JSTextBox();
            this.jstxtCName = new JSRequirement.Controls.JSTextBox();
            this.jsGroupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsGroupBox1
            // 
            this.jsGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox1.Controls.Add(this.jsChkCredit);
            this.jsGroupBox1.Controls.Add(this.jS7BtnClose);
            this.jsGroupBox1.Controls.Add(this.jS7BtnEdit);
            this.jsGroupBox1.Controls.Add(this.jsLabel5);
            this.jsGroupBox1.Controls.Add(this.jsLabel3);
            this.jsGroupBox1.Controls.Add(this.jsLabel2);
            this.jsGroupBox1.Controls.Add(this.jsLabel1);
            this.jsGroupBox1.Controls.Add(this.jstxtMobile);
            this.jsGroupBox1.Controls.Add(this.jstxtTel);
            this.jsGroupBox1.Controls.Add(this.jstxtAddress);
            this.jsGroupBox1.Controls.Add(this.jstxtCName);
            this.jsGroupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsGroupBox1.Location = new System.Drawing.Point(0, 0);
            this.jsGroupBox1.Name = "jsGroupBox1";
            this.jsGroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox1.Size = new System.Drawing.Size(402, 211);
            this.jsGroupBox1.TabIndex = 1;
            this.jsGroupBox1.TabStop = false;
            this.jsGroupBox1.Text = "مشخصات مشتری جدید را وارد نمایید";
            // 
            // jsChkCredit
            // 
            this.jsChkCredit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsChkCredit.BackColor = System.Drawing.Color.Transparent;
            this.jsChkCredit.Location = new System.Drawing.Point(20, 30);
            this.jsChkCredit.Name = "jsChkCredit";
            this.jsChkCredit.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsChkCredit.Size = new System.Drawing.Size(115, 28);
            this.jsChkCredit.TabIndex = 13;
            this.jsChkCredit.Text = "امتیاز خرید اعتباری";
            this.jsChkCredit.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.jsChkCredit.UseVisualStyleBackColor = false;
            // 
            // jS7BtnClose
            // 
            this.jS7BtnClose.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Close;
            this.jS7BtnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnClose.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnClose.ButtonText = "بستن";
            this.jS7BtnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnClose.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnClose.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnClose.Image")));
            this.jS7BtnClose.Location = new System.Drawing.Point(25, 154);
            this.jS7BtnClose.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnClose.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnClose.Name = "jS7BtnClose";
            this.jS7BtnClose.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnClose.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnClose.TabIndex = 11;
            this.jS7BtnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnClose.UseVisualStyleBackColor = false;
            this.jS7BtnClose.Click += new System.EventHandler(this.JS7BtnCloseClick);
            // 
            // jS7BtnEdit
            // 
            this.jS7BtnEdit.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Update;
            this.jS7BtnEdit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnEdit.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnEdit.ButtonText = "به روز رسانی";
            this.jS7BtnEdit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnEdit.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnEdit.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnEdit.Image")));
            this.jS7BtnEdit.Location = new System.Drawing.Point(159, 154);
            this.jS7BtnEdit.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnEdit.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnEdit.Name = "jS7BtnEdit";
            this.jS7BtnEdit.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnEdit.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnEdit.TabIndex = 10;
            this.jS7BtnEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnEdit.UseVisualStyleBackColor = false;
            this.jS7BtnEdit.Click += new System.EventHandler(this.JS7BtnEditClick);
            // 
            // jsLabel5
            // 
            this.jsLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel5.AutoSize = true;
            this.jsLabel5.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel5.Location = new System.Drawing.Point(151, 104);
            this.jsLabel5.Name = "jsLabel5";
            this.jsLabel5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel5.Size = new System.Drawing.Size(38, 22);
            this.jsLabel5.TabIndex = 9;
            this.jsLabel5.Text = "موبایل";
            this.jsLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel3
            // 
            this.jsLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel3.AutoSize = true;
            this.jsLabel3.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel3.Location = new System.Drawing.Point(342, 104);
            this.jsLabel3.Name = "jsLabel3";
            this.jsLabel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel3.Size = new System.Drawing.Size(30, 22);
            this.jsLabel3.TabIndex = 7;
            this.jsLabel3.Text = "تلفن";
            this.jsLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel2
            // 
            this.jsLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel2.AutoSize = true;
            this.jsLabel2.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel2.Location = new System.Drawing.Point(342, 68);
            this.jsLabel2.Name = "jsLabel2";
            this.jsLabel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel2.Size = new System.Drawing.Size(35, 22);
            this.jsLabel2.TabIndex = 6;
            this.jsLabel2.Text = "آدرس";
            this.jsLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsLabel1
            // 
            this.jsLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel1.AutoSize = true;
            this.jsLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel1.Location = new System.Drawing.Point(342, 32);
            this.jsLabel1.Name = "jsLabel1";
            this.jsLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel1.Size = new System.Drawing.Size(22, 22);
            this.jsLabel1.TabIndex = 5;
            this.jsLabel1.Text = "نام";
            this.jsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jstxtMobile
            // 
            this.jstxtMobile.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtMobile.Location = new System.Drawing.Point(20, 101);
            this.jstxtMobile.MaxLength = 200;
            this.jstxtMobile.Name = "jstxtMobile";
            this.jstxtMobile.PersianText = true;
            this.jstxtMobile.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtMobile.Size = new System.Drawing.Size(125, 30);
            this.jstxtMobile.TabIndex = 3;
            // 
            // jstxtTel
            // 
            this.jstxtTel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtTel.Location = new System.Drawing.Point(211, 101);
            this.jstxtTel.MaxLength = 200;
            this.jstxtTel.Name = "jstxtTel";
            this.jstxtTel.PersianText = true;
            this.jstxtTel.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtTel.Size = new System.Drawing.Size(125, 30);
            this.jstxtTel.TabIndex = 2;
            // 
            // jstxtAddress
            // 
            this.jstxtAddress.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtAddress.Location = new System.Drawing.Point(20, 65);
            this.jstxtAddress.MaxLength = 200;
            this.jstxtAddress.Name = "jstxtAddress";
            this.jstxtAddress.PersianText = true;
            this.jstxtAddress.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtAddress.Size = new System.Drawing.Size(316, 30);
            this.jstxtAddress.TabIndex = 1;
            // 
            // jstxtCName
            // 
            this.jstxtCName.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jstxtCName.Location = new System.Drawing.Point(159, 29);
            this.jstxtCName.MaxLength = 200;
            this.jstxtCName.Name = "jstxtCName";
            this.jstxtCName.PersianText = true;
            this.jstxtCName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jstxtCName.Size = new System.Drawing.Size(177, 30);
            this.jstxtCName.TabIndex = 0;
            // 
            // FrmCustomerEdit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(402, 211);
            this.Controls.Add(this.jsGroupBox1);
            this.Name = "FrmCustomerEdit";
            this.Text = "ویرایش مشخصات مشتری";
            this.jsGroupBox1.ResumeLayout(false);
            this.jsGroupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSGroupBox jsGroupBox1;
        private JSRequirement.Controls.JSCheckBox jsChkCredit;
        private JSRequirement.Controls.JS7Btn jS7BtnClose;
        private JSRequirement.Controls.JS7Btn jS7BtnEdit;
        private JSRequirement.Controls.JSLabel jsLabel5;
        private JSRequirement.Controls.JSLabel jsLabel3;
        private JSRequirement.Controls.JSLabel jsLabel2;
        private JSRequirement.Controls.JSLabel jsLabel1;
        private JSRequirement.Controls.JSTextBox jstxtMobile;
        private JSRequirement.Controls.JSTextBox jstxtTel;
        private JSRequirement.Controls.JSTextBox jstxtAddress;
        private JSRequirement.Controls.JSTextBox jstxtCName;
    }
}
