﻿using System;
using System.Windows.Forms;
using System.Linq;


namespace StoreManagement.Forms.frm_Sale
{
    public partial class FrmSaleAdd : Requirement.JSfrmBase
    {
        int _currentRow;
        public FrmSaleAdd()
        {
            InitializeComponent();
            jsclblAddValue.Anchor = (AnchorStyles.Top | AnchorStyles.Left);
            jS7BtnSale.Anchor = (AnchorStyles.Top | AnchorStyles.Left);
            jS7BtnSeri.Anchor = (AnchorStyles.Top | AnchorStyles.Left);
            jS7BtnDel.Anchor = (AnchorStyles.Top | AnchorStyles.Left);
            jS7BtnHome.Anchor = (AnchorStyles.Top | AnchorStyles.Left);

            {
                var newColumn = new DataGridViewTextBoxColumn
                {
                    Name = "RowNumber",
                    HeaderText = @"ردیف",
                    MinimumWidth = 30,
                    Width = 30,
                    ReadOnly = true
                };
                jsDataGrid1.Columns.Add(newColumn);
            }

            {
                var newColumn = new DataGridViewComboBoxColumn
                {
                    Name = "PCatID",
                    HeaderText = @"دسته",
                    DataSource = new Requirement.SMLinqDataContext().View_SM_UsedCategories,
                    DisplayMember = "ProductCategory",
                    ValueMember = "ProductCategoryID",
                    MinimumWidth = 130
                };
                jsDataGrid1.Columns.Add(newColumn);
            }
            {
                var newColumn = new DataGridViewComboBoxColumn
                {
                    Name = "PID",
                    HeaderText = @"نام کالا",
                    DataSource = new Requirement.SMLinqDataContext().tbl_SM_Products,
                    DisplayMember = "PName",
                    ValueMember = "ProductID",
                    DataPropertyName = "",
                    AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill,
                    MinimumWidth = 200
                };
                jsDataGrid1.Columns.Add(newColumn);
            }
            {
                var newColumn = new DataGridViewTextBoxColumn
                {
                    Name = "PCount",
                    HeaderText = @"تعداد",
                    MinimumWidth = 50,

                    Width = 50
                };
                jsDataGrid1.Columns.Add(newColumn);
            }
            {
                var newColumn = new DataGridViewTextBoxColumn
                {
                    Name = "PPrice",
                    HeaderText = @"قیمت کالا",
                    MinimumWidth = 70,
                    Width = 100,
                    ReadOnly = true
                };
                jsDataGrid1.Columns.Add(newColumn);
            }
            {
                var newColumn = new DataGridViewTextBoxColumn
                {
                    Name = "PDiscount",
                    HeaderText = @"تخفیف",
                    MinimumWidth = 70,
                    Width = 70
                };
                jsDataGrid1.Columns.Add(newColumn);
            }
            {
                var newColumn = new DataGridViewTextBoxColumn
                {
                    Name = "RTPrice",
                    HeaderText = @"مجموع",
                    MinimumWidth = 100,
                    Width = 110,
                    ReadOnly = true
                };
                jsDataGrid1.Columns.Add(newColumn);
            }
            

            jsCmbCustomer.DataSource = new Requirement.SMLinqDataContext().tbl_SM_Customers;
            jsCmbCustomer.DisplayMember = "CName";
            jsCmbCustomer.ValueMember = "CustomerID";
        }

        private void JS7BtnHomeClick(object sender, EventArgs e)
        {
            Close();
        }

        private void JS7BtnSaleClick(object sender, EventArgs e)
        {

            try
            {

                jsDataGrid1.Focus();
                if (jsDataGrid1.RowCount > 0)
                {
                    int pk;

                    var returnPk = new Requirement.SMLinqDataContext().JSP_SM_Sales_Add(
                        Convert.ToByte(Properties.Settings.Default.AppLoginedUser), jsCmbCustomer.SValueByte,
                        jsChkCredit.Checked, DateTime.Now, jstxtSDesc.Text, DateTime.Now);

                    
                    if (returnPk == null)
                    {
                        var lastPk = new Requirement.SMLinqDataContext().tbl_SM_Sales.Select(c => c.SalesID).Max();
                        Int32.TryParse(lastPk.ToString(), out pk);
                    }
                    else
                    {
                        var lastPk = returnPk.Select(c => c.Id).First();
                        Int32.TryParse(lastPk.ToString(), out pk);
                    }
                    if (pk == 0) MessageBox.Show(@"خطا در محاسبه آخرین فروش", @"خطا");

                    for (int index = 0; index < jsDataGrid1.Rows.Count - 1; index++)
                    // for update each product data
                    {
                        DataGridViewRow row = jsDataGrid1.Rows[index];
                        if (row.Cells["PID"].Value == null) continue;
                        if (row.Cells["PCount"].Value == null) continue;
                        if (row.Cells["PPrice"].Value == null) continue;

                        new Requirement.SMLinqDataContext().JSP_SM_SalesDetails_Add(
                            pk, Convert.ToInt16(row.Cells["PID"].Value),
                            Convert.ToSingle(row.Cells["PCount"].Value), Convert.ToInt32(row.Cells["PPrice"].Value));
                    }
                }

                jsDataGrid1.Rows.Clear();
                jsBarCodeBox1.Text = string.Empty;
                jsclblAddValue.Text = string.Empty;
                jsLblTotalSalePersianDesc.Text = string.Empty;
                jsclblTPrice.Text = @"0";
                jsclblTDiscount.Text = @"0";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, @"خطا در اضافه کردن فروش جدید");
                return;
            }
        }

        private void FrmSaleAddNumberTaken(object sender, EventArgs e)
        {
            try
            {
                if (JSNumber == 0) return;

                jsDataGrid1.Rows.Add(jsDataGrid1.RowCount, null, null, JSNumber, 1, 0, JSNumber);

                SaleTotalPrice();
                _currentRow = jsDataGrid1.RowCount - 2;
                TotalSaleForRow(_currentRow);
                //jsDataGrid1.Rows[_currentRow].Selected = true;
                jsDataGrid1.CurrentCell = jsDataGrid1[0, _currentRow];
                JSNumber = 0;
                jsclblAddValue.Text = @"+";

                Int16 dpid;
                Int16.TryParse(Properties.Settings.Default.AppLoginDefaultProduct, out dpid);
                if (dpid != 0)
                {
                    jsDataGrid1.Rows[_currentRow].Cells["PID"].Value = dpid;
                    jsDataGrid1.Rows[_currentRow].Cells["PCatID"].Value = new Requirement.SMLinqDataContext().View_SM_Products.Where(
                    c => c.ProductID == dpid).First().ProductCategoryID;
                    jsDataGrid1.Rows[_currentRow].Cells["PPrice"].Value = new Requirement.SMLinqDataContext().View_SM_Products.Where(
                    c => c.ProductID == dpid).First().PPrice;
                }


            }
            catch (Exception)
            {
                MessageBox.Show(@"خطا در وارد کردن عدد به جدول", @"سامانه مدیریت سوپر مارکت");
                return;
            }
        }

        private void FrmSaleAdd_OneNumTaken(object sender, EventArgs e)
        {
            jsclblAddValue.Text = JSNumber.ToString() + @"+ ";
        }

        private void FrmSaleAddBarcodeTaken(object sender, EventArgs e)
        {
            try
            {
                jsBarCodeBox1.Text = JSBarcode;
                var db =
                    new Requirement.SMLinqDataContext().View_SM_Products.Where(c => c.PBarCode == jsBarCodeBox1.Text);
                if (db.Count() == 0)
                {
                    db =
                    new Requirement.SMLinqDataContext().View_SM_Products.Where(c => c.PBarCode2 == jsBarCodeBox1.Text);
                    if (db.Count() == 0)
                    {
                        const string msgtxt =
                            @"این بارکد برای هیچ کالایی ثبت نشده است" + "\n" + " را بفشارید Yes برای افزودن کالا";
                        var result = MessageBox.Show(msgtxt, @"سامانه مدیریت سوپر مارکت",
                                                     MessageBoxButtons.YesNo, MessageBoxIcon.Question,
                                                     MessageBoxDefaultButton.Button2);
                        if (result == DialogResult.Yes)
                        {
                            new frm_Product.FrmProductAdd {jsBarCodeBox1 = {Text = JSBarcode}}.ShowDialog();
                            Close();
                        }
                        jsBarCodeBox1.Text = "";
                        return;
                    }
                }
                if (db.Count() > 1)
                {
                    jsBarCodeBox1.Text = "";
                    MessageBox.Show(@"این بارکد برای بیش از یک کالا ثبت شده است", @"خطا");
                    return;
                }

                if (db.Count() == 1)
                {
                    JscfAddToDataGrid(db);
                }
            }
            catch (Exception)
            {
                MessageBox.Show(@"خطا در تغییر بارکد", @"سامانه مدیریت سوپر مارکت");
                return;
            }
        }

        bool _newProduct = true;
        private void JscfAddToDataGrid(IQueryable<Requirement.View_SM_Product> db)
        {
            try
            {
                for (int index = 0; index < jsDataGrid1.Rows.Count - 1; index++) // for check new product or not
                {
                    Int16 pID;
                    if (jsDataGrid1.Rows[index].Cells["PID"].Value == null) continue;
                    Int16.TryParse(jsDataGrid1.Rows[index].Cells["PID"].Value.ToString(), out pID);

                    Single pCount;
                    if (jsDataGrid1.Rows[index].Cells["PCount"].Value == null) continue;
                    Single.TryParse(jsDataGrid1.Rows[index].Cells["PCount"].Value.ToString(), out pCount);


                    if (db.First().ProductID == pID)
                    {
                        jsDataGrid1.Rows[index].Cells["PCount"].Value = pCount + 1;
                        TotalSaleForRow(index);
                        _newProduct = false;
                        _currentRow = index;
                    }
                }
                if (_newProduct) // if new then
                {
                    if (jsChkCredit.Checked) // if credit add without discount
                        jsDataGrid1.Rows.Add(jsDataGrid1.RowCount, db.First().ProductCategoryID, db.First().ProductID, "1", db.First().PPrice,
                                             "0", db.First().PPrice);

                    else // else add with discount
                    {
                        jsDataGrid1.Rows.Add(jsDataGrid1.RowCount, db.First().ProductCategoryID, db.First().ProductID, "1", db.First().PPrice,
                                             db.First().PDiscount, (db.First().PPrice - db.First().PDiscount));
                    }
                    _currentRow = jsDataGrid1.RowCount - 2;
                }
                else
                {
                    _newProduct = true;
                }

                TotalSaleForRow(jsDataGrid1.Rows.Count - 2);
                SaleTotalPrice();
                jsDataGrid1.CurrentCell = jsDataGrid1[0, _currentRow];
            }
            catch (Exception)
            {
                MessageBox.Show(@"خطا در اضافه کردن به جدول", @"سامانه مدیریت سوپر مارکت");
                return;
            }
        }

        private void TotalSaleForRow(int rowNumber)
        {
            try
            {
                double totalofrow = Convert.ToSingle(jsDataGrid1.Rows[rowNumber].Cells["PCount"].Value)*
                                    (Convert.ToInt32(jsDataGrid1.Rows[rowNumber].Cells["PPrice"].Value) -
                                     Convert.ToInt32(jsDataGrid1.Rows[rowNumber].Cells["PDiscount"].Value));

                jsDataGrid1.Rows[rowNumber].Cells["RTPrice"].Value = (int)Math.Ceiling(totalofrow);
                return;
            }
            catch (Exception)
            {
                MessageBox.Show(@"محاسبه جمع سطر", @"سامانه مدیریت سوپر مارکت");
                jsDataGrid1.Rows[rowNumber].Cells["RTPrice"].Value = "خطا";
                return;
            }
        }

        private void SaleTotalPrice()
        {
            try
            {
                double saletotalprice = 0;
                double saletotalDiscount = 0;
                for (int index = 0; index < jsDataGrid1.Rows.Count - 1; index++)
                // for calc totalprice and totaldiscount
                {
                    DataGridViewRow row = jsDataGrid1.Rows[index];
                    if (row.Cells["RTPrice"].Value == null) continue;
                    saletotalprice += Convert.ToInt32(row.Cells["RTPrice"].Value);
                    if (row.Cells["PDiscount"].Value == null) continue;
                    saletotalDiscount += Convert.ToInt32(row.Cells["PDiscount"].Value) *
                                         Convert.ToSingle(row.Cells["PCount"].Value);
                    row.Cells["RowNumber"].Value = index + 1;
                }
                jsclblTPrice.Text = Math.Ceiling(saletotalprice).ToString();
                jsclblTDiscount.Text = Math.Ceiling(saletotalDiscount).ToString();
                if (jsclblTDiscount.Text == @"0")
                {
                    jsclblTDiscount.Visible = false;
                    jsclblTDiscountCaption.Visible = false;
                }
                else
                {
                    jsclblTDiscount.Visible = true;
                    jsclblTDiscountCaption.Visible = true;

                }
                
                jsLblTotalSalePersianDesc.Text = JSRequirement.Codes.ToWords.ToString(Convert.ToInt32(saletotalprice)) + @" تومان";
                //jsDataGrid1.Rows[jsDataGrid1.Rows.Count-1].Selected = true;
                //jsDataGrid1.CurrentCell = jsDataGrid1[0, jsDataGrid1.Rows.Count - 1];
                jsDataGrid1.FirstDisplayedScrollingRowIndex = jsDataGrid1.Rows.Count - 1;

            }
            catch (Exception)
            {
                MessageBox.Show(@"خطا در محاسبه جمع کل فروش", @"سامانه مدیریت سوپر مارکت");
                return;
            }
        }




        private void JS7BtnDelClick(object sender, EventArgs e)
        {   
            try
            {
                if (jsDataGrid1.Rows.Count == 1) return;
                if (jsDataGrid1.Rows.Count == _currentRow + 1) return;
                jsDataGrid1.Rows.RemoveAt(_currentRow);
                _currentRow = jsDataGrid1.RowCount - 2;
                SaleTotalPrice();
                jsDataGrid1.CurrentCell = jsDataGrid1[0, _currentRow];
            }
            catch (Exception)
            {
                MessageBox.Show(@"خطا در پاک کردن ردیف از جدول", @"سامانه مدیریت سوپر مارکت");
                return;
            }
        }

        private void JS7BtnSeriClick(object sender, EventArgs e)
        {
            FrmHome.LoadedForm++;
            new FrmSaleAdd().Show(Owner);
        }

        private void JSDataGrid1Enter(object sender, EventArgs e)
        {
            InputLanguage.CurrentInputLanguage = InputLanguage.FromCulture(new System.Globalization.CultureInfo("en-us"));
        }

        private void FrmSaleAddKeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete) JS7BtnDelClick(null, null);
            if (e.KeyCode == Keys.F8) JS7BtnSeriClick(null, null);
            if (e.KeyCode == Keys.F4 && e.Alt == false)
            {
                jsDataGrid1.Focus();
                JS7BtnSaleClick(null, null);
            }
            if (e.KeyCode == Keys.Escape ) JS7BtnHomeClick(null, null);
            if (e.KeyCode == Keys.F6)
                jsChkCredit.Checked = !jsChkCredit.Checked;
            if (e.KeyCode == Keys.F7)
                jsCmbCustomer.Focus();
        }

        private void JSDataGrid1CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            try
            {
                switch (e.ColumnIndex)
                {
                    case 3:
                        if (e.FormattedValue.ToString() == "" || e.FormattedValue.ToString() == "0")
                            jsDataGrid1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = 1;
                        break;

                    case 5:
                        if (e.FormattedValue.ToString() == "")
                            jsDataGrid1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = 0;
                        break;
                }
            }
            catch (Exception)
            {
                MessageBox.Show(@"خطا در حال اعتبارسنجی سلول", @"سامانه مدیریت سوپر مارکت");
                return;
            }
        }

        private void JSDataGrid1CellValidated(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (jsDataGrid1.CurrentCell.Value == null) return;
                Int16 catID;
                Int16 pID;
                Single pCount;
                if (jsDataGrid1.Rows[e.RowIndex].Cells["PCatID"].Value != null)
                    Int16.TryParse(jsDataGrid1.Rows[e.RowIndex].Cells["PCatID"].Value.ToString(), out catID);
                else catID = -1;

                if (jsDataGrid1.Rows[e.RowIndex].Cells["PID"].Value != null)
                    Int16.TryParse(jsDataGrid1.Rows[e.RowIndex].Cells["PID"].Value.ToString(), out pID);
                else pID = -1;

                if (jsDataGrid1.Rows[e.RowIndex].Cells["PCount"].Value != null)
                    Single.TryParse(jsDataGrid1.Rows[e.RowIndex].Cells["PCount"].Value.ToString(), out pCount);
                else pCount = -1;

                var db = new Requirement.SMLinqDataContext().View_SM_Products.Where(c => c.ProductID == pID);


                switch (e.ColumnIndex)
                {
                    case 1:
                        if (db.Count() > 0)
                            if (catID != db.First().ProductCategoryID)
                            {
                                jsDataGrid1.Rows[e.RowIndex].Cells["PID"].Value = null;
                                jsDataGrid1.Rows[e.RowIndex].Cells["PCount"].Value = 0;
                                jsDataGrid1.Rows[e.RowIndex].Cells["PPrice"].Value = 0;
                            }

                        ((DataGridViewComboBoxCell) (jsDataGrid1.Rows[e.RowIndex].Cells["PID"])).DataSource =
                            new Requirement.SMLinqDataContext().View_SM_Products.Where(c => c.ProductCategoryID == catID)
                                .Select(c => new {c.ProductID, c.PName});
                        break;

                    case 2:
                        if (pCount < 1)
                            jsDataGrid1.Rows[e.RowIndex].Cells["PCount"].Value = 1;

                        jsDataGrid1.Rows[e.RowIndex].Cells["PCatID"].Value = db.First().ProductCategoryID;
                        jsDataGrid1.Rows[e.RowIndex].Cells["PPrice"].Value = db.First().PPrice;
                        jsDataGrid1.Rows[e.RowIndex].Cells["PDiscount"].Value = db.First().PDiscount;
                        if (jsChkCredit.Checked)
                            jsDataGrid1.Rows[e.RowIndex].Cells["PDiscount"].Value = 0;

                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, @"خطا در اعتبار سنجی سلول ها");
                //MessageBox.Show(@"خطا در اعتبار سنجی سلول ها", @"سامانه مدیریت سوپر مارکت");
                return;
            }

            TotalSaleForRow(e.RowIndex);
            SaleTotalPrice();
        }

        private void JSDataGrid1RowEnter(object sender, DataGridViewCellEventArgs e)
        {
            _currentRow = e.RowIndex;
        }

        private void FrmSaleAddFormClosing(object sender, FormClosingEventArgs e)
        {
            FrmHome.LoadedForm--;
        }

        private void JS7BtnPrevSaleClick(object sender, EventArgs e)
        {
            
            FrmHome.LoadedForm++;
            var frmsale = new FrmSaleAdd();
            //var lastPk = new Requirement.SMLinqDataContext().tbl_SM_Sales.Select(c => c.SalesID).Max();

            frmsale.Show(Owner);
        }
    }
}
