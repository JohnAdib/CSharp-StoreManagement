﻿namespace StoreManagement.Forms.Settings
{
    partial class FrmAppSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmAppSettings));
            this.jsPanel2 = new JSRequirement.Controls.JSPanel();
            this.jS7BtnClose = new JSRequirement.Controls.JS7Btn();
            this.jS7BtnUpdate = new JSRequirement.Controls.JS7Btn();
            this.jsPanel3 = new JSRequirement.Controls.JSPanel();
            this.TabSettings = new System.Windows.Forms.TabControl();
            this.tabGeneral = new System.Windows.Forms.TabPage();
            this.jsGroupBox3 = new JSRequirement.Controls.JSGroupBox();
            this.jsLabel5 = new JSRequirement.Controls.JSLabel();
            this.jsCmbDefaultProduct = new JSRequirement.Controls.JSComboBox();
            this.jsGroupBox1 = new JSRequirement.Controls.JSGroupBox();
            this.jsTxtAppname = new JSRequirement.Controls.JSTextBox();
            this.jsLabel1 = new JSRequirement.Controls.JSLabel();
            this.tabSecurity = new System.Windows.Forms.TabPage();
            this.jsGroupBox2 = new JSRequirement.Controls.JSGroupBox();
            this.jsCmbDefaultUserCode = new JSRequirement.Controls.JSComboBox();
            this.jsLabel3 = new JSRequirement.Controls.JSLabel();
            this.jsTxtAppLoginTryCount = new JSRequirement.Controls.JSTextBox();
            this.jsLabel2 = new JSRequirement.Controls.JSLabel();
            this.tabSaleSettings = new System.Windows.Forms.TabPage();
            this.jsPanel3.SuspendLayout();
            this.TabSettings.SuspendLayout();
            this.tabGeneral.SuspendLayout();
            this.jsGroupBox3.SuspendLayout();
            this.jsGroupBox1.SuspendLayout();
            this.tabSecurity.SuspendLayout();
            this.jsGroupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsPanel2
            // 
            this.jsPanel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsPanel2.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel2.Location = new System.Drawing.Point(0, 0);
            this.jsPanel2.Name = "jsPanel2";
            this.jsPanel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel2.Size = new System.Drawing.Size(200, 100);
            this.jsPanel2.TabIndex = 4;
            // 
            // jS7BtnClose
            // 
            this.jS7BtnClose.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Close;
            this.jS7BtnClose.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnClose.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnClose.ButtonText = "بستن";
            this.jS7BtnClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnClose.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnClose.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnClose.Image")));
            this.jS7BtnClose.Location = new System.Drawing.Point(9, 92);
            this.jS7BtnClose.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnClose.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnClose.Name = "jS7BtnClose";
            this.jS7BtnClose.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnClose.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnClose.TabIndex = 3;
            this.jS7BtnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnClose.UseVisualStyleBackColor = false;
            this.jS7BtnClose.Click += new System.EventHandler(this.JS7BtnCloseClick);
            // 
            // jS7BtnUpdate
            // 
            this.jS7BtnUpdate.ActionType = JSRequirement.Controls.JS7Btn.BtnContentList.Update;
            this.jS7BtnUpdate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7BtnUpdate.BackColor = System.Drawing.Color.Transparent;
            this.jS7BtnUpdate.ButtonText = "به روز رسانی";
            this.jS7BtnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7BtnUpdate.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7BtnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("jS7BtnUpdate.Image")));
            this.jS7BtnUpdate.Location = new System.Drawing.Point(10, 41);
            this.jS7BtnUpdate.Margin = new System.Windows.Forms.Padding(7);
            this.jS7BtnUpdate.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7BtnUpdate.Name = "jS7BtnUpdate";
            this.jS7BtnUpdate.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7BtnUpdate.Size = new System.Drawing.Size(120, 40);
            this.jS7BtnUpdate.TabIndex = 2;
            this.jS7BtnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.jS7BtnUpdate.UseVisualStyleBackColor = false;
            this.jS7BtnUpdate.Click += new System.EventHandler(this.JS7BtnUpdateClick);
            // 
            // jsPanel3
            // 
            this.jsPanel3.BackColor = System.Drawing.Color.Transparent;
            this.jsPanel3.Controls.Add(this.TabSettings);
            this.jsPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsPanel3.Location = new System.Drawing.Point(0, 0);
            this.jsPanel3.Name = "jsPanel3";
            this.jsPanel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanel3.Size = new System.Drawing.Size(688, 370);
            this.jsPanel3.TabIndex = 3;
            // 
            // TabSettings
            // 
            this.TabSettings.Controls.Add(this.tabGeneral);
            this.TabSettings.Controls.Add(this.tabSecurity);
            this.TabSettings.Controls.Add(this.tabSaleSettings);
            this.TabSettings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TabSettings.Location = new System.Drawing.Point(0, 0);
            this.TabSettings.Name = "TabSettings";
            this.TabSettings.RightToLeftLayout = true;
            this.TabSettings.SelectedIndex = 0;
            this.TabSettings.Size = new System.Drawing.Size(688, 370);
            this.TabSettings.TabIndex = 7;
            // 
            // tabGeneral
            // 
            this.tabGeneral.Controls.Add(this.jsGroupBox3);
            this.tabGeneral.Controls.Add(this.jsGroupBox1);
            this.tabGeneral.Location = new System.Drawing.Point(4, 31);
            this.tabGeneral.Name = "tabGeneral";
            this.tabGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.tabGeneral.Size = new System.Drawing.Size(680, 335);
            this.tabGeneral.TabIndex = 0;
            this.tabGeneral.Text = "عمومی";
            this.tabGeneral.UseVisualStyleBackColor = true;
            // 
            // jsGroupBox3
            // 
            this.jsGroupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGroupBox3.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox3.Controls.Add(this.jsLabel5);
            this.jsGroupBox3.Controls.Add(this.jsCmbDefaultProduct);
            this.jsGroupBox3.Location = new System.Drawing.Point(199, 126);
            this.jsGroupBox3.Name = "jsGroupBox3";
            this.jsGroupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox3.Size = new System.Drawing.Size(404, 133);
            this.jsGroupBox3.TabIndex = 7;
            this.jsGroupBox3.TabStop = false;
            this.jsGroupBox3.Text = "ثبت فروش آزاد با نام";
            // 
            // jsLabel5
            // 
            this.jsLabel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel5.AutoSize = true;
            this.jsLabel5.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel5.Location = new System.Drawing.Point(272, 69);
            this.jsLabel5.Name = "jsLabel5";
            this.jsLabel5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel5.Size = new System.Drawing.Size(86, 22);
            this.jsLabel5.TabIndex = 5;
            this.jsLabel5.Text = "کالای فروش آزاد";
            this.jsLabel5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsCmbDefaultProduct
            // 
            this.jsCmbDefaultProduct.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsCmbDefaultProduct.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.jsCmbDefaultProduct.FormattingEnabled = true;
            this.jsCmbDefaultProduct.Location = new System.Drawing.Point(21, 66);
            this.jsCmbDefaultProduct.Name = "jsCmbDefaultProduct";
            this.jsCmbDefaultProduct.PersianText = true;
            this.jsCmbDefaultProduct.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsCmbDefaultProduct.Size = new System.Drawing.Size(245, 30);
            this.jsCmbDefaultProduct.TabIndex = 4;
            // 
            // jsGroupBox1
            // 
            this.jsGroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox1.Controls.Add(this.jsTxtAppname);
            this.jsGroupBox1.Controls.Add(this.jsLabel1);
            this.jsGroupBox1.Location = new System.Drawing.Point(199, 10);
            this.jsGroupBox1.Name = "jsGroupBox1";
            this.jsGroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox1.Size = new System.Drawing.Size(404, 100);
            this.jsGroupBox1.TabIndex = 3;
            this.jsGroupBox1.TabStop = false;
            this.jsGroupBox1.Text = "تنظیمات عمومی";
            // 
            // jsTxtAppname
            // 
            this.jsTxtAppname.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsTxtAppname.Location = new System.Drawing.Point(21, 44);
            this.jsTxtAppname.MaxLength = 200;
            this.jsTxtAppname.Name = "jsTxtAppname";
            this.jsTxtAppname.Num16 = ((short)(0));
            this.jsTxtAppname.Num32 = 0;
            this.jsTxtAppname.Num64 = ((long)(0));
            this.jsTxtAppname.NumByte = ((byte)(0));
            this.jsTxtAppname.NumDouble = 0D;
            this.jsTxtAppname.NumFloat = 0F;
            this.jsTxtAppname.PersianText = true;
            this.jsTxtAppname.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsTxtAppname.Size = new System.Drawing.Size(245, 30);
            this.jsTxtAppname.TabIndex = 1;
            // 
            // jsLabel1
            // 
            this.jsLabel1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel1.AutoSize = true;
            this.jsLabel1.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel1.Location = new System.Drawing.Point(279, 47);
            this.jsLabel1.Name = "jsLabel1";
            this.jsLabel1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel1.Size = new System.Drawing.Size(74, 22);
            this.jsLabel1.TabIndex = 0;
            this.jsLabel1.Text = "سامانه مدیریت";
            this.jsLabel1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabSecurity
            // 
            this.tabSecurity.Controls.Add(this.jsGroupBox2);
            this.tabSecurity.Location = new System.Drawing.Point(4, 31);
            this.tabSecurity.Name = "tabSecurity";
            this.tabSecurity.Padding = new System.Windows.Forms.Padding(3);
            this.tabSecurity.Size = new System.Drawing.Size(543, 335);
            this.tabSecurity.TabIndex = 1;
            this.tabSecurity.Text = "امنیتی";
            this.tabSecurity.UseVisualStyleBackColor = true;
            // 
            // jsGroupBox2
            // 
            this.jsGroupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox2.Controls.Add(this.jsCmbDefaultUserCode);
            this.jsGroupBox2.Controls.Add(this.jsLabel3);
            this.jsGroupBox2.Controls.Add(this.jsTxtAppLoginTryCount);
            this.jsGroupBox2.Controls.Add(this.jsLabel2);
            this.jsGroupBox2.Location = new System.Drawing.Point(133, 10);
            this.jsGroupBox2.Name = "jsGroupBox2";
            this.jsGroupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox2.Size = new System.Drawing.Size(404, 137);
            this.jsGroupBox2.TabIndex = 9;
            this.jsGroupBox2.TabStop = false;
            this.jsGroupBox2.Text = "تنظیمات ورود به سامانه";
            // 
            // jsCmbDefaultUserCode
            // 
            this.jsCmbDefaultUserCode.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsCmbDefaultUserCode.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.jsCmbDefaultUserCode.FormattingEnabled = true;
            this.jsCmbDefaultUserCode.Location = new System.Drawing.Point(21, 80);
            this.jsCmbDefaultUserCode.Name = "jsCmbDefaultUserCode";
            this.jsCmbDefaultUserCode.PersianText = true;
            this.jsCmbDefaultUserCode.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsCmbDefaultUserCode.Size = new System.Drawing.Size(245, 30);
            this.jsCmbDefaultUserCode.TabIndex = 6;
            // 
            // jsLabel3
            // 
            this.jsLabel3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel3.AutoSize = true;
            this.jsLabel3.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel3.Location = new System.Drawing.Point(272, 83);
            this.jsLabel3.Name = "jsLabel3";
            this.jsLabel3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel3.Size = new System.Drawing.Size(84, 22);
            this.jsLabel3.TabIndex = 5;
            this.jsLabel3.Text = "کاربر پیش فرض";
            this.jsLabel3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // jsTxtAppLoginTryCount
            // 
            this.jsTxtAppLoginTryCount.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsTxtAppLoginTryCount.Location = new System.Drawing.Point(21, 41);
            this.jsTxtAppLoginTryCount.MaxLength = 2;
            this.jsTxtAppLoginTryCount.Name = "jsTxtAppLoginTryCount";
            this.jsTxtAppLoginTryCount.Num16 = ((short)(0));
            this.jsTxtAppLoginTryCount.Num32 = 0;
            this.jsTxtAppLoginTryCount.Num64 = ((long)(0));
            this.jsTxtAppLoginTryCount.NumByte = ((byte)(0));
            this.jsTxtAppLoginTryCount.NumDouble = 0D;
            this.jsTxtAppLoginTryCount.NumFloat = 0F;
            this.jsTxtAppLoginTryCount.PersianText = true;
            this.jsTxtAppLoginTryCount.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsTxtAppLoginTryCount.Size = new System.Drawing.Size(138, 30);
            this.jsTxtAppLoginTryCount.TabIndex = 4;
            // 
            // jsLabel2
            // 
            this.jsLabel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsLabel2.AutoSize = true;
            this.jsLabel2.BackColor = System.Drawing.Color.Transparent;
            this.jsLabel2.Location = new System.Drawing.Point(165, 44);
            this.jsLabel2.Name = "jsLabel2";
            this.jsLabel2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsLabel2.Size = new System.Drawing.Size(155, 22);
            this.jsLabel2.TabIndex = 3;
            this.jsLabel2.Text = "تعداد تلاش های مجاز برای ورود";
            this.jsLabel2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tabSaleSettings
            // 
            this.tabSaleSettings.Location = new System.Drawing.Point(4, 31);
            this.tabSaleSettings.Name = "tabSaleSettings";
            this.tabSaleSettings.Padding = new System.Windows.Forms.Padding(3);
            this.tabSaleSettings.Size = new System.Drawing.Size(543, 335);
            this.tabSaleSettings.TabIndex = 2;
            this.tabSaleSettings.Text = "فروش";
            this.tabSaleSettings.UseVisualStyleBackColor = true;
            // 
            // FrmAppSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.ClientSize = new System.Drawing.Size(763, 370);
            this.Controls.Add(this.jsPanel3);
            this.Controls.Add(this.jsPanel2);
            this.FormTitle = "تنظیمات";
            this.Name = "FrmAppSettings";
            this.Text = "سامانه مدیریت فروشگاه | تنظیمات";
            this.Controls.SetChildIndex(this.jsPanel2, 0);
            this.Controls.SetChildIndex(this.jsPanel3, 0);
            this.jsPanel3.ResumeLayout(false);
            this.TabSettings.ResumeLayout(false);
            this.tabGeneral.ResumeLayout(false);
            this.jsGroupBox3.ResumeLayout(false);
            this.jsGroupBox3.PerformLayout();
            this.jsGroupBox1.ResumeLayout(false);
            this.jsGroupBox1.PerformLayout();
            this.tabSecurity.ResumeLayout(false);
            this.jsGroupBox2.ResumeLayout(false);
            this.jsGroupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSPanel jsPanel2;
        private JSRequirement.Controls.JSPanel jsPanel3;
        private JSRequirement.Controls.JS7Btn jS7BtnClose;
        private JSRequirement.Controls.JS7Btn jS7BtnUpdate;
        private System.Windows.Forms.TabControl TabSettings;
        private System.Windows.Forms.TabPage tabGeneral;
        private System.Windows.Forms.TabPage tabSecurity;
        private JSRequirement.Controls.JSGroupBox jsGroupBox1;
        private JSRequirement.Controls.JSTextBox jsTxtAppname;
        private JSRequirement.Controls.JSLabel jsLabel1;
        private JSRequirement.Controls.JSGroupBox jsGroupBox2;
        private JSRequirement.Controls.JSComboBox jsCmbDefaultUserCode;
        private JSRequirement.Controls.JSLabel jsLabel3;
        private JSRequirement.Controls.JSTextBox jsTxtAppLoginTryCount;
        private JSRequirement.Controls.JSLabel jsLabel2;
        private System.Windows.Forms.TabPage tabSaleSettings;
        private JSRequirement.Controls.JSGroupBox jsGroupBox3;
        private JSRequirement.Controls.JSLabel jsLabel5;
        private JSRequirement.Controls.JSComboBox jsCmbDefaultProduct;
    }
}
