﻿using System;
using System.Windows.Forms;

namespace StoreManagement.Forms.frm_Purchase
{
    public partial class FrmPurchase : Requirement.JSfrmBase
    {
        public FrmPurchase()
        {
            InitializeComponent();
            UpdateDateGrid();
        }

        public void UpdateDateGrid()
        {
            jsDataGrid1.DataSource = new Requirement.SMLinqDataContext().View_SM_Purchases;
        }

        private void JS7Btn4Click(object sender, EventArgs e)
        {
            Close();
        }

        private void JS7Btn3Click(object sender, EventArgs e)
        {
            try
            {
                if (jsDataGrid1.CurrentRow == null)
                    return;

                if (
                    MessageBox.Show(Properties.Settings.Default.AppMsgDelete, @"حذف", MessageBoxButtons.YesNo,
                                    MessageBoxIcon.Question) == DialogResult.No)
                    return;

                new Requirement.SMLinqDataContext().JSP_SM_Purchases_Delete(
                    Convert.ToInt32(jsDataGrid1.CurrentRow.Cells["PurchasesID"].Value));
                UpdateDateGrid();
            }
            catch
            {
                MessageBox.Show(@"خطایی در حذف رخ داده است!", @"خطا", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }

        private void JS7Btn2Click(object sender, EventArgs e)
        {
            MessageBox.Show(@"به زودی تکمیل خواهد شد");
        }

        private void JS7Btn1Click(object sender, EventArgs e)
        {
            Close();
            new FrmPurchaseAdd().ShowDialog(this);
        }
    }
}
