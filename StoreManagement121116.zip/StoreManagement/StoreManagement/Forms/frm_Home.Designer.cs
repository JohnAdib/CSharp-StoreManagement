﻿namespace StoreManagement.Forms
{
    partial class FrmHome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.jsPanelMenuHome = new JSRequirement.Controls.JSPanel();
            this.jsMenuStripStoreManagement1 = new StoreManagement.Requirement.JSMenuStripStoreManagement();
            this.jS7Btn4 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn5 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn1 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn3 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn6 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn7 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn8 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn9 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn2 = new JSRequirement.Controls.JS7Btn();
            this.jS7Btn10 = new JSRequirement.Controls.JS7Btn();
            this.jsGroupBox1 = new JSRequirement.Controls.JSGroupBox();
            this.jsGroupBox2 = new JSRequirement.Controls.JSGroupBox();
            this.jsGroupBox3 = new JSRequirement.Controls.JSGroupBox();
            this.jS7Btn11 = new JSRequirement.Controls.JS7Btn();
            this.jsPanelMenuHome.SuspendLayout();
            this.jsGroupBox1.SuspendLayout();
            this.jsGroupBox2.SuspendLayout();
            this.jsGroupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // jsPanelMenuHome
            // 
            this.jsPanelMenuHome.BackColor = System.Drawing.Color.Transparent;
            this.jsPanelMenuHome.Controls.Add(this.jsMenuStripStoreManagement1);
            this.jsPanelMenuHome.Dock = System.Windows.Forms.DockStyle.Right;
            this.jsPanelMenuHome.Location = new System.Drawing.Point(499, 0);
            this.jsPanelMenuHome.Name = "jsPanelMenuHome";
            this.jsPanelMenuHome.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsPanelMenuHome.Size = new System.Drawing.Size(75, 327);
            this.jsPanelMenuHome.TabIndex = 1001;
            // 
            // jsMenuStripStoreManagement1
            // 
            this.jsMenuStripStoreManagement1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.jsMenuStripStoreManagement1.BackColor = System.Drawing.Color.Transparent;
            this.jsMenuStripStoreManagement1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.jsMenuStripStoreManagement1.Location = new System.Drawing.Point(0, 0);
            this.jsMenuStripStoreManagement1.MaximumSize = new System.Drawing.Size(80, 0);
            this.jsMenuStripStoreManagement1.MinimumSize = new System.Drawing.Size(75, 250);
            this.jsMenuStripStoreManagement1.Name = "jsMenuStripStoreManagement1";
            this.jsMenuStripStoreManagement1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsMenuStripStoreManagement1.Size = new System.Drawing.Size(75, 327);
            this.jsMenuStripStoreManagement1.TabIndex = 0;
            // 
            // jS7Btn4
            // 
            this.jS7Btn4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn4.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn4.ButtonText = "تنظیمات";
            this.jS7Btn4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn4.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn4.Location = new System.Drawing.Point(161, 33);
            this.jS7Btn4.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn4.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn4.Name = "jS7Btn4";
            this.jS7Btn4.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn4.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn4.TabIndex = 1004;
            this.jS7Btn4.Text = "jS7Btn4";
            this.jS7Btn4.UseVisualStyleBackColor = false;
            this.jS7Btn4.Click += new System.EventHandler(this.JS7Btn4Click);
            // 
            // jS7Btn5
            // 
            this.jS7Btn5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn5.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn5.ButtonText = "دسته ها";
            this.jS7Btn5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn5.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn5.Location = new System.Drawing.Point(27, 33);
            this.jS7Btn5.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn5.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn5.Name = "jS7Btn5";
            this.jS7Btn5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn5.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn5.TabIndex = 1005;
            this.jS7Btn5.UseVisualStyleBackColor = false;
            this.jS7Btn5.Click += new System.EventHandler(this.JS7Btn5Click);
            // 
            // jS7Btn1
            // 
            this.jS7Btn1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn1.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn1.ButtonText = "مشتریان";
            this.jS7Btn1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn1.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn1.Location = new System.Drawing.Point(27, 87);
            this.jS7Btn1.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn1.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn1.Name = "jS7Btn1";
            this.jS7Btn1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn1.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn1.TabIndex = 1006;
            this.jS7Btn1.UseVisualStyleBackColor = false;
            this.jS7Btn1.Click += new System.EventHandler(this.JS7Btn1Click);
            // 
            // jS7Btn3
            // 
            this.jS7Btn3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn3.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn3.ButtonText = "واحد شمارش کالا";
            this.jS7Btn3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn3.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn3.Location = new System.Drawing.Point(161, 33);
            this.jS7Btn3.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn3.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn3.Name = "jS7Btn3";
            this.jS7Btn3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn3.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn3.TabIndex = 1007;
            this.jS7Btn3.Text = "jS7Btn3";
            this.jS7Btn3.UseVisualStyleBackColor = false;
            this.jS7Btn3.Click += new System.EventHandler(this.JS7Btn3Click);
            // 
            // jS7Btn6
            // 
            this.jS7Btn6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn6.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn6.ButtonText = "توزیع کنندگان";
            this.jS7Btn6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn6.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn6.Location = new System.Drawing.Point(161, 87);
            this.jS7Btn6.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn6.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn6.Name = "jS7Btn6";
            this.jS7Btn6.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn6.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn6.TabIndex = 1008;
            this.jS7Btn6.Text = "jS7Btn6";
            this.jS7Btn6.UseVisualStyleBackColor = false;
            this.jS7Btn6.Click += new System.EventHandler(this.JS7Btn6Click);
            // 
            // jS7Btn7
            // 
            this.jS7Btn7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn7.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn7.ButtonText = "کالاها";
            this.jS7Btn7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn7.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn7.Location = new System.Drawing.Point(27, 141);
            this.jS7Btn7.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn7.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn7.Name = "jS7Btn7";
            this.jS7Btn7.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn7.Size = new System.Drawing.Size(254, 40);
            this.jS7Btn7.TabIndex = 1009;
            this.jS7Btn7.Text = "jS7Btn7";
            this.jS7Btn7.UseVisualStyleBackColor = false;
            this.jS7Btn7.Click += new System.EventHandler(this.JS7Btn7Click);
            // 
            // jS7Btn8
            // 
            this.jS7Btn8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn8.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn8.ButtonText = "فروش ها";
            this.jS7Btn8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn8.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn8.Location = new System.Drawing.Point(27, 87);
            this.jS7Btn8.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn8.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn8.Name = "jS7Btn8";
            this.jS7Btn8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn8.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn8.TabIndex = 11;
            this.jS7Btn8.Text = "jS7Btn8";
            this.jS7Btn8.UseVisualStyleBackColor = false;
            this.jS7Btn8.Click += new System.EventHandler(this.JS7Btn8Click);
            // 
            // jS7Btn9
            // 
            this.jS7Btn9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn9.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn9.ButtonText = "فروش";
            this.jS7Btn9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn9.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn9.Location = new System.Drawing.Point(27, 33);
            this.jS7Btn9.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn9.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn9.Name = "jS7Btn9";
            this.jS7Btn9.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn9.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn9.TabIndex = 10;
            this.jS7Btn9.Text = "jS7Btn9";
            this.jS7Btn9.UseVisualStyleBackColor = false;
            this.jS7Btn9.Click += new System.EventHandler(this.JS7Btn9Click);
            // 
            // jS7Btn2
            // 
            this.jS7Btn2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn2.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn2.ButtonText = "خریدها";
            this.jS7Btn2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn2.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn2.Location = new System.Drawing.Point(27, 195);
            this.jS7Btn2.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn2.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn2.Name = "jS7Btn2";
            this.jS7Btn2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn2.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn2.TabIndex = 13;
            this.jS7Btn2.Text = "jS7Btn2";
            this.jS7Btn2.UseVisualStyleBackColor = false;
            this.jS7Btn2.Click += new System.EventHandler(this.JS7Btn2Click);
            // 
            // jS7Btn10
            // 
            this.jS7Btn10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn10.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn10.ButtonText = "خرید کالا";
            this.jS7Btn10.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn10.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn10.Location = new System.Drawing.Point(27, 141);
            this.jS7Btn10.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn10.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn10.Name = "jS7Btn10";
            this.jS7Btn10.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn10.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn10.TabIndex = 12;
            this.jS7Btn10.Text = "jS7Btn10";
            this.jS7Btn10.UseVisualStyleBackColor = false;
            this.jS7Btn10.Click += new System.EventHandler(this.JS7Btn10Click);
            // 
            // jsGroupBox1
            // 
            this.jsGroupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGroupBox1.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox1.Controls.Add(this.jS7Btn5);
            this.jsGroupBox1.Controls.Add(this.jS7Btn1);
            this.jsGroupBox1.Controls.Add(this.jS7Btn3);
            this.jsGroupBox1.Controls.Add(this.jS7Btn6);
            this.jsGroupBox1.Controls.Add(this.jS7Btn7);
            this.jsGroupBox1.ForeColor = System.Drawing.Color.Black;
            this.jsGroupBox1.Location = new System.Drawing.Point(9, 12);
            this.jsGroupBox1.Name = "jsGroupBox1";
            this.jsGroupBox1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox1.Size = new System.Drawing.Size(306, 209);
            this.jsGroupBox1.TabIndex = 2;
            this.jsGroupBox1.TabStop = false;
            this.jsGroupBox1.Text = "اطلاعات اولیه";
            // 
            // jsGroupBox2
            // 
            this.jsGroupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGroupBox2.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox2.Controls.Add(this.jS7Btn9);
            this.jsGroupBox2.Controls.Add(this.jS7Btn10);
            this.jsGroupBox2.Controls.Add(this.jS7Btn8);
            this.jsGroupBox2.Controls.Add(this.jS7Btn2);
            this.jsGroupBox2.ForeColor = System.Drawing.Color.Black;
            this.jsGroupBox2.Location = new System.Drawing.Point(321, 12);
            this.jsGroupBox2.Name = "jsGroupBox2";
            this.jsGroupBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox2.Size = new System.Drawing.Size(172, 265);
            this.jsGroupBox2.TabIndex = 1;
            this.jsGroupBox2.TabStop = false;
            this.jsGroupBox2.Text = "خرید و فروش کالا";
            // 
            // jsGroupBox3
            // 
            this.jsGroupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jsGroupBox3.BackColor = System.Drawing.Color.Transparent;
            this.jsGroupBox3.Controls.Add(this.jS7Btn11);
            this.jsGroupBox3.Controls.Add(this.jS7Btn4);
            this.jsGroupBox3.ForeColor = System.Drawing.Color.Black;
            this.jsGroupBox3.Location = new System.Drawing.Point(9, 227);
            this.jsGroupBox3.Name = "jsGroupBox3";
            this.jsGroupBox3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jsGroupBox3.Size = new System.Drawing.Size(306, 87);
            this.jsGroupBox3.TabIndex = 3;
            this.jsGroupBox3.TabStop = false;
            this.jsGroupBox3.Text = "سامانه مدیریت فروشگاه";
            // 
            // jS7Btn11
            // 
            this.jS7Btn11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.jS7Btn11.BackColor = System.Drawing.Color.Transparent;
            this.jS7Btn11.ButtonText = "کاربران";
            this.jS7Btn11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.jS7Btn11.Font = new System.Drawing.Font("B Mitra", 13.5F);
            this.jS7Btn11.Location = new System.Drawing.Point(27, 33);
            this.jS7Btn11.Margin = new System.Windows.Forms.Padding(7);
            this.jS7Btn11.MinimumSize = new System.Drawing.Size(120, 40);
            this.jS7Btn11.Name = "jS7Btn11";
            this.jS7Btn11.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.jS7Btn11.Size = new System.Drawing.Size(120, 40);
            this.jS7Btn11.TabIndex = 1019;
            this.jS7Btn11.Text = "jS7Btn11";
            this.jS7Btn11.UseVisualStyleBackColor = false;
            this.jS7Btn11.Click += new System.EventHandler(this.JS7Btn11Click);
            // 
            // FrmHome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.BackgroundImage = global::StoreManagement.Properties.Resources.LightBackgroundTile;
            this.ClientSize = new System.Drawing.Size(574, 327);
            this.Controls.Add(this.jsGroupBox3);
            this.Controls.Add(this.jsGroupBox2);
            this.Controls.Add(this.jsGroupBox1);
            this.Controls.Add(this.jsPanelMenuHome);
            this.DoubleBuffered = true;
            this.Name = "FrmHome";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "سامانه مدیریت فروشگاه | صفحه اصلی";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmHomeFormClosing);
            this.jsPanelMenuHome.ResumeLayout(false);
            this.jsGroupBox1.ResumeLayout(false);
            this.jsGroupBox2.ResumeLayout(false);
            this.jsGroupBox3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private JSRequirement.Controls.JSPanel jsPanelMenuHome;
        private Requirement.JSMenuStripStoreManagement jsMenuStripStoreManagement1;
        private JSRequirement.Controls.JS7Btn jS7Btn4;
        private JSRequirement.Controls.JS7Btn jS7Btn5;
        private JSRequirement.Controls.JS7Btn jS7Btn1;
        private JSRequirement.Controls.JS7Btn jS7Btn3;
        private JSRequirement.Controls.JS7Btn jS7Btn6;
        private JSRequirement.Controls.JS7Btn jS7Btn7;
        private JSRequirement.Controls.JS7Btn jS7Btn8;
        private JSRequirement.Controls.JS7Btn jS7Btn9;
        private JSRequirement.Controls.JS7Btn jS7Btn2;
        private JSRequirement.Controls.JS7Btn jS7Btn10;
        private JSRequirement.Controls.JSGroupBox jsGroupBox1;
        private JSRequirement.Controls.JSGroupBox jsGroupBox2;
        private JSRequirement.Controls.JSGroupBox jsGroupBox3;
        private JSRequirement.Controls.JS7Btn jS7Btn11;
    }
}
